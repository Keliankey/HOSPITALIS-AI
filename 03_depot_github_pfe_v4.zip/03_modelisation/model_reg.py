"""Entrainement, validation temporelle par blocs, calibration.
Cible : INVENDU (la nuit restera vide) — c'est la grandeur du revenu a risque.
Population : les nuits ENCORE OUVERTES a la date d'observation.
Aucun reechantillonnage, aucune ponderation de classe (van den Goorbergh 2022 ; Carriero 2025).
"""
import numpy as np, pandas as pd, warnings, json
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, brier_score_loss
import xgboost as xgb
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')

HOR = [90, 60, 30, 15, 7, 3]
FIN_FENETRE = '2026-08-31'   # derniere nuit modelisee : dernier mois complet avant l extraction (chapitre 3, section 3.8)
p = pd.read_pickle('panel.pkl')
p = p[p.nuit <= FIN_FENETRE]
cal = pd.read_excel('Calendrier_exogene.xlsx', sheet_name='Calendrier')
cal = cal[['date', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour_eur']]
cal.columns = ['nuit', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour']
p = p.merge(cal, on='nuit', how='left')

# structure du bien (zone), sans identifiant : la lecon de la ref. 43
win = pd.read_pickle('p2w.pkl').reset_index()
p = p.merge(win[['code', 'zone']], on='code', how='left')

p['invendu'] = 1 - p.vendu
p['week_end'] = p.jour_semaine.isin([4, 5]).astype(int)
p['mois'] = p.nuit.dt.month
ouv = p[p.deja_vendu_a_d0 == 0].copy()

FEAT = ['quantieme', 'jour_semaine', 'week_end', 'mois', 'occ_30j', 'occ_60j',
        'jours_depuis_resa', 'jours_depuis_remise_en_ligne', 'penalite_visibilite',
        'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour']
CAT = ['zone']

# ---- blocs temporels successifs (Bergmeir & Benitez : blocs, pas dernier bloc unique)
BORNES = ['2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']

def cal_int_slope(y, prob):
    """Ordonnee a l'origine et pente de calibration (Van Calster 2019)."""
    eps = 1e-6
    lo = np.log(np.clip(prob, eps, 1 - eps) / (1 - np.clip(prob, eps, 1 - eps)))
    if len(np.unique(y)) < 2:
        return np.nan, np.nan
    slope = LogisticRegression(penalty=None, solver='lbfgs', max_iter=1000)\
        .fit(lo.reshape(-1, 1), y).coef_[0][0]
    # intercept : pente fixee a 1, logit en offset
    from sklearn.linear_model import SGDClassifier
    b, lr = 0.0, 0.05
    for _ in range(400):                       # Newton simplifie sur l'intercept seul
        pr = 1 / (1 + np.exp(-(lo + b)))
        g = np.sum(y - pr); h = np.sum(pr * (1 - pr))
        if h <= 0: break
        step = g / h
        b += step
        if abs(step) < 1e-9: break
    return b, slope

def net_benefit(y, prob, pt):
    """Benefice net (Vickers & Elkin) : on consent une remise si prob >= pt."""
    n = len(y)
    trait = prob >= pt
    tp = np.sum(trait & (y == 1)); fp = np.sum(trait & (y == 0))
    return tp / n - (fp / n) * (pt / (1 - pt))

res, curves, preds_all = [], [], []
for h in HOR:
    d = ouv[ouv.horizon == h].sort_values('nuit')
    for i in range(1, len(BORNES)):
        t0, t1 = BORNES[i - 1], BORNES[i]
        tr = d[d.nuit < t0]
        te = d[(d.nuit >= t0) & (d.nuit < t1)]
        if len(tr) < 500 or len(te) < 200: continue
        Xtr, Xte = tr[FEAT], te[FEAT]
        ytr, yte = tr.invendu.values, te.invendu.values
        if len(np.unique(ytr)) < 2 or len(np.unique(yte)) < 2: continue

        m = {}
        m['XGBoost'] = xgb.XGBClassifier(
            n_estimators=150, max_depth=3, learning_rate=0.03, subsample=0.7,
            colsample_bytree=0.7, reg_lambda=10.0, min_child_weight=50, eval_metric='logloss',
            tree_method='hist').fit(Xtr, ytr)
        m['CatBoost'] = CatBoostClassifier(
            iterations=150, depth=3, learning_rate=0.03, l2_leaf_reg=20,
            verbose=0, allow_writing_files=False).fit(
            pd.concat([Xtr, tr[CAT]], axis=1), ytr, cat_features=CAT)
        lg_tr = Xtr.fillna(Xtr.median()); lg_te = Xte.fillna(Xtr.median())
        m['Regression logistique'] = LogisticRegression(max_iter=2000).fit(
            (lg_tr - lg_tr.mean()) / (lg_tr.std() + 1e-9), ytr)

        for nom, mod in m.items():
            if nom == 'CatBoost':
                pr = mod.predict_proba(pd.concat([Xte, te[CAT]], axis=1))[:, 1]
            elif nom == 'Regression logistique':
                pr = mod.predict_proba((lg_te - lg_tr.mean()) / (lg_tr.std() + 1e-9))[:, 1]
            else:
                pr = mod.predict_proba(Xte)[:, 1]
            ic, sl = cal_int_slope(yte, pr)
            res.append(dict(horizon=h, bloc=f'{t0[:7]}→{t1[:7]}', modele=nom,
                            n_train=len(tr), n_test=len(te),
                            taux_base=round(100 * yte.mean(), 1),
                            AUC=round(roc_auc_score(yte, pr), 4),
                            Brier=round(brier_score_loss(yte, pr), 4),
                            cal_intercept=round(ic, 3), cal_pente=round(sl, 3)))
            if i == len(BORNES) - 1:          # dernier bloc : courbes de decision
                preds_all.append(pd.DataFrame(dict(horizon=h, modele=nom,
                                                   y=yte, prob=pr)))

R = pd.DataFrame(res)
R.to_csv('resultats_modeles_reg.csv', index=False)
pd.concat(preds_all).to_pickle('preds.pkl')

print('=== MOYENNE SUR LES BLOCS, PAR HORIZON ET MODELE ===')
agg = R.groupby(['horizon', 'modele']).agg(
    blocs=('AUC', 'size'), taux_base=('taux_base', 'mean'),
    AUC=('AUC', 'mean'), Brier=('Brier', 'mean'),
    cal_intercept=('cal_intercept', 'mean'), cal_pente=('cal_pente', 'mean')).round(3)
print(agg.to_string())
