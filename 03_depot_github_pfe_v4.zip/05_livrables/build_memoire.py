"""Assemble le mémoire, produit le Word (table des matières à points de suite et liens,
numéros de page en bas à droite) puis met à jour la table avec LibreOffice et exporte le PDF."""
import re, subprocess, zipfile, shutil, os, sys
os.chdir('/home/claude/pfe')
A="[À rédiger par l'auteur.]"
TOC=r"""```{=openxml}
<w:p><w:pPr><w:pStyle w:val="TOCHeading"/><w:pageBreakBefore/></w:pPr><w:r><w:t>Table des matières</w:t></w:r></w:p><w:p><w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve">TOC \o "1-2" \h \z \u</w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>Clic droit, puis Mettre à jour les champs.</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>
```"""
front=open('memoire-assemble.md').read().split('# Remerciements')[0]
ref=open('resultats-reference-31-aout.md').read()
sec7=ref[ref.index("| Seuil | Modèle |"):ref.index("Mise à jour du 3 octobre au soir")]
att=ref[ref.index("| Horizon | AUC sans |"):ref.index("Aucun gain.")]
typ=ref[ref.index("| Modèle | Variante |"):ref.index("Le type ne change rien")]
parts=[front,"# Remerciements\n\n"+A,"# Résumé exécutif\n\n"+A,"# Déclaration d'usage de l'intelligence artificielle\n\n"+A,TOC,
 open('glossaire-court.md').read(),open('chapitre-1-complet.md').read(),open('chapitre-2-assemble.md').read(),
 open('chapitre-3-methodologie.md').read(),open('chapitres-4-a-7-corrige.md').read(),open('references.md').read(),
 "# Annexes\n\n## Annexe A. Note méthodologique étendue\n\n"+A+"\n\n## Annexe B. Code source et dépôt\n\nLe code est livré sous la forme d'un dépôt (depot_github_pfe_v4), sans aucune donnée. Il comprend la construction du panel, les variables exogènes, la modélisation, les figures et les livrables. L'adresse du dépôt public est à compléter par l'auteur.\n\n"
 "## Annexe C. Tableaux complémentaires\n\nTableau C.1. Sensibilité au seuil d'interruption longue, 4 modèles\n\n"+sec7.strip()+"\n\nTableau C.2. Apport des 2 attributs du rapport de la plateforme (XGBoost, intervalles à 95 % par rééchantillonnage en grappes sur les annonces)\n\n"+att.strip()+"\n\nTableau C.3. Apport du type de bien, 3 blocs temporels\n\n"+typ.strip()+"\n\n"
 "## Annexe D. Autorisation d'exploitation des données\n\nL'autorisation signée est jointe au dossier de dépôt.\n\n## Annexe E. Journal d'usage de l'intelligence artificielle\n\n"+A]
open('memoire-complet-03-10.md','w').write("\n\n".join(parts).replace('\\.','.'))
raw='/tmp/m_raw.docx'
subprocess.run(['pandoc','memoire-complet-03-10.md','--reference-doc=reference-pfe.docx','-M','lang=fr-FR','-o',raw],check=True)
# --- post-traitement XML
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
z=zipfile.ZipFile(raw); files={n:z.read(n) for n in z.namelist()}; z.close()
doc=files['word/document.xml'].decode()
sect=('<w:sectPr><w:footerReference w:type="default" r:id="rIdPied"/><w:pgSz w:w="11906" w:h="16838"/>'
      '<w:pgMar w:top="1418" w:right="1418" w:bottom="1418" w:left="1418" w:header="709" w:footer="709" w:gutter="0"/></w:sectPr>')
doc=doc.replace('<w:sectPr />',sect)
if 'xmlns:r=' not in doc[:2000]:
    doc=doc.replace('<w:document ','<w:document xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ',1)
files['word/document.xml']=doc.encode()
files['word/footer1.xml']=(f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="{W}"><w:p><w:pPr><w:jc w:val="right"/></w:pPr>'
 '<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r>'
 '<w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>').encode()
rels=files['word/_rels/document.xml.rels'].decode()
rels=rels.replace('</Relationships>','<Relationship Id="rIdPied" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
files['word/_rels/document.xml.rels']=rels.encode()
ct=files['[Content_Types].xml'].decode()
ct=ct.replace('</Types>','<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
files['[Content_Types].xml']=ct.encode()
st=files['word/styles.xml'].decode()
st=re.sub(r'<w:style [^>]*w:styleId="TOC[12]".*?</w:style>','',st,flags=re.S)
def toc(i,ind): return (f'<w:style w:type="paragraph" w:styleId="TOC{i}"><w:name w:val="toc {i}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="39"/><w:unhideWhenUsed/>'
  f'<w:pPr><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9070"/></w:tabs><w:spacing w:before="0" w:after="100" w:line="276" w:lineRule="auto"/><w:ind w:left="{ind}" w:right="0" w:firstLine="0"/><w:jc w:val="left"/></w:pPr></w:style>')
st=st.replace('</w:styles>',toc(1,0)+toc(2,284)+'</w:styles>')
st=re.sub(r'(<w:style [^>]*w:styleId="Heading1"[^>]*>.*?<w:pPr>)',r'\1<w:pageBreakBefore/>',st,count=1,flags=re.S)
files['word/styles.xml']=st.encode()
se=files['word/settings.xml'].decode()
if 'updateFields' not in se: se=re.sub(r'(<w:settings[^>]*>)',r'\1<w:updateFields w:val="true"/>',se,count=1)
files['word/settings.xml']=se.encode()
inter='/tmp/m_inter.docx'
with zipfile.ZipFile(inter,'w',zipfile.ZIP_DEFLATED) as zo:
    for n,b in files.items(): zo.writestr(n,b)
print('docx intermediaire pret')
