# I.A explicable (xAI) pour anticiper l’inoccupation et le revenu à risque : code du mémoire

Code source accompagnant le mémoire de fin d'études du MSc *Artificial Intelligence for Business*, aivancity.

**Sujet.** « I.A explicable (xAI) pour anticiper l’inoccupation et le revenu à risque : conception et évaluation d’un système prédictif multi-horizon pour les locations de courte durée à Bruxelles ».

---

## ⚠️ Ce dépôt ne contient aucune donnée, et c'est délibéré

Les données d'exploitation sont **confidentielles** et couvertes par une autorisation d'usage strictement académique. Aucun fichier de données n'est publié ici : ni réservations, ni revenus, ni identifiants d'annonce, ni nom de bien.

Le `.gitignore` exclut explicitement tous les formats de données. **Vérifiez-le avant chaque commit.**

Les scripts de **préparation des données brutes** ne figurent pas non plus dans ce dépôt. Ils sont soudés aux fichiers sources et en portent les identifiants : noms de biens, libellés de comptes, intitulés de feuilles. Ils font partie de l'annexe confidentielle remise au jury, pas de la publication. Ce qu'ils font est décrit au chapitre Méthodologie ; ce qui est publié ici commence à la construction du panel, c'est-à-dire là où la méthode devient reproductible indépendamment des données.

---

## Ce que le dispositif fait

Prédire, pour chaque nuit d'un parc de locations de courte durée et à six horizons (J-90, J-60, J-30, J-15, J-7, J-3), la probabilité qu'elle reste invendue : puis la convertir en euros, et en décision de remise.

Trois contraintes structurent tout le code :

1. **Point-in-time strict.** À l'horizon J-*h*, seule l'information disponible *h* jours avant la nuit entre dans la matrice d'attributs. Deux contrôles d'intégrité le vérifient sur toutes les lignes du panel. La fenêtre modélisée s'arrête au 31 août 2026 (constante FIN_FENETRE).
2. **Cible fixe.** Le dénouement d'une nuit est identique aux six horizons ; seules les matrices d'attributs changent.
3. **Validation par blocs temporels successifs**, jamais par découpage aléatoire : le script `03_modelisation/comparaison.py` mesure l'écart entre les deux.

---

## Ordre d'exécution

```
01_panel/lags.py            construit le panel bien × nuit × horizon, variables retardées
01_panel/export.py          exporte le panel et ses neuf contrôles d'intégrité
01_panel/type_bien.py       type de bien déduit du libellé (seuls le code et le type sont écrits)

02_exogene/exo.py                   squelette du calendrier : fériés, ponts, régime fiscal
02_exogene/vacances.py              vacances scolaires des deux communautés
02_exogene/irm.py                   extraction des bilans climatiques IRM
02_exogene/irm_export.py            mise en forme, avec la règle d'admissibilité
02_exogene/meteo_previous_runs.py   archive de prévisions Open-Meteo (point-in-time)
02_exogene/meteo_build.py           filtrage des colonnes admissibles

03_modelisation/model_reg.py    entraînement, validation par blocs, calibration
03_modelisation/meteo_test2.py  la météo améliore-t-elle la prédiction ? (non)
03_modelisation/vac_test.py     les vacances scolaires ? (oui, et le gain croît avec l'horizon)
03_modelisation/comparaison.py  4 modèles × 4 protocoles
03_modelisation/fuite_graines.py part de l'optimisme due à la duplication de la cible, dix tirages
03_modelisation/final.py        courbes de décision, valeurs de Shapley, valorisation en euros
03_modelisation/sensibilite_seuil.py       seuil d'interruption 30, 45, 60 jours (3 modèles)
03_modelisation/sensibilite_seuil_lstm.py  même test pour le LSTM
03_modelisation/test_type_bien.py          le type de bien améliore-t-il le modèle ? (non)
03_modelisation/test_attributs_plateforme.py  2 attributs du rapport de la plateforme (non)
03_modelisation/erreurs_capacite.py       analyse des erreurs (section 4.5) et contrainte de capacite (5.4)
03_modelisation/bn_realise.py             benefice net realise sous capacite, Singh, Shah et Vickers (2023)
03_modelisation/recalage.py               recalage glissant du niveau, exploratoire (section 6.3)

04_figures/figures.py           figures 1 à 3
04_figures/fig_protocoles.py    figure 4
04_figures/fig_modeles.py       figures 5 à 7
04_figures/fig_attributs_plateforme.py  figure du rapport de la plateforme
04_figures/fig_activite_annuelle.py     activite annuelle du parc (chapitre 1)

05_livrables/classeur_resultats.py  classeur documenté : formules, exemples, données
05_livrables/prototype_rejeu.py     scores du prototype Hospitalis AI, rejeu du dernier bloc
```

Chaque script est autonome et lit les fichiers produits par les précédents.

## Configuration

Les scripts qui lisent des données brutes utilisent une racine unique :

```bash
export PFE_DONNEES=/chemin/vers/vos/donnees/
```

À défaut, `./donnees/` est utilisé. Aucun chemin absolu n'est codé en dur.

## Dépendances

```bash
pip install -r requirements.txt
```

`torch` n'est nécessaire que pour le volet LSTM de `comparaison.py`.

---

## Les trois résultats que ce code produit

**Le revenu à risque, vérifié en euros.** `RaR = P(invendu) × R`, avec *R* le revenu net par nuit vendue. Sur le dernier bloc temporel (mars à août 2026), la somme des probabilités × *R* sous-estime la perte réellement constatée de 3,4 % à 7,6 % selon l'horizon. C'est une vérification de calibration exprimée dans l'unité de la décision, et le code la rapporte telle quelle.

**Les courbes de décision.** Bénéfice net au sens de Vickers & Elkin (2006), comparé aux deux règles uniformes, sur dix-neuf seuils. Le modèle domine les deux règles sur 6 à 10 seuils selon l'horizon, et pas partout, ce que le code rapporte tel quel.

**Ce que le protocole de validation fait au résultat.** Le découpage aléatoire gonfle l'aire sous la courbe de +0,017 (régression logistique) à +0,054 (LSTM) par rapport aux blocs temporels. La part imputable à la seule duplication de la cible entre horizons, mesurée sur dix tirages par `fuite_graines.py`, est faible : +0,002 à +0,007 en moyenne, avec un écart-type de l'ordre de 0,009. L'essentiel de l'optimisme vient donc du mélange des périodes, non de la duplication.

**Ce qui a été testé et écarté.** Le type de bien ne change ni l'aire sous la courbe ni l'écart en euros. Les 2 attributs du rapport de la plateforme n'apportent rien : 5 intervalles de confiance sur 6, obtenus par rééchantillonnage en grappes sur les annonces, contiennent zéro, le sixième est négatif. Le classement des modèles ne dépend pas du seuil d'interruption retenu (30, 45 ou 60 jours).

**Une limite de reproductibilité observée.** Entraîner les mêmes modèles sur les mêmes lignes dans un autre ordre déplace l'écart en euros d'environ 1 point selon l'horizon. Les scripts trient donc les lignes par date de nuit avant l'apprentissage.

---

## Reproductibilité

Les scripts fixent les graines aléatoires (`random_state=0`, `torch.manual_seed(0)`) et les bornes temporelles sont écrites en clair. À données identiques, les résultats le sont aussi.

Ce qui ne se reproduit pas sans les données : tout le volet empirique. Ce dépôt sert à **vérifier la méthode**, pas à refaire les chiffres.

## Sources externes et licences

| Source | Usage | Licence |
|---|---|---|
| Open-Meteo, Previous Runs API | prévisions point-in-time, J-3 et J-7 | CC BY 4.0 : attribution obligatoire |
| Institut Royal Météorologique | bilans climatiques, station d'Uccle | consultation, non redistribués |
| enseignement.be / onderwijs.vlaanderen.be | calendriers scolaires | données publiques |
| Moniteur belge, SPF Finances | ordonnances, circulaire TVA | données publiques |

## Déclaration d'usage de l'intelligence artificielle

Ce code a été écrit avec l'assistance d'un modèle de langage. Le détail : ce qui a été proposé, conservé, modifié ou rejeté : figure dans le journal d'usage annexé au mémoire, conformément aux règles de l'établissement.

## Licence

Code sous licence MIT. **Les données n'y sont pas soumises** : elles ne sont pas publiées et restent la propriété de leur détenteur.
