import numpy as np, pandas as pd, warnings
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
exec(open('exogenes_ablation.py').read().split("BASE0=TEMPS+HIST")[0])
BORNES=['2025-03-01','2025-09-01','2026-03-01','2026-09-01']
def cb(tr,te,f):
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False)
    m.fit(pd.concat([tr[f],tr[CAT]],axis=1),tr.invendu,cat_features=CAT); return m.predict_proba(pd.concat([te[f],te[CAT]],axis=1))[:,1]
FINAL=TEMPS+HIST+FER+FISC+VAC; SANS=TEMPS+HIST+FER+VAC
def pente(y,pr):
    pr=np.clip(pr,1e-4,1-1e-4); lg=np.log(pr/(1-pr)).reshape(-1,1); return LogisticRegression(C=1e6).fit(lg,y).coef_[0,0]
REV=65.87; rows=[]
for i in range(3):
    for h in HOR:
        d=ouv[ouv.horizon==h].sort_values('nuit'); tr=d[d.nuit<BORNES[i]]; te=d[(d.nuit>=BORNES[i])&(d.nuit<BORNES[i+1])]
        for nom,f in [('final',FINAL),('sans_fiscal',SANS)]:
            pr=cb(tr,te,f); y=te.invendu.values
            rows.append(dict(bloc=i+1,h=h,modele=nom,auc=roc_auc_score(y,pr),pente=pente(y,pr),ecart=100*(pr.sum()-y.sum())/y.sum()))
R=pd.DataFrame(rows); R.to_csv('sans_fiscal.csv',index=False)
print(R.groupby('modele')[['auc','pente']].mean().round(4))
print(R[R.bloc==3].pivot(index='h',columns='modele',values='ecart').round(1).loc[HOR])
o=ouv[ouv.horizon==30]
C=o[['occ_30j','occ_60j','quantieme','mois','tva_taux','taxe_sejour','jours_depuis_resa','vac_fwb','vac_flandre']].corr(method='spearman').round(2)
print(C.to_string())
