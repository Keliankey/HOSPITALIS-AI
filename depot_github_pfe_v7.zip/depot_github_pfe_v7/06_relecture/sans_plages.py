exec(open('relecture_tests.py').read().split("cells=[]")[0])
q=pd.read_pickle('perim.pkl').sort_values(['code','nuit']); q['inv']=1-q.vendu
q['brk']=(q.inv!=q.groupby('code').inv.shift())|(q.nuit-q.groupby('code').nuit.shift()!=pd.Timedelta('1D')); q['run']=q.brk.cumsum()
r=q[q.inv==1].groupby('run').nuit.size(); q['long']=q.run.isin(set(r[(r>=22)&(r<=44)].index))
o=ouv.merge(q[['code','nuit','long']],on=['code','nuit'],how='left'); o=o[~o.long.fillna(False)]
for h in HOR:
    d=o[o.horizon==h].sort_values(['nuit','code']); tr=d[d.nuit<'2026-03-01']; te=d[d.nuit>='2026-03-01']
    pr=cb(tr,te,FEAT); y=te.invendu.values
    print(f'J-{h:2d}: sans plages longues (apprentissage et test) : ecart {100*(pr.sum()-y.sum())/y.sum():+5.1f} %  AUC {roc_auc_score(y,pr):.3f}  taux base app {100*tr.invendu.mean():.1f} test {100*y.mean():.1f}')
