import pandas as pd, numpy as np
q=pd.read_pickle('perim.pkl').sort_values(['code','nuit'])
q['inv']=1-q.vendu
# plages consecutives d'invendu par annonce
q['brk']=(q.inv!=q.groupby('code').inv.shift())|(q.nuit-q.groupby('code').nuit.shift()!=pd.Timedelta('1D'))
q['run']=q.brk.cumsum()
r=q[q.inv==1].groupby('run').agg(code=('code','first'),deb=('nuit','min'),fin=('nuit','max'),n=('nuit','size'))
L=r[(r.n>=22)&(r.n<=44)]
print('plages 22-44:',len(L),'nuits',L.n.sum(),'part',round(100*L.n.sum()/len(q),1),'%')
# repartition par periode (blocs)
B=[('2023-11-04','2025-03-01','apprentissage initial'),('2025-03-01','2025-09-01','bloc 1'),('2025-09-01','2026-03-01','bloc 2'),('2026-03-01','2026-09-01','bloc 3 (test final)')]
q['in_long']=q.run.isin(L.index)
for a,b,nom in B:
    s=q[(q.nuit>=a)&(q.nuit<b)]
    print(f'{nom:22s} nuits {len(s):6d}  invendu {100*s.inv.mean():5.1f} %  dans plages 22-44 : {s.in_long.sum():5d} = {100*s.in_long.mean():4.1f} % du perimetre, {100*s.in_long.sum()/max(s.inv.sum(),1):4.1f} % de l invendu')
s=q[(q.nuit>='2026-03-01')]
s['mois']=s.nuit.dt.month
print(s.groupby('mois').agg(nuits=('inv','size'),invendu=('inv','mean'),long=('in_long','mean')).round(3))
