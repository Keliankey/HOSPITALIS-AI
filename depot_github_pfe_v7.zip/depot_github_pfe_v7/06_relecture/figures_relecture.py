import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
exec(open('figures.py').read().split('# ============================================================ FIGURE 1')[0])
HOR=[90,60,30,15,7,3]
# ---------- A. courbe de réservation et horizons
r=pd.read_csv('delais_reservation.csv'); L=r.delai_reservation_jours.values
x=np.arange(0,121); y=[100*(L<=k).mean() for k in x]
fig,ax=plt.subplots(figsize=(7.2,3.6)); soigne(ax)
ax.plot(x,y,color=BLEU,lw=2)
for h in HOR:
    v=100*(L<=h).mean(); ax.axvline(h,color=GRILLE,lw=0.8,ls='--'); ax.plot(h,v,'o',color=ORANGE,ms=5)
    ax.annotate(f'J-{h}\n{v:.0f} %'.replace('.',','),(h,v),textcoords='offset points',xytext=(4,-22 if h>7 else 6),fontsize=7.5,color=ENCRE)
ax.invert_xaxis(); ax.set_xlim(120,0); ax.set_ylim(0,102)
ax.set_xlabel("Jours avant l'arrivée"); ax.set_ylabel("Réservations restant à venir (%)")
ax.set_title("Courbe de réservation du parc et position des 6 horizons")
fig.savefig('fig_courbe_reservation.png'); plt.close(fig)
# ---------- B. schéma des blocs temporels
fig,ax=plt.subplots(figsize=(7.2,2.4))
deb=pd.Timestamp('2023-11-04'); B=[pd.Timestamp(b) for b in ['2025-03-01','2025-09-01','2026-03-01','2026-09-01']]
for i in range(3):
    yy=2-i
    ax.barh(yy,(B[i]-deb).days,left=0,color=BLEU,alpha=0.85,height=0.5)
    ax.barh(yy,(B[i+1]-B[i]).days,left=(B[i]-deb).days,color=ORANGE,height=0.5)
    ax.text(-15,yy,f'Bloc {i+1}',ha='right',va='center',fontsize=8.5,color=ENCRE)
    ax.text((B[i]-deb).days/2,yy,'apprentissage',ha='center',va='center',fontsize=7.5,color='white')
    ax.text((B[i]-deb).days+(B[i+1]-B[i]).days/2,yy,'test',ha='center',va='center',fontsize=7.5,color='white')
ticks=[deb]+B; ax.set_xticks([(t-deb).days for t in ticks]); ax.set_xticklabels(['nov. 2023','mars 2025','sept. 2025','mars 2026','août 2026'],fontsize=7.5)
ax.set_yticks([]); [ax.spines[s].set_visible(False) for s in ('top','right','left')]
ax.set_title("Validation par blocs temporels : apprendre sur le passé, tester sur la période suivante")
fig.savefig('fig_blocs_temporels.png'); plt.close(fig)
# ---------- C. AUC par horizon, 4 modèles et référence naïve
M={'Régression logistique':[0.6168,0.6060,0.6093,0.6043,0.6003,0.5944],'XGBoost':[0.6243,0.6283,0.6501,0.6360,0.6274,0.6220],
   'CatBoost':[0.6214,0.6299,0.6466,0.6332,0.6260,0.6221],'LSTM':[0.6201,0.6036,0.6252,0.6194,0.6123,0.6357]}
nv=pd.read_csv('auc_par_bloc_horizon.csv').groupby('horizon').naive.mean().loc[HOR].values
fig,ax=plt.subplots(figsize=(7.2,3.6)); soigne(ax); xs=np.arange(6)
sty={'CatBoost':(BLEU,'-','o'),'XGBoost':(AQUA,'--','s'),'Régression logistique':(ORANGE,'-.','^'),'LSTM':(ENCRE2,':','D')}
for k,v in M.items():
    c,ls,mk=sty[k]; ax.plot(xs,v,color=c,ls=ls,marker=mk,ms=4,lw=1.6,label=k)
ax.plot(xs,nv,color='#9a9893',ls='-',marker='x',ms=5,lw=1.2,label='Référence naïve (taux historique)')
ax.axhline(0.5,color=GRILLE,lw=0.8); ax.text(5.05,0.5,'hasard',fontsize=7,va='center',color=ENCRE2)
ax.set_xticks(xs); ax.set_xticklabels([f'J-{h}' for h in HOR]); ax.set_ylim(0.49,0.67)
ax.set_ylabel('Aire sous la courbe (AUC)'); ax.set_title('Discrimination par horizon : 4 modèles et référence naïve')
ax.legend(fontsize=7.5,frameon=False,ncol=2,loc='lower left'); virgule(fig)
fig.savefig('fig_auc_horizon.png'); plt.close(fig)
print('ok')
