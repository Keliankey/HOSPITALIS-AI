"""Tests demandes par la relecture du 4 octobre : reference naive, IC bootstrap par annonce,
part du signal au-dela du hasard, effet des plages longues (canal direct) sur la sous-estimation."""
import numpy as np, pandas as pd, warnings, xgboost as xgb
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE=['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne','penalite_visibilite','ferie','veille_ferie','pont','tva_taux','taxe_sejour']
FEAT=BASE+VAC; CAT=['zone']; HOR=[90,60,30,15,7,3]
p=pd.read_pickle('panel.pkl')
C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['date']=pd.to_datetime(C.date)
cal=C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC]; cal.columns=['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour']+VAC
p=p.merge(cal,on='nuit',how='left').merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']],on='code',how='left')
p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int); p['mois']=p.nuit.dt.month
p['zone_i']=(p.zone=='Laeken').astype(int)
ouv=p[p.deja_vendu_a_d0==0].copy()
BORNES=['2025-03-01','2025-09-01','2026-03-01','2026-09-01']

def cb(tr,te,feat):
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False)
    m.fit(pd.concat([tr[feat],tr[CAT]],axis=1),tr.invendu,cat_features=CAT)
    return m.predict_proba(pd.concat([te[feat],te[CAT]],axis=1))[:,1]
def xg(tr,te):
    m=xgb.XGBClassifier(n_estimators=150,max_depth=3,learning_rate=0.03,subsample=0.7,colsample_bytree=0.7,reg_lambda=10.0,min_child_weight=50,eval_metric='logloss',tree_method='hist',random_state=0)
    m.fit(tr[FEAT+['zone_i']],tr.invendu); return m.predict_proba(te[FEAT+['zone_i']])[:,1]
def naive(tr,te):
    """Taux historique d'invendu de l'annonce pour le meme mois, a cet horizon, retreci vers le taux de l'annonce puis vers le taux global (k=20)."""
    g=tr.invendu.mean(); k=20
    a=tr.groupby('code').invendu.agg(['sum','size']); ra=((a['sum']+k*g)/(a['size']+k))
    am=tr.groupby(['code','mois']).invendu.agg(['sum','size']).reset_index()
    am['ra']=am.code.map(ra); am['r']=(am['sum']+k*am.ra)/(am['size']+k)
    t=te[['code','mois']].merge(am[['code','mois','r']],on=['code','mois'],how='left')
    return t.r.fillna(te.code.map(ra).reset_index(drop=True)).fillna(g).values
def pente(y,pr):
    pr=np.clip(pr,1e-4,1-1e-4); lg=np.log(pr/(1-pr)).reshape(-1,1)
    return LogisticRegression(C=1e6).fit(lg,y).coef_[0,0]

cells=[]
for i in range(3):
    for h in HOR:
        d=ouv[ouv.horizon==h].sort_values(['nuit','code'])
        tr=d[d.nuit<BORNES[i]]; te=d[(d.nuit>=BORNES[i])&(d.nuit<BORNES[i+1])].reset_index(drop=True)
        P=dict(catboost=cb(tr,te,FEAT),catboost_sans_vac=cb(tr,te,BASE),xgboost=xg(tr,te),naive=naive(tr,te),
               heuristique_occ30=1-te.occ_30j.fillna(tr.occ_30j.mean()).values)
        cells.append(dict(bloc=i+1,h=h,te=te[['code','nuit','invendu']],P=P))
        print(f'bloc {i+1} J-{h}: '+'  '.join(f'{k} {roc_auc_score(te.invendu,v):.3f}' for k,v in P.items()),flush=True)

def metr(idx=None):
    out={}
    for k in ['catboost','catboost_sans_vac','xgboost','naive','heuristique_occ30']:
        A=[];S=[]
        for c in cells:
            y=c['te'].invendu.values; pr=c['P'][k]
            if idx is not None:
                sel=idx[c['bloc'],c['h']]; y=y[sel]; pr=pr[sel]
            A.append(roc_auc_score(y,pr))
            if k in('catboost','xgboost'): S.append(pente(y,pr))
        out['auc_'+k]=np.mean(A)
        if S: out['pente_'+k]=np.mean(S)
    return out
obs=metr()
codes=sorted(ouv.code.unique()); rng=np.random.default_rng(42); B=300; boot=[]
pos={(c['bloc'],c['h']):{a:np.flatnonzero(c['te'].code.values==a) for a in codes} for c in cells}
for b in range(B):
    s=rng.choice(codes,len(codes),replace=True)
    idx={k:np.concatenate([v[a] for a in s]) for k,v in pos.items()}
    boot.append(metr(idx))
Bt=pd.DataFrame(boot)
def ic(serie): return f'[{np.percentile(serie,2.5):+.4f} ; {np.percentile(serie,97.5):+.4f}]'
print('\n=== MOYENNES 3 BLOCS x 6 HORIZONS, IC 95 % bootstrap par annonce (B=300) ===')
for k,v in obs.items(): print(f'{k:28s} {v:.4f}  IC {ic(Bt[k])}')
for nom,a,b in [('AUC CatBoost - naive','auc_catboost','auc_naive'),('AUC CatBoost - heuristique occ30','auc_catboost','auc_heuristique_occ30'),
                ('AUC vacances (avec - sans)','auc_catboost','auc_catboost_sans_vac'),('AUC XGBoost - CatBoost','auc_xgboost','auc_catboost'),
                ('Pente CatBoost - XGBoost','pente_catboost','pente_xgboost')]:
    print(f'{nom:34s} {obs[a]-obs[b]:+.4f}  IC {ic(Bt[a]-Bt[b])}')
pd.DataFrame([obs]).to_csv('relecture_moyennes.csv',index=False); Bt.to_csv('relecture_bootstrap.csv',index=False)
rows=[]
for c in cells:
    y=c['te'].invendu.values
    rows.append(dict(bloc=c['bloc'],horizon=c['h'],**{k:round(roc_auc_score(y,v),4) for k,v in c['P'].items()}))
pd.DataFrame(rows).to_csv('auc_par_bloc_horizon.csv',index=False)

# --- sous-estimation du dernier bloc, avec et sans les plages longues de 22 a 44 nuits
q=pd.read_pickle('perim.pkl').sort_values(['code','nuit']); q['inv']=1-q.vendu
q['brk']=(q.inv!=q.groupby('code').inv.shift())|(q.nuit-q.groupby('code').nuit.shift()!=pd.Timedelta('1D')); q['run']=q.brk.cumsum()
r=q[q.inv==1].groupby('run').nuit.size(); longs=set(r[(r>=22)&(r<=44)].index)
q['long']=q.run.isin(longs); lk=q[['code','nuit','long']]
print('\n=== DERNIER BLOC : somme predite / invendu constate, toutes nuits puis hors plages 22-44 ===')
for c in cells:
    if c['bloc']!=3: continue
    t=c['te'].merge(lk,on=['code','nuit'],how='left'); pr=c['P']['catboost']; y=t.invendu.values; m=~t.long.fillna(False).values
    print(f"J-{c['h']:2d}: toutes {100*(pr.sum()-y.sum())/y.sum():+5.1f} %   hors plages longues {100*(pr[m].sum()-y[m].sum())/y[m].sum():+5.1f} %   (nuits retirees {(~m).sum()})")
