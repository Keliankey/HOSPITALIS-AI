"""Panel bien x nuit x horizon : variables retardees et penalite de remise en ligne.
Toutes les variables sont calculees a la DATE D'OBSERVATION d0 = nuit - horizon.
Aucune information posterieure a d0 n'entre dans une variable.
"""
import pickle, numpy as np, pandas as pd

HOR = [90, 60, 30, 15, 7, 3]
PEN_FENETRE = 60      # jours de penalite de visibilite apres remise en ligne
PEN_SEUIL   = 45      # duree minimale d'interruption ouvrant la penalite

res = pickle.load(open('p2.pkl', 'rb'))
win = pickle.load(open('p2w.pkl', 'rb')).reset_index()
qual = pickle.load(open('p2q.pkl', 'rb'))
inter = pickle.load(open('p2i2.pkl', 'rb'))

win = win.rename(columns={'Listing ID': 'listing'})
code_of = dict(zip(win.listing, win.code))
res['code'] = res['Listing ID'].map(code_of)
res = res.dropna(subset=['code'])
for c in ('Start date', 'End date', 'Booking date'):
    res[c] = pd.to_datetime(res[c])

# ---------------------------------------------------------------- 1. exposition
# une ligne par (code, nuit) sur la fenetre de commercialisation, moins les
# interruptions qualifiees sinistre / retrait / longue duree
rows = []
for _, w in win.iterrows():
    for d in pd.date_range(w.entree, w.sortie - pd.Timedelta(days=1), freq='D'):
        rows.append((w.code, d))
parc = pd.DataFrame(rows, columns=['code', 'nuit'])

hors = np.zeros(len(parc), dtype=bool)
for _, q in qual.iterrows():
    hors |= ((parc.code == q.code) &
             (parc.nuit >= q.debut) &
             (parc.nuit < q.fin)).values
parc['hors_perimetre'] = hors
perim = parc[~parc.hors_perimetre].copy()

# ---------------------------------------------------------------- 2. cible
# nuit vendue = couverte par une reservation, quelle que soit sa date de prise
vendu = set()
prise = {}                       # (code, nuit) -> date de reservation la plus ancienne
for r in res.itertuples():
    for d in pd.date_range(r._2, r._3 - pd.Timedelta(days=1), freq='D'):
        k = (r.code, d)
        vendu.add(k)
        b = r._7
        if k not in prise or b < prise[k]:
            prise[k] = b
perim['vendu'] = [1 if (c, d) in vendu else 0 for c, d in zip(perim.code, perim.nuit)]
perim['date_prise'] = [prise.get((c, d)) for c, d in zip(perim.code, perim.nuit)]

# ---------------------------------------------------------------- 3. historiques
occ = {}                         # code -> Series indexee par nuit, 1/0, sur le perimetre
for c, g in perim.groupby('code'):
    occ[c] = g.set_index('nuit')['vendu'].sort_index()

resa_par_code = {c: np.sort(g['Booking date'].values)
                 for c, g in res.groupby('code')}

# fin des interruptions, par code : (date de reouverture, duree de l'interruption)
reouv = {}
for _, it in inter.iterrows():
    reouv.setdefault(it.code, []).append((it.fin, int(it.jours)))
for c in reouv:
    reouv[c].sort()
entree_of = dict(zip(win.code, win.entree))

def hist(c, d0):
    """Remplissage des 30 et 60 jours precedant d0, connus a d0."""
    s = occ.get(c)
    out = []
    for n in (30, 60):
        if s is None:
            out.append(np.nan); continue
        f = s.loc[(s.index >= d0 - pd.Timedelta(days=n)) & (s.index < d0)]
        out.append(round(f.mean(), 4) if len(f) else np.nan)
    return out

def depuis_resa(c, d0):
    a = resa_par_code.get(c)
    if a is None: return np.nan
    a = a[a < np.datetime64(d0)]
    return int((d0 - pd.Timestamp(a[-1])).days) if len(a) else np.nan

def remise_en_ligne(c, d0):
    """(jours depuis la derniere remise en ligne, penalite de visibilite active)."""
    last, dur = entree_of.get(c), None
    for fin, j in reouv.get(c, []):
        if fin <= d0:
            last, dur = fin, j
    if last is None: return (np.nan, 0)
    jours = int((d0 - pd.Timestamp(last)).days)
    pen = 1 if (dur is not None and dur >= PEN_SEUIL and jours < PEN_FENETRE) else 0
    return (jours, pen)

# ---------------------------------------------------------------- 4. panel
out = []
for h in HOR:
    sub = perim.copy()
    sub['horizon'] = h
    sub['d0'] = sub.nuit - pd.Timedelta(days=h)
    # une ligne n'existe que si la date d'observation tombe apres l'entree en parc
    sub = sub[sub.d0 >= sub.code.map(entree_of)]
    sub['deja_vendu_a_d0'] = [
        1 if (p is not None and pd.notna(p) and p <= d0) else 0
        for p, d0 in zip(sub.date_prise, sub.d0)]
    hh = [hist(c, d0) for c, d0 in zip(sub.code, sub.d0)]
    sub['occ_30j'] = [x[0] for x in hh]
    sub['occ_60j'] = [x[1] for x in hh]
    sub['jours_depuis_resa'] = [depuis_resa(c, d0) for c, d0 in zip(sub.code, sub.d0)]
    rl = [remise_en_ligne(c, d0) for c, d0 in zip(sub.code, sub.d0)]
    sub['jours_depuis_remise_en_ligne'] = [x[0] for x in rl]
    sub['penalite_visibilite'] = [x[1] for x in rl]
    out.append(sub)

panel = pd.concat(out, ignore_index=True)
panel['quantieme'] = panel.nuit.dt.dayofyear
# quantieme agnostique a l'annee : correction bissextile apres le 28 fevrier
bis = panel.nuit.dt.is_leap_year & (panel.nuit.dt.month > 2)
panel.loc[bis, 'quantieme'] = panel.loc[bis, 'quantieme'] - 1
panel['jour_semaine'] = panel.nuit.dt.dayofweek
panel = panel[['code', 'nuit', 'horizon', 'd0', 'quantieme', 'jour_semaine',
               'deja_vendu_a_d0', 'occ_30j', 'occ_60j', 'jours_depuis_resa',
               'jours_depuis_remise_en_ligne', 'penalite_visibilite', 'vendu']]
panel.to_pickle('panel.pkl')

# ---------------------------------------------------------------- 5. controles
print('perimetre parc      :', len(parc), 'nuits')
print('hors perimetre      :', int(parc.hors_perimetre.sum()))
print('perimetre modele    :', len(perim), '| vendues', int(perim.vendu.sum()),
      '| invendues', int((1 - perim.vendu).sum()),
      '| taux de base', round(100 * (1 - perim.vendu.mean()), 1), '%')
print('panel               :', len(panel), 'lignes\n')

t = panel.groupby('horizon').agg(
    lignes=('vendu', 'size'),
    deja_vendu=('deja_vendu_a_d0', 'mean'),
    taux_vente_global=('vendu', 'mean'))
t['encore_ouvertes'] = panel[panel.deja_vendu_a_d0 == 0].groupby('horizon').size()
t['vente_si_ouverte'] = panel[panel.deja_vendu_a_d0 == 0].groupby('horizon')['vendu'].mean()
t['deja_vendu'] = (100 * t.deja_vendu).round(1)
t['taux_vente_global'] = (100 * t.taux_vente_global).round(1)
t['vente_si_ouverte'] = (100 * t.vente_si_ouverte).round(1)
print('PAR HORIZON (%)'); print(t.to_string())

print('\nPENALITE DE VISIBILITE')
p = panel[panel.deja_vendu_a_d0 == 0]
g = p.groupby('penalite_visibilite')['vendu'].agg(['size', 'mean'])
g['mean'] = (100 * g['mean']).round(1)
print(g.to_string())

print('\nCONTROLE POINT-IN-TIME : d0 > nuit ?',
      int((panel.d0 >= panel.nuit).sum()), 'ligne(s) — doit valoir 0')
print('valeurs manquantes :')
print(panel.isna().sum()[panel.isna().sum() > 0].to_string() or '  aucune')
