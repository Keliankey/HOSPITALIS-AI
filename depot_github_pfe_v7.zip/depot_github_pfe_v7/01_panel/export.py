"""Export du panel et de ses controles."""
import pandas as pd, numpy as np

p = pd.read_pickle('panel.pkl')
p.to_csv('Panel_variables_retardees.csv', index=False)

# ---- controles point-in-time ----------------------------------------------
ctrl = []
ctrl.append(("d0 posterieure ou egale a la nuit", int((p.d0 >= p.nuit).sum()), 0))
ctrl.append(("d0 != nuit - horizon", int((p.d0 != p.nuit - pd.to_timedelta(p.horizon, 'D')).sum()), 0))
ctrl.append(("occ_30j hors [0,1]", int(((p.occ_30j < 0) | (p.occ_30j > 1)).sum()), 0))
ctrl.append(("occ_60j hors [0,1]", int(((p.occ_60j < 0) | (p.occ_60j > 1)).sum()), 0))
ctrl.append(("jours_depuis_resa negatif", int((p.jours_depuis_resa < 0).sum()), 0))
ctrl.append(("jours_depuis_remise_en_ligne negatif", int((p.jours_depuis_remise_en_ligne < 0).sum()), 0))
ctrl.append(("penalite hors {0,1}", int((~p.penalite_visibilite.isin([0, 1])).sum()), 0))
ctrl.append(("cible hors {0,1}", int((~p.vendu.isin([0, 1])).sum()), 0))
ctrl.append(("deja_vendu=1 et cible=0 (incoherent)", int(((p.deja_vendu_a_d0 == 1) & (p.vendu == 0)).sum()), 0))
ctrl = pd.DataFrame(ctrl, columns=['Controle', 'Observe', 'Attendu'])
ctrl['Verdict'] = np.where(ctrl.Observe == ctrl.Attendu, 'OK', 'A CORRIGER')

# ---- par horizon -----------------------------------------------------------
ouv = p[p.deja_vendu_a_d0 == 0]
h = pd.DataFrame({
    'lignes': p.groupby('horizon').size(),
    'deja_vendues_a_d0_%': (100 * p.groupby('horizon').deja_vendu_a_d0.mean()).round(1),
    'encore_ouvertes': ouv.groupby('horizon').size(),
    'taux_vente_inconditionnel_%': (100 * p.groupby('horizon').vendu.mean()).round(1),
    'taux_vente_si_ouverte_%': (100 * ouv.groupby('horizon').vendu.mean()).round(1),
}).reset_index()
h['taux_invendu_si_ouverte_%'] = (100 - h['taux_vente_si_ouverte_%']).round(1)

# ---- penalite de visibilite ------------------------------------------------
pen = ouv.groupby(['horizon', 'penalite_visibilite']).agg(
    lignes=('vendu', 'size'), taux_vente=('vendu', 'mean')).reset_index()
pen['taux_vente'] = (100 * pen.taux_vente).round(1)
pen = pen.pivot(index='horizon', columns='penalite_visibilite',
                values=['lignes', 'taux_vente'])
pen.columns = ['lignes_hors_penalite', 'lignes_sous_penalite',
               'vente_hors_penalite_%', 'vente_sous_penalite_%']
pen = pen.reset_index()
pen['ecart_points'] = (pen['vente_sous_penalite_%'] - pen['vente_hors_penalite_%']).round(1)

# ---- dictionnaire ----------------------------------------------------------
dic = pd.DataFrame([
    ['code', 'identifiant d annonce pseudonymise', 'cle'],
    ['nuit', 'nuit predite', 'cle'],
    ['horizon', 'h, en jours : 90, 60, 30, 15, 7, 3', 'cle'],
    ['d0', 'date d observation = nuit - horizon. Aucune variable n utilise d information posterieure.', 'cle'],
    ['quantieme', 'jour de l annee, corrige des bissextiles (consigne du superviseur)', 'temps'],
    ['jour_semaine', '0 = lundi', 'temps'],
    ['deja_vendu_a_d0', '1 si la nuit etait deja reservee a d0. Connu a d0, donc admissible — mais voir la note.', 'etat'],
    ['occ_30j', 'part des nuits vendues dans les 30 jours precedant d0, meme bien', 'retardee'],
    ['occ_60j', 'idem sur 60 jours', 'retardee'],
    ['jours_depuis_resa', 'jours ecoules a d0 depuis la derniere reservation prise, meme bien', 'retardee'],
    ['jours_depuis_remise_en_ligne', 'jours ecoules a d0 depuis la fin de la derniere interruption, ou depuis l entree en parc', 'retardee'],
    ['penalite_visibilite', '1 si d0 tombe dans les 60 jours suivant la fin d une interruption de 45 jours ou plus', 'retardee'],
    ['vendu', 'CIBLE : 1 si la nuit s est finalement vendue. Fixe, identique a tous les horizons.', 'cible'],
], columns=['Variable', 'Definition', 'Famille'])

note = pd.DataFrame({'Notice': [
    "PANEL bien x nuit x horizon — variables retardees et penalite de remise en ligne.",
    "",
    "CONSTRUCTION. Perimetre de modelisation : 32 661 nuits, apres retrait des 7 128 nuits",
    "qualifiees sinistre ou longue duree. Taux d invendu 33,9 %. Six horizons, 186 508 lignes.",
    "Une ligne n existe que si la date d observation tombe apres l entree du bien en parc :",
    "c est pourquoi le nombre de lignes decroit quand l horizon s allonge.",
    "",
    "LE RESULTAT QUI CHANGE LA CIBLE. A J-3, 56,1 % des nuits sont DEJA VENDUES a la date",
    "d observation. Pour celles-la, il n y a rien a predire et aucune decision a prendre :",
    "le modele apprendrait a recopier une information deja connue, et son exactitude globale",
    "serait flatteuse sans valoir quoi que ce soit.",
    "La population qui porte la decision est celle des nuits ENCORE OUVERTES a d0 — les seules",
    "sur lesquelles une remise peut etre consentie. Restreint a elles, le taux de vente tombe",
    "de 66,0 % a 22,6 % a J-3, et de 67,1 % a 65,9 % a J-90.",
    "Consequence : le taux de base n est pas 33,9 %, il depend de l horizon. Entrainer et",
    "evaluer sur les nuits encore ouvertes, et le justifier au chapitre methodologique.",
    "",
    "PENALITE DE VISIBILITE. Mesuree ici sur les nuits encore ouvertes : 48,5 % de vente sous",
    "penalite contre 55,5 % hors penalite, soit -7,0 points. L ordre de grandeur rejoint les",
    "-9,1 points d occupation mesures precedemment par une autre voie. Deux mesures",
    "independantes qui convergent : c est ce qui rend le constat publiable.",
    "",
    "VALEURS MANQUANTES, et elles sont legitimes. occ_30j manque 7 222 fois et occ_60j 3 964 fois :",
    "ce sont les debuts de fenetre, ou l historique demande n existe pas encore. Ne pas imputer",
    "par zero — zero signifie « aucune nuit vendue », pas « on ne sait pas ». XGBoost et CatBoost",
    "traitent nativement l absence ; la laisser absente.",
    "",
    "CE QUI N EST PAS ENCORE DANS CE FICHIER : les quatre sources exogenes. Voir",
    "Calendrier_exogene.xlsx, onglet « Sources a collecter ».",
]})

with pd.ExcelWriter('Panel_controles.xlsx', engine='xlsxwriter') as x:
    note.to_excel(x, sheet_name='Lisez-moi', index=False)
    h.to_excel(x, sheet_name='Par horizon', index=False)
    pen.to_excel(x, sheet_name='Penalite visibilite', index=False)
    ctrl.to_excel(x, sheet_name='Controles', index=False)
    dic.to_excel(x, sheet_name='Dictionnaire', index=False)

print(ctrl.to_string(index=False))
print()
print(h.to_string(index=False))
print()
print(pen.to_string(index=False))
