"""Type de bien derive du titre de l'annonce (fichier consolide local, non publie).
3 modalites : Studio ; Appartement 2 chambres ; Appartement, chambres non precisees.
Seul le code annonce et le type sont conserves en sortie ; aucun titre n'est ecrit."""
import os, re, pandas as pd
src = os.environ.get('BASE_CONSOLIDEE', 'Parc2_base_consolidee.xlsx')
d = pd.read_excel(src, sheet_name='Par annonce', header=3)[['Code', 'Titre de l’annonce']].dropna(subset=['Code'])
def typ(s):
    s = str(s).lower()
    if 'studio' in s: return 'Studio'
    if re.search(r'\b2\s*(ch|bed|bd|br|chambre)', s): return 'Appartement 2 chambres'
    return 'Appartement, chambres non précisées'
d['type'] = d['Titre de l’annonce'].map(typ)
d[['Code', 'type']].to_pickle('type_bien.pkl')
print(d.type.value_counts())
