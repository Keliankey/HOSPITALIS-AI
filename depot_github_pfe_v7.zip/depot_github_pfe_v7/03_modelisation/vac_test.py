"""Les vacances scolaires ameliorent-elles la prediction ? Test aux SIX horizons.

Contrairement a la meteo, un calendrier scolaire est arrete plus d un an a l avance :
il est connu a J-90 comme a J-3. Aucune restriction de sous-echantillon, aucune
lacune de couverture. Le test porte donc sur la totalite du panel.
"""
import numpy as np, pandas as pd, warnings
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, brier_score_loss
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')

VAC = ['vac_fwb', 'vac_flandre', 'vac_les_deux', 'vac_une_seule',
       'vac_fwb_jour', 'vac_flandre_jour']

FIN_FENETRE = '2026-08-31'   # derniere nuit modelisee : dernier mois complet avant l extraction (chapitre 3, section 3.8)
p = pd.read_pickle('panel.pkl')
p = p[p.nuit <= FIN_FENETRE]
C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier')
C['date'] = pd.to_datetime(C.date)
cal = C[['date', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour_eur'] + VAC]
cal.columns = ['nuit', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour'] + VAC
p = p.merge(cal, on='nuit', how='left')
p = p.merge(pd.read_pickle('p2w.pkl').reset_index()[['code', 'zone']], on='code', how='left')
p['invendu'] = 1 - p.vendu
p['week_end'] = p.jour_semaine.isin([4, 5]).astype(int)
p['mois'] = p.nuit.dt.month
ouv = p[p.deja_vendu_a_d0 == 0].copy()
assert ouv[VAC].isna().sum().sum() == 0, 'valeurs manquantes sur les vacances'

BASE = ['quantieme', 'jour_semaine', 'week_end', 'mois', 'occ_30j', 'occ_60j',
        'jours_depuis_resa', 'jours_depuis_remise_en_ligne', 'penalite_visibilite',
        'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour']
CAT = ['zone']
BORNES = ['2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']

def pente(y, prob):
    eps = 1e-6
    lo = np.log(np.clip(prob, eps, 1 - eps) / (1 - np.clip(prob, eps, 1 - eps)))
    if len(np.unique(y)) < 2: return np.nan
    return LogisticRegression(penalty=None, solver='lbfgs', max_iter=1000)\
        .fit(lo.reshape(-1, 1), y).coef_[0][0]

res = []
for h in [90, 60, 30, 15, 7, 3]:
    d = ouv[ouv.horizon == h].sort_values('nuit')
    for jeu, feats in [('sans vacances', BASE), ('avec vacances', BASE + VAC)]:
        for i in range(1, len(BORNES)):
            t0, t1 = BORNES[i - 1], BORNES[i]
            tr = d[d.nuit < t0]; te = d[(d.nuit >= t0) & (d.nuit < t1)]
            if len(tr) < 500 or len(te) < 200: continue
            ytr, yte = tr.invendu.values, te.invendu.values
            if len(np.unique(ytr)) < 2 or len(np.unique(yte)) < 2: continue
            m = CatBoostClassifier(iterations=150, depth=3, learning_rate=0.03,
                                   l2_leaf_reg=20, verbose=0, allow_writing_files=False)\
                .fit(pd.concat([tr[feats], tr[CAT]], axis=1), ytr, cat_features=CAT)
            pr = m.predict_proba(pd.concat([te[feats], te[CAT]], axis=1))[:, 1]
            res.append(dict(horizon=h, jeu=jeu, bloc=f'{t0[:7]}→{t1[:7]}',
                            n_test=len(te), AUC=roc_auc_score(yte, pr),
                            Brier=brier_score_loss(yte, pr), cal_pente=pente(yte, pr)))

R = pd.DataFrame(res)
R.to_csv('resultats_vacances.csv', index=False)
A = R.groupby(['horizon', 'jeu']).agg(blocs=('AUC', 'size'), AUC=('AUC', 'mean'),
                                      Brier=('Brier', 'mean'), cal_pente=('cal_pente', 'mean')).round(4)
print(A.to_string())
print()
print('=== ECART D AUC, PAR HORIZON ===')
for h in [90, 60, 30, 15, 7, 3]:
    a = A.loc[(h, 'avec vacances'), 'AUC']; b = A.loc[(h, 'sans vacances'), 'AUC']
    s = R[R.horizon == h].pivot_table(index='bloc', columns='jeu', values='AUC')
    ec = (s['avec vacances'] - s['sans vacances'])
    print(f'  J-{h:<3} {b:.4f} -> {a:.4f}   ecart {a-b:+.4f}   '
          f'par bloc : {" ".join(f"{v:+.4f}" for v in ec)}')
