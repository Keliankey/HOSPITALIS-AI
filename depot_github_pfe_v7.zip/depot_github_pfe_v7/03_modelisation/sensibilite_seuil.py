# -*- coding: utf-8 -*-
"""Test de sensibilité au seuil d'interruption : 30, 45 et 60 jours.
Validation par blocs temporels successifs. Trois mesures par modèle :
AUC, pente de calibration, écart entre revenu à risque prédit et perte réelle."""
import sys, warnings, numpy as np, pandas as pd
warnings.filterwarnings('ignore')
import xgboost as xgb
from catboost import CatBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

REV = 65.87
HOR = [90, 60, 30, 15, 7, 3]
BORNES = ['2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']
VAC = ['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
CALC = ['ferie','veille_ferie','pont','tva_taux','taxe_sejour']
BASE = ['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa',
        'jours_depuis_remise_en_ligne','penalite_visibilite'] + CALC + VAC

C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier')
C['nuit'] = pd.to_datetime(C.date)
cal = C[['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur'] + VAC].copy()
cal.columns = ['nuit'] + CALC + VAC

def pente(y, p):
    eps = 1e-6; p = np.clip(p, eps, 1-eps)
    lo = np.log(p/(1-p))
    m = LogisticRegression(fit_intercept=True).fit(lo.reshape(-1,1), y)
    return float(m.coef_[0][0])

def charger(S):
    p = pd.read_pickle(f'panel_{S}.pkl')
    p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
    w = pd.read_pickle(f'win_{S}.pkl')
    p = p.merge(cal, on='nuit', how='left').merge(w[['code','zone']], on='code', how='left')
    p['invendu'] = 1 - p.vendu
    p['week_end'] = p.jour_semaine.isin([4,5]).astype(int)
    p['mois'] = p.nuit.dt.month
    p['zone_i'] = pd.factorize(p.zone)[0]
    return p[p.deja_vendu_a_d0 == 0].copy()

def fit_predict(nom, tr, te):
    ytr = tr.invendu.values
    if nom == 'XGBoost':
        F = BASE + ['zone_i']
        m = xgb.XGBClassifier(n_estimators=150, max_depth=3, learning_rate=.03, subsample=.7,
            colsample_bytree=.7, reg_lambda=10., min_child_weight=50,
            eval_metric='logloss', tree_method='hist').fit(tr[F], ytr)
        return m.predict_proba(te[F])[:,1]
    if nom == 'CatBoost':
        m = CatBoostClassifier(iterations=150, depth=3, learning_rate=.03, l2_leaf_reg=20,
            verbose=0, allow_writing_files=False).fit(
            pd.concat([tr[BASE], tr[['zone']]], axis=1), ytr, cat_features=['zone'])
        return m.predict_proba(pd.concat([te[BASE], te[['zone']]], axis=1))[:,1]
    if nom == 'Regression logistique':
        a = tr[BASE].fillna(tr[BASE].median()); b = te[BASE].fillna(tr[BASE].median())
        mu, sd = a.mean(), a.std() + 1e-9
        m = LogisticRegression(max_iter=2000).fit((a-mu)/sd, ytr)
        return m.predict_proba((b-mu)/sd)[:,1]
    raise ValueError(nom)

def run(S, modeles):
    d = charger(S); res = []
    for nom in modeles:
        for h in HOR:
            s = d[d.horizon == h].sort_values('nuit')
            for i in range(1, len(BORNES)):
                t0, t1 = BORNES[i-1], BORNES[i]
                tr = s[s.nuit < t0]; te = s[(s.nuit >= t0) & (s.nuit < t1)]
                if len(tr) < 500 or len(te) < 200: continue
                if te.invendu.nunique() < 2 or tr.invendu.nunique() < 2: continue
                pr = fit_predict(nom, tr, te)
                y = te.invendu.values
                res.append(dict(seuil=S, modele=nom, horizon=h, bloc=f'{t0[:7]}→{t1[:7]}',
                    n_test=len(te), taux_base=round(100*y.mean(),2),
                    AUC=roc_auc_score(y, pr), pente=pente(y, pr),
                    rar=pr.sum()*REV, reel=y.sum()*REV, dernier=(i == len(BORNES)-1)))
                print(f'  {nom[:12]:12s} J-{h:<3d} {t1[:7]}  AUC {res[-1]["AUC"]:.4f}', flush=True)
    return pd.DataFrame(res)

if __name__ == '__main__':
    S = int(sys.argv[1])
    mods = sys.argv[2].split(',') if len(sys.argv) > 2 else ['XGBoost','CatBoost','Regression logistique']
    print(f'=== seuil {S} ===', flush=True)
    r = run(S, mods)
    r.to_csv(f'sensi_{S}.csv', index=False)
    print(r.groupby('modele').agg(AUC=('AUC','mean'), pente=('pente','mean')).round(4).to_string())
