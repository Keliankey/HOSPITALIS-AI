"""GFS : la meteo ameliore-t-elle la prediction, une fois la couverture complete ?

Deux configurations, parce que les familles n ont pas la meme couverture :
  A. TEMPERATURE seule — disponible depuis le 01/01/2023, donc sur TOUT le panel.
     C est le test propre : plus de sous-echantillon saisonnierement biaise.
  B. TEMPERATURE + PLUIE + VENT — disponibles depuis le 20-26/01/2024 seulement,
     donc sur le sous-echantillon couvert, avec le temoin sur le meme sous-echantillon.
"""
import numpy as np, pandas as pd, warnings
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, brier_score_loss
from catboost import CatBoostClassifier
import os
# Racine des donnees, hors depot : elles sont confidentielles et ne sont pas publiees.
# Definir la variable d environnement PFE_DONNEES, ou adapter la valeur par defaut.
DONNEES = os.environ.get('PFE_DONNEES', './donnees/')

warnings.filterwarnings('ignore')

U = DONNEES + "bruxelles_journalier_GFS.csv"
TEMP = ['temperature_2m_mean', 'temperature_2m_min', 'temperature_2m_max']
AUTRE = ['precipitation_sum', 'wind_speed_10m_mean', 'wind_speed_10m_max']

FIN_FENETRE = '2026-08-31'   # derniere nuit modelisee : dernier mois complet avant l extraction (chapitre 3, section 3.8)
p = pd.read_pickle('panel.pkl')
p = p[p.nuit <= FIN_FENETRE]
cal = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier')
cal = cal[['date', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour_eur']]
cal.columns = ['nuit', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour']
p = p.merge(cal, on='nuit', how='left')
p = p.merge(pd.read_pickle('p2w.pkl').reset_index()[['code', 'zone']], on='code', how='left')
p['invendu'] = 1 - p.vendu
p['week_end'] = p.jour_semaine.isin([4, 5]).astype(int)
p['mois'] = p.nuit.dt.month
ouv = p[p.deja_vendu_a_d0 == 0].copy()

G = pd.read_csv(U, parse_dates=['date']).rename(columns={'date': 'nuit'})

BASE = ['quantieme', 'jour_semaine', 'week_end', 'mois', 'occ_30j', 'occ_60j',
        'jours_depuis_resa', 'jours_depuis_remise_en_ligne', 'penalite_visibilite',
        'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour']
CAT = ['zone']
BORNES = ['2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']

def pente(y, prob):
    eps = 1e-6
    lo = np.log(np.clip(prob, eps, 1 - eps) / (1 - np.clip(prob, eps, 1 - eps)))
    if len(np.unique(y)) < 2: return np.nan
    return LogisticRegression(penalty=None, solver='lbfgs', max_iter=1000)\
        .fit(lo.reshape(-1, 1), y).coef_[0][0]

res = []
for conf, vars_ in [('A. temperature seule', TEMP), ('B. temp + pluie + vent', TEMP + AUTRE)]:
    for h in [3, 7]:
        cols = [f'{v}_previous_day{h}' for v in vars_]
        d = ouv[ouv.horizon == h].merge(G[['nuit'] + cols], on='nuit', how='left')
        d = d.dropna(subset=cols).sort_values('nuit')
        for jeu, feats in [('sans meteo', BASE), ('avec meteo', BASE + cols)]:
            for i in range(1, len(BORNES)):
                t0, t1 = BORNES[i - 1], BORNES[i]
                tr = d[d.nuit < t0]; te = d[(d.nuit >= t0) & (d.nuit < t1)]
                if len(tr) < 500 or len(te) < 200: continue
                ytr, yte = tr.invendu.values, te.invendu.values
                if len(np.unique(ytr)) < 2 or len(np.unique(yte)) < 2: continue
                m = CatBoostClassifier(iterations=150, depth=3, learning_rate=0.03,
                                       l2_leaf_reg=20, verbose=0, allow_writing_files=False)\
                    .fit(pd.concat([tr[feats], tr[CAT]], axis=1), ytr, cat_features=CAT)
                pr = m.predict_proba(pd.concat([te[feats], te[CAT]], axis=1))[:, 1]
                res.append(dict(config=conf, horizon=h, jeu=jeu, bloc=f'{t0[:7]}→{t1[:7]}',
                                n_train=len(tr), n_test=len(te),
                                AUC=roc_auc_score(yte, pr),
                                Brier=brier_score_loss(yte, pr), cal_pente=pente(yte, pr)))

R = pd.DataFrame(res)
R.to_csv('resultats_meteo_gfs.csv', index=False)
A = R.groupby(['config', 'horizon', 'jeu']).agg(
    blocs=('AUC', 'size'), n_test=('n_test', 'sum'), AUC=('AUC', 'mean'),
    Brier=('Brier', 'mean'), cal_pente=('cal_pente', 'mean')).round(4)
print(A.to_string())
print()
for conf in R.config.unique():
    for h in [3, 7]:
        try:
            a = A.loc[(conf, h, 'avec meteo'), 'AUC']; b = A.loc[(conf, h, 'sans meteo'), 'AUC']
            n = int(A.loc[(conf, h, 'avec meteo'), 'n_test'])
            print(f'  {conf:24s} J-{h} : AUC {b:.4f} -> {a:.4f}  ecart {a-b:+.4f}  (n test {n})')
        except KeyError:
            pass
