"""Test des deux attributs admissibles du rapport plateforme (instantane du 22/02/2026).
Seules les colonnes Id Listing, note moyenne et rang equipements sont lues.
Sous-echantillon : nuits ouvertes, d0 >= 2026-02-22, 32 annonces, fenetre <= 2026-08-31.
Decoupage temporel 70/30 sur la date de nuit ; IC 95 % par bootstrap en grappes (annonce)."""
import os, numpy as np, pandas as pd, xgboost as xgb, warnings
from sklearn.metrics import roc_auc_score
warnings.filterwarnings('ignore'); rng = np.random.default_rng(0)
VAC = ['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE = ['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa',
        'jours_depuis_remise_en_ligne','penalite_visibilite','ferie','veille_ferie','pont','tva_taux','taxe_sejour']
FEAT = BASE + VAC + ['zone_i']; ATT = ['note_moyenne','rang_equipements']
INSTANTANE = pd.Timestamp('2026-02-22')

raw = pd.read_excel(os.environ.get('RAPPORT_PLATEFORME', 'rapport_plateforme.xlsx'),
                    sheet_name='Raw Data',
                    usecols=['Id Listing','listing_avg_guest_rating_of_reviewed_stays_published_lifetime','Rank Amenities'])
raw.columns = ['logement_id','note_moyenne','rang_equipements']
raw = raw.drop_duplicates('logement_id')   # une annonce figure sur 2 lignes (2 types de jour)
raw['note_moyenne'] = raw.note_moyenne.astype(str).str.replace('★','').astype(float)
res = pd.read_pickle('res.pkl')[['logement_id','code']].drop_duplicates()
att = raw.merge(res, on='logement_id')[['code'] + ATT]          # plus aucun identifiant plateforme

p = pd.read_pickle('panel.pkl')

p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier'); C['date'] = pd.to_datetime(C.date)
cal = C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur'] + VAC]
cal.columns = ['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour'] + VAC
p = p.merge(cal, on='nuit', how='left')
p = p.merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']], on='code', how='left')
p['invendu'] = 1 - p.vendu; p['week_end'] = p.jour_semaine.isin([4,5]).astype(int); p['mois'] = p.nuit.dt.month
p['zone_i'] = pd.factorize(p.zone)[0]
ouv = p[p.deja_vendu_a_d0 == 0]

# couverture : part des lignes du panel licites pour ces attributs
cov = []
for h, g in p.groupby('horizon'):
    cov.append(dict(horizon=h, lignes=len(g), licites=int(((g.d0 >= INSTANTANE) & g.code.isin(att.code)).sum())))
cov = pd.DataFrame(cov); cov['part_pct'] = (100*cov.licites/cov.lignes).round(1)

def fit(tr, te, cols):
    m = xgb.XGBClassifier(n_estimators=150, max_depth=3, learning_rate=0.03, subsample=0.7,
                          colsample_bytree=0.7, reg_lambda=10.0, min_child_weight=50,
                          eval_metric='logloss', tree_method='hist', random_state=0)
    return m.fit(tr[cols], tr.invendu).predict_proba(te[cols])[:, 1]

out, ic = [], []
for h in [90, 60, 30, 15, 7, 3]:
    d = ouv[(ouv.horizon == h) & (ouv.d0 >= INSTANTANE)].merge(att, on='code').sort_values('nuit')
    cut = d.nuit.quantile(0.7); tr, te = d[d.nuit <= cut], d[d.nuit > cut]
    p0, p1 = fit(tr, te, FEAT), fit(tr, te, FEAT + ATT); y = te.invendu.values
    a0, a1 = roc_auc_score(y, p0), roc_auc_score(y, p1)
    out.append(dict(horizon=h, n_train=len(tr), n_test=len(te), auc_base=a0, auc_avec_attributs=a1, ecart=a1-a0))
    codes = te.code.values; uc = np.unique(codes); grp = {c: np.where(codes == c)[0] for c in uc}; diffs = []
    for _ in range(2000):
        ix = np.concatenate([grp[c] for c in rng.choice(uc, len(uc), replace=True)])
        if y[ix].min() == y[ix].max(): continue
        diffs.append(roc_auc_score(y[ix], p1[ix]) - roc_auc_score(y[ix], p0[ix]))
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    ic.append(dict(horizon=h, ecart=a1-a0, ic_bas=lo, ic_haut=hi, n_annonces=len(uc)))
    print(f'J-{h}: train {len(tr)} test {len(te)} AUC {a0:.4f} -> {a1:.4f} ecart {a1-a0:+.4f} IC [{lo:+.3f};{hi:+.3f}] annonces {len(uc)}')

pd.DataFrame(out).to_csv('resultats_attributs_airbnb.csv', index=False)
pd.DataFrame(ic).to_csv('ic_attributs_airbnb.csv', index=False)
cov.to_csv('couverture_attributs_airbnb.csv', index=False)
print(cov.to_string(index=False))
# correlation au niveau annonce
w = ouv[(ouv.d0 >= INSTANTANE) & (ouv.horizon == 3)].groupby('code').invendu.mean().rename('inv')
from scipy import stats
a = att.set_index('code').join(w, how='inner').dropna()
for c in ATT:
    r, pv = stats.pearsonr(a[c], a.inv); s, ps = stats.spearmanr(a[c], a.inv)
    print(f'{c}: r={r:+.3f} p={pv:.3f} | rho={s:+.3f} p={ps:.3f} | n={len(a)}')
print('ecart moyen', round(pd.DataFrame(out).ecart.mean(), 4))
