"""Les trois livrables manquants : courbes de decision, valeurs de Shapley,
valorisation monetaire du revenu a risque.

Modele final : CatBoost regularise + calendrier + vacances scolaires.
Population : nuits encore ouvertes a la date d observation.
Validation : blocs temporels successifs ; les sorties portent sur le DERNIER bloc,
celui qui simule l usage reel (predire 2026 avec ce qu on savait avant mars 2026).
"""
import numpy as np, pandas as pd, warnings, json
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')

VAC = ['vac_fwb', 'vac_flandre', 'vac_les_deux', 'vac_une_seule',
       'vac_fwb_jour', 'vac_flandre_jour']
BASE = ['quantieme', 'jour_semaine', 'week_end', 'mois', 'occ_30j', 'occ_60j',
        'jours_depuis_resa', 'jours_depuis_remise_en_ligne', 'penalite_visibilite',
        'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour']
FEAT = BASE + VAC
CAT = ['zone']
HOR = [90, 60, 30, 15, 7, 3]

FIN_FENETRE = '2026-08-31'   # derniere nuit modelisee : dernier mois complet avant l extraction (chapitre 3, section 3.8)
p = pd.read_pickle('panel.pkl')
p = p[p.nuit <= FIN_FENETRE]
C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier')
C['date'] = pd.to_datetime(C.date)
cal = C[['date', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour_eur'] + VAC]
cal.columns = ['nuit', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour'] + VAC
p = p.merge(cal, on='nuit', how='left')
p = p.merge(pd.read_pickle('p2w.pkl').reset_index()[['code', 'zone']], on='code', how='left')
p['invendu'] = 1 - p.vendu
p['week_end'] = p.jour_semaine.isin([4, 5]).astype(int)
p['mois'] = p.nuit.dt.month
ouv = p[p.deja_vendu_a_d0 == 0].copy()

# --- revenu par nuit, mesure sur le parc -------------------------------------
b = pd.read_pickle('p2.pkl')
b['net'] = b['Gross earnings'] - b['Cleaning fee']
REV = round(float(b.net.sum() / b.nuits.sum()), 2)     # revenu net par nuit vendue
print(f'Revenu net moyen par nuit vendue : {REV} EUR '
      f'({int(b.nuits.sum())} nuits, {round(float(b.net.sum()),2)} EUR)')

COUPE = '2026-03-01'          # dernier bloc : apprentissage avant, test apres

def net_benefit(y, prob, pt):
    """Benefice net de Vickers & Elkin. y = 1 si la nuit restera invendue."""
    n = len(y)
    trait = prob >= pt
    tp = np.sum(trait & (y == 1)); fp = np.sum(trait & (y == 0))
    return tp / n - (fp / n) * (pt / (1 - pt))

SEUILS = np.round(np.arange(0.05, 0.96, 0.05), 2)
courbes, shap_rows, euros, perf = [], [], [], []

for h in HOR:
    d = ouv[ouv.horizon == h].sort_values('nuit')
    tr = d[d.nuit < COUPE]; te = d[d.nuit >= COUPE]
    if len(tr) < 500 or len(te) < 200: continue
    Xtr = pd.concat([tr[FEAT], tr[CAT]], axis=1)
    Xte = pd.concat([te[FEAT], te[CAT]], axis=1)
    ytr, yte = tr.invendu.values, te.invendu.values
    m = CatBoostClassifier(iterations=150, depth=3, learning_rate=0.03, l2_leaf_reg=20,
                           verbose=0, allow_writing_files=False).fit(Xtr, ytr, cat_features=CAT)
    pr = m.predict_proba(Xte)[:, 1]
    perf.append(dict(horizon=h, n_test=len(te), taux_base=round(100*yte.mean(), 1),
                     AUC=round(roc_auc_score(yte, pr), 4)))

    # --- 1. courbes de decision ---------------------------------------------
    for pt in SEUILS:
        courbes.append(dict(horizon=h, seuil=pt,
                            modele=net_benefit(yte, pr, pt),
                            tout_remiser=net_benefit(yte, np.ones(len(yte)), pt),
                            rien_remiser=0.0))
    # regle uniforme reelle : remise a J-14 => actif a J-3 et J-7 seulement
    for pt in SEUILS:
        regle = np.ones(len(yte)) if h <= 14 else np.zeros(len(yte))
        courbes[-len(SEUILS) + list(SEUILS).index(pt)]['regle_J14'] = \
            net_benefit(yte, regle, pt)

    # --- 2. valeurs de Shapley ----------------------------------------------
    sv = m.get_feature_importance(type='ShapValues',
                                  data=__import__('catboost').Pool(Xte, yte, cat_features=CAT))
    imp = np.abs(sv[:, :-1]).mean(axis=0)
    for nom, v in zip(list(Xte.columns), imp):
        shap_rows.append(dict(horizon=h, variable=nom, shap_abs_moyen=round(float(v), 5)))

    # --- 3. valorisation monetaire ------------------------------------------
    # revenu a risque = P(invendu) x revenu net d une nuit vendue
    rar = pr * REV
    euros.append(dict(horizon=h, n_nuits=len(te),
                      revenu_a_risque_total=round(float(rar.sum()), 0),
                      revenu_a_risque_moyen=round(float(rar.mean()), 2),
                      perte_reelle=round(float(yte.sum() * REV), 0),
                      ecart_pct=round(100 * (rar.sum() - yte.sum() * REV) / (yte.sum() * REV), 1)))

P = pd.DataFrame(perf); D = pd.DataFrame(courbes)
S = pd.DataFrame(shap_rows); E = pd.DataFrame(euros)
D.to_csv('courbes_decision.csv', index=False)
S.to_csv('shap_importance.csv', index=False)
E.to_csv('revenu_a_risque.csv', index=False)

print('\n=== PERFORMANCE SUR LE DERNIER BLOC ===')
print(P.to_string(index=False))
print('\n=== VALORISATION DU REVENU A RISQUE ===')
print(E.to_string(index=False))
print('\n=== TOP 8 DES VARIABLES, PAR HORIZON (|SHAP| moyen) ===')
for h in HOR:
    s = S[S.horizon == h].nlargest(8, 'shap_abs_moyen')
    print(f'  J-{h}: ' + ' | '.join(f'{r.variable} {r.shap_abs_moyen:.3f}' for r in s.itertuples()))
print('\n=== COURBE DE DECISION : le modele bat-il les regles uniformes ? ===')
for h in HOR:
    d = D[D.horizon == h]
    g = d[(d.modele > d.tout_remiser) & (d.modele > d.rien_remiser)]
    print(f'  J-{h}: modele superieur aux deux regles sur {len(g)}/{len(d)} seuils'
          + (f', de {g.seuil.min():.2f} a {g.seuil.max():.2f}' if len(g) else ''))
