"""5.4 Benefice net realise sous contrainte de capacite (Singh, Shah et Vickers, 2023).
CatBoost final, dernier bloc. Capacite : K nuits par semaine d'observation, les plus risquees d'abord."""
import numpy as np, pandas as pd, warnings
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE=['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne','penalite_visibilite','ferie','veille_ferie','pont','tva_taux','taxe_sejour']
FEAT=BASE+VAC; CAT=['zone']; HOR=[90,60,30,15,7,3]
p=pd.read_pickle('panel.pkl')
p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['date']=pd.to_datetime(C.date)
cal=C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC]; cal.columns=['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour']+VAC
p=p.merge(cal,on='nuit',how='left').merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']],on='code',how='left')
p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int); p['mois']=p.nuit.dt.month
ouv=p[p.deja_vendu_a_d0==0]; rng=np.random.default_rng(0); PT=0.45; rows=[]
def nb(tp,fp,n,pt): return tp/n-fp/n*pt/(1-pt)
for h in HOR:
    d=ouv[ouv.horizon==h].sort_values('nuit'); tr=d[d.nuit<'2026-03-01']; te=d[d.nuit>='2026-03-01'].copy()
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False).fit(pd.concat([tr[FEAT],tr[CAT]],axis=1),tr.invendu,cat_features=CAT)
    te['pr']=m.predict_proba(pd.concat([te[FEAT],te[CAT]],axis=1))[:,1]; te['sem']=te.d0.dt.to_period('W'); n=len(te); y=te.invendu.values
    sel=te.pr>=PT; base=dict(horizon=h,n=n,nb_modele_sans_contrainte=nb((sel&(y==1)).sum(),(sel&(y==0)).sum(),n,PT),nb_tout_remiser=nb(y.sum(),(1-y).sum(),n,PT))
    for K in [10,25,50]:
        s=te[te.pr>=PT].sort_values('pr',ascending=False).groupby('sem').head(K)
        tp=int(s.invendu.sum()); fp=len(s)-tp
        # tout remiser sous contrainte : K nuits tirees au hasard chaque semaine, moyenne sur 200 tirages
        r=[]
        for _ in range(200):
            z=te.groupby('sem',group_keys=False).apply(lambda g: g.sample(min(K,len(g)),random_state=int(rng.integers(1e9))))
            r.append(nb(z.invendu.sum(),len(z)-z.invendu.sum(),n,PT))
        rows.append({**base,'K':K,'nb_modele_realise':nb(tp,fp,n,PT),'nb_tout_remiser_realise':float(np.mean(r)),'nuits_traitees':len(s)})
R=pd.DataFrame(rows).round(4); R.to_csv('bn_realise.csv',index=False); print(R.to_string(index=False))
