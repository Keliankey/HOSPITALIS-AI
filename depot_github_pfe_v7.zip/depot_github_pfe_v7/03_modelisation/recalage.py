"""Correction de la sous-estimation par recalage glissant de l'ordonnee a l'origine (recalibration-in-the-large).
Pour chaque nuit du dernier bloc observee a d0, on mesure sur les 30 jours de nuits deja denouees avant d0
(meme horizon) l'ecart entre taux observe et taux predit, et on decale le logit d'autant. Point-in-time strict."""
import numpy as np, pandas as pd, warnings
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE=['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne','penalite_visibilite','ferie','veille_ferie','pont','tva_taux','taxe_sejour']
FEAT=BASE+VAC; CAT=['zone']; HOR=[90,60,30,15,7,3]
p=pd.read_pickle('panel.pkl')
p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['date']=pd.to_datetime(C.date)
cal=C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC]; cal.columns=['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour']+VAC
p=p.merge(cal,on='nuit',how='left').merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']],on='code',how='left')
p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int); p['mois']=p.nuit.dt.month
ouv=p[p.deja_vendu_a_d0==0]; lg=lambda x: np.log(np.clip(x,1e-4,1-1e-4)/(1-np.clip(x,1e-4,1-1e-4))); out=[]
for W in [30,60]:
  for h in HOR:
    d=ouv[ouv.horizon==h].sort_values('nuit').copy(); tr=d[d.nuit<'2026-03-01']
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False).fit(pd.concat([tr[FEAT],tr[CAT]],axis=1),tr.invendu,cat_features=CAT)
    d['pr']=m.predict_proba(pd.concat([d[FEAT],d[CAT]],axis=1))[:,1]
    te=d[d.nuit>='2026-03-01'].copy(); ser=d.groupby('nuit').agg(y=('invendu','sum'),p=('pr','sum'),n=('pr','size'))
    cs=ser.cumsum(); idx=cs.index
    def off(d0):
        a=idx.searchsorted(d0-pd.Timedelta(days=W)); b=idx.searchsorted(d0)   # nuits deja passees a d0
        if b-a<5: return 0.0
        y=cs.y.iloc[b-1]-(cs.y.iloc[a-1] if a>0 else 0); pp=cs.p.iloc[b-1]-(cs.p.iloc[a-1] if a>0 else 0); n=cs.n.iloc[b-1]-(cs.n.iloc[a-1] if a>0 else 0)
        return lg(y/n)-lg(pp/n)
    o=te.d0.map({k:off(k) for k in te.d0.unique()})
    te['pr2']=1/(1+np.exp(-(lg(te.pr)+o)))
    y=te.invendu.sum()
    out.append(dict(fenetre=W,horizon=h,ecart_initial=round(100*(te.pr.sum()-y)/y,1),ecart_recale=round(100*(te.pr2.sum()-y)/y,1)))
R=pd.DataFrame(out); print(R.pivot(index='horizon',columns='fenetre',values=['ecart_initial','ecart_recale']).loc[HOR]); R.to_csv('recalage.csv',index=False)
