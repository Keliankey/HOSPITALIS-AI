"""Type de bien (derive des titres d'annonce, 3 modalites) : avec / sans, CatBoost et XGBoost.
3 blocs temporels (AUC, pente) + ecart monetaire sur le dernier bloc. Fenetre <= 2026-08-31."""
import numpy as np, pandas as pd, warnings, xgboost as xgb
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
VAC = ['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE = ['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne',
        'penalite_visibilite','ferie','veille_ferie','pont','tva_taux','taxe_sejour']
FEAT = BASE + VAC; HOR = [90,60,30,15,7,3]
BORNES = ['2025-03-01','2025-09-01','2026-03-01','2026-09-01']
p = pd.read_pickle('panel.pkl')
p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier'); C['date'] = pd.to_datetime(C.date)
cal = C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur'] + VAC]
cal.columns = ['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour'] + VAC
p = p.merge(cal, on='nuit', how='left').merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']], on='code', how='left')
p = p.merge(pd.read_pickle('type_bien.pkl').rename(columns={'Code':'code'}), on='code', how='left')
p['invendu'] = 1 - p.vendu; p['week_end'] = p.jour_semaine.isin([4,5]).astype(int); p['mois'] = p.nuit.dt.month
p['zone_i'] = pd.factorize(p.zone)[0]; p['type_i'] = pd.factorize(p['type'])[0]
ouv = p[p.deja_vendu_a_d0 == 0]
def pente(y, pr):
    lo = np.log(np.clip(pr,1e-6,1-1e-6)/(1-np.clip(pr,1e-6,1-1e-6)))
    return LogisticRegression(penalty=None, max_iter=1000).fit(lo.reshape(-1,1), y).coef_[0][0]
def ajuste(mod, typ, tr, te):
    if mod == 'CatBoost':
        cat = ['zone'] + (['type'] if typ else [])
        m = CatBoostClassifier(iterations=150, depth=3, learning_rate=0.03, l2_leaf_reg=20, verbose=0,
                               allow_writing_files=False).fit(tr[FEAT+cat], tr.invendu, cat_features=cat)
        return m.predict_proba(te[FEAT+cat])[:,1]
    cols = FEAT + ['zone_i'] + (['type_i'] if typ else [])
    m = xgb.XGBClassifier(n_estimators=150, max_depth=3, learning_rate=0.03, subsample=0.7, colsample_bytree=0.7,
                          reg_lambda=10.0, min_child_weight=50, eval_metric='logloss', tree_method='hist').fit(tr[cols], tr.invendu)
    return m.predict_proba(te[cols])[:,1]
rows = []
for h in HOR:
    d = ouv[ouv.horizon == h].sort_values('nuit')   # meme ordre que final.py et comparaison.py
    for i in range(1, 4):
        t1, t2 = BORNES[i-1], BORNES[i]; tr = d[d.nuit < t1]; te = d[(d.nuit >= t1) & (d.nuit < t2)]
        for mod in ['CatBoost','XGBoost']:
            for typ in [False, True]:
                pr = ajuste(mod, typ, tr, te); y = te.invendu.values
                rows.append(dict(horizon=h, bloc=t1[:7], modele=mod, variante='avec type' if typ else 'sans type',
                                 AUC=roc_auc_score(y,pr), pente=pente(y,pr),
                                 ecart_pct=100*(pr.sum()-y.sum())/y.sum()))
    print('J-', h, 'fait', flush=True)
R = pd.DataFrame(rows); R.to_csv('resultats_type_bien.csv', index=False)
A = R.groupby(['modele','variante']).agg(AUC=('AUC','mean'), pente=('pente','mean')).round(4)
L = R[R.bloc == '2026-03'].pivot_table(index=['modele','variante'], columns='horizon', values='ecart_pct').round(1)[HOR]
A['ecart_moy_dernier_bloc'] = R[R.bloc=='2026-03'].groupby(['modele','variante']).ecart_pct.mean().round(1)
print(A); print(L)
A.join(L).to_csv('arbitrage_type_bien.csv')
