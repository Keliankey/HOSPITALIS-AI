# -*- coding: utf-8 -*-
import sys, time, warnings, numpy as np, pandas as pd
warnings.filterwarnings('ignore')
import torch, torch.nn as nn
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
torch.manual_seed(0); np.random.seed(0)

REV=65.87; HOR=[90,60,30,15,7,3]; SEQ=60; EPOCHS=12
BORNES=['2025-03-01','2025-09-01','2026-03-01','2026-09-01']
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
CALC=['ferie','veille_ferie','pont','tva_taux','taxe_sejour']
BASE=['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa',
      'jours_depuis_remise_en_ligne','penalite_visibilite']+CALC+VAC

C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['nuit']=pd.to_datetime(C.date)
cal=C[['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC].copy()
cal.columns=['nuit']+CALC+VAC

def pente(y,p):
    eps=1e-6;p=np.clip(p,eps,1-eps);lo=np.log(p/(1-p))
    return float(LogisticRegression().fit(lo.reshape(-1,1),y).coef_[0][0])

class Net(nn.Module):
    def __init__(s,n_stat,n_zone):
        super().__init__()
        s.lstm=nn.LSTM(2,24,batch_first=True); s.emb=nn.Embedding(n_zone,4)
        s.tete=nn.Sequential(nn.Linear(24+n_stat+4,32),nn.ReLU(),nn.Dropout(.2),nn.Linear(32,1))
    def forward(s,seq,stat,zone):
        _,(h,_)=s.lstm(seq)
        return s.tete(torch.cat([h[-1],stat,s.emb(zone)],1)).squeeze(1)

def run(S,timing_only=False):
    p=pd.read_pickle(f'panel_{S}.pkl'); w=pd.read_pickle(f'win_{S}.pkl')
    p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
    pe=pd.read_pickle(f'perim_{S}.pkl')
    p=p.merge(cal,on='nuit',how='left').merge(w[['code','zone']],on='code',how='left')
    p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int)
    p['mois']=p.nuit.dt.month; p['zone_i']=pd.factorize(p.zone)[0]
    d=p[p.deja_vendu_a_d0==0].copy()
    # séries d'occupation par code, indexées sur un calendrier continu
    D0=pe.nuit.min(); series={}
    for c,g in pe.groupby('code'):
        idx=((g.nuit-D0).dt.days).values
        n=int(((pe.nuit.max()-D0).days))+1
        v=np.full(n,-1.,dtype=np.float32); v[idx]=g.vendu.values
        series[c]=v
    NZ=int(d.zone_i.max())+1
    def seqs(sub):
        off=((sub.d0-D0).dt.days).values
        out=np.zeros((len(sub),SEQ,2),dtype=np.float32)
        for k,(c,o) in enumerate(zip(sub.code.values,off)):
            v=series[c]; a=max(0,o-SEQ); b=max(0,o)
            w_=v[a:b]
            if len(w_)<SEQ: w_=np.concatenate([np.full(SEQ-len(w_),-1.,dtype=np.float32),w_])
            out[k,:,0]=np.where(w_<0,0.,w_); out[k,:,1]=(w_>=0).astype(np.float32)
        return out
    res=[]
    for h in HOR:
        s=d[d.horizon==h].sort_values('nuit')
        for i in range(1,len(BORNES)):
            t0,t1=BORNES[i-1],BORNES[i]
            tr=s[s.nuit<t0]; te=s[(s.nuit>=t0)&(s.nuit<t1)]
            if len(tr)<500 or len(te)<200: continue
            if te.invendu.nunique()<2 or tr.invendu.nunique()<2: continue
            t=time.time()
            sc=StandardScaler().fit(tr[BASE].fillna(tr[BASE].median()))
            Xtr=sc.transform(tr[BASE].fillna(tr[BASE].median()))
            Xte=sc.transform(te[BASE].fillna(tr[BASE].median()))
            Str,Ste=seqs(tr),seqs(te)
            m=Net(len(BASE),NZ)
            opt=torch.optim.Adam(m.parameters(),lr=2e-3); lf=nn.BCEWithLogitsLoss()
            xs=torch.tensor(Str); xt=torch.tensor(Xtr,dtype=torch.float32)
            xz=torch.tensor(tr.zone_i.values); yy=torch.tensor(tr.invendu.values,dtype=torch.float32)
            n=len(tr); bs=512
            for ep in range(EPOCHS):
                perm=torch.randperm(n)
                for k in range(0,n,bs):
                    j=perm[k:k+bs]; opt.zero_grad()
                    loss=lf(m(xs[j],xt[j],xz[j]),yy[j]); loss.backward(); opt.step()
            m.eval()
            with torch.no_grad():
                pr=torch.sigmoid(m(torch.tensor(Ste),torch.tensor(Xte,dtype=torch.float32),
                                   torch.tensor(te.zone_i.values))).numpy()
            y=te.invendu.values
            res.append(dict(seuil=S,modele='LSTM',horizon=h,bloc=f'{t0[:7]}→{t1[:7]}',
                n_test=len(te),taux_base=round(100*y.mean(),2),AUC=roc_auc_score(y,pr),
                pente=pente(y,pr),rar=pr.sum()*REV,reel=y.sum()*REV,dernier=(i==len(BORNES)-1)))
            print(f'  LSTM J-{h:<3d} {t1[:7]}  AUC {res[-1]["AUC"]:.4f}  ({time.time()-t:.0f}s)',flush=True)
            if timing_only: return None
    return pd.DataFrame(res)

if __name__=='__main__':
    S=int(sys.argv[1])
    if len(sys.argv)>2 and sys.argv[2]=='time': run(S,True); sys.exit()
    r=run(S); r.to_csv(f'sensi_lstm_{S}.csv',index=False)
    print(r.groupby('seuil').agg(AUC=('AUC','mean'),pente=('pente','mean')).round(4).to_string())
