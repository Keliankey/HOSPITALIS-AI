"""4.5 analyse des erreurs et 5.4 contrainte de capacite. CatBoost final, dernier bloc (mars-aout 2026)."""
import numpy as np, pandas as pd, warnings
from sklearn.metrics import roc_auc_score
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE=['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne','penalite_visibilite','ferie','veille_ferie','pont','tva_taux','taxe_sejour']
FEAT=BASE+VAC; CAT=['zone']; HOR=[90,60,30,15,7,3]
p=pd.read_pickle('panel.pkl')
p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['date']=pd.to_datetime(C.date)
cal=C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC]; cal.columns=['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour']+VAC
p=p.merge(cal,on='nuit',how='left').merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']],on='code',how='left')
p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int); p['mois']=p.nuit.dt.month
ouv=p[p.deja_vendu_a_d0==0].copy()
REV=65.87; out=[]; seg=[]; cap=[]
for h in HOR:
    d=ouv[ouv.horizon==h].sort_values('nuit'); tr=d[d.nuit<'2026-03-01']; te=d[d.nuit>='2026-03-01'].copy()
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False).fit(pd.concat([tr[FEAT],tr[CAT]],axis=1),tr.invendu,cat_features=CAT)
    te['pr']=m.predict_proba(pd.concat([te[FEAT],te[CAT]],axis=1))[:,1]
    # segments
    te['jour']=np.where(te.week_end==1,'vendredi-samedi','dimanche-jeudi'); te['mois_l']=te.nuit.dt.month
    for var in ['zone','jour','mois_l']:
        for k,g in te.groupby(var):
            seg.append(dict(horizon=h,segment=var,valeur=k,n=len(g),taux_obs=round(100*g.invendu.mean(),1),taux_pred=round(100*g.pr.mean(),1),
                            ecart_pts=round(100*(g.pr.mean()-g.invendu.mean()),1),AUC=round(roc_auc_score(g.invendu,g.pr),3) if g.invendu.nunique()>1 else np.nan))
    # erreurs les plus couteuses au seuil 0.5 : faux negatifs (invendues jugees sures) et faux positifs
    s=0.5; fn=((te.pr<s)&(te.invendu==1)); fp=((te.pr>=s)&(te.invendu==0))
    out.append(dict(horizon=h,n=len(te),faux_negatifs=int(fn.sum()),faux_positifs=int(fp.sum()),
                    fn_part_weekend=round(100*te[fn].week_end.mean(),1),fp_part_weekend=round(100*te[fp].week_end.mean(),1),
                    fn_part_laeken=round(100*(te[fn].zone=='Laeken').mean(),1),base_laeken=round(100*(te.zone=='Laeken').mean(),1)))
    # capacite : la gerance ne traite que K nuits par semaine d'observation (les plus risquees)
    te['semaine']=te.d0.dt.to_period('W'); nsem=te.semaine.nunique()
    for K in [10,25,50,100]:
        sel=te.sort_values('pr',ascending=False).groupby('semaine').head(K)
        vp=int(sel.invendu.sum()); fpk=len(sel)-vp
        cap.append(dict(horizon=h,K_par_semaine=K,nuits_traitees=len(sel),semaines=nsem,precision=round(100*vp/len(sel),1),
                        invendues_ciblees=vp,part_des_invendues=round(100*vp/te.invendu.sum(),1),taux_base=round(100*te.invendu.mean(),1)))
pd.DataFrame(seg).to_csv('erreurs_segments.csv',index=False); pd.DataFrame(out).to_csv('erreurs_types.csv',index=False); pd.DataFrame(cap).to_csv('capacite.csv',index=False)
S=pd.DataFrame(seg); print(S[S.segment!='mois_l'].to_string(index=False)); print(S[S.segment=='mois_l'].pivot(index='valeur',columns='horizon',values='ecart_pts'))
print(pd.DataFrame(out).to_string(index=False)); print(pd.DataFrame(cap).to_string(index=False))
