# I.A explicable (xAI) pour anticiper l’inoccupation et le revenu à risque : code du mémoire

Code source accompagnant le mémoire de fin d'études du MSc *Artificial Intelligence for Business*, aivancity.

**Sujet.** « I.A explicable (xAI) pour anticiper l’inoccupation et le revenu à risque : conception et évaluation d’un système prédictif multi-horizon pour les locations de courte durée à Bruxelles ».

---

## ⚠️ Ce dépôt ne contient aucune donnée, et c'est délibéré

Les données d'exploitation sont **confidentielles** et couvertes par une autorisation d'usage strictement académique. Aucun fichier de données n'est publié ici : ni réservations, ni revenus, ni identifiants d'annonce, ni nom de bien.

Le `.gitignore` exclut explicitement tous les formats de données. **Vérifiez-le avant chaque commit.**

Les scripts de **préparation des données brutes** ne figurent pas non plus dans ce dépôt. Ils sont soudés aux fichiers sources et en portent les identifiants : noms de biens, libellés de comptes, intitulés de feuilles. Ils font partie de l'annexe confidentielle remise au jury, pas de la publication. Ce qu'ils font est décrit au chapitre Méthodologie ; ce qui est publié ici commence à la construction du panel, c'est-à-dire là où la méthode devient reproductible indépendamment des données.

---

## Ce que le dispositif fait

Prédire, pour chaque nuit d'un parc de locations de courte durée et à six horizons (J-90, J-60, J-30, J-15, J-7, J-3), la probabilité qu'elle reste invendue : puis la convertir en euros, et en décision de remise.

Trois contraintes structurent tout le code :

1. **Point-in-time strict.** À l'horizon J-*h*, seule l'information disponible *h* jours avant la nuit entre dans la matrice d'attributs. Deux contrôles d'intégrité le vérifient sur toutes les lignes du panel. La fenêtre modélisée s'arrête au 31 août 2026 (constante FIN_FENETRE).
2. **Cible fixe.** Le dénouement d'une nuit est identique aux six horizons ; seules les matrices d'attributs changent.
3. **Validation par blocs temporels successifs**, jamais par découpage aléatoire : le script `03_modelisation/comparaison.py` mesure l'écart entre les deux.

---

## Correspondance avec le mémoire

| Version du mémoire | Scripts qui produisent ses chiffres |
|---|---|
| Version déposée le 4 octobre 2026 (88 pages) | `03_modelisation` et `06_relecture` (découpage initial) |
| Version corrigée et chiffres présentés en soutenance | `07_protocole_corrige` |

L'annexe B de la version déposée désigne ce code sous le nom d'archive `depot_github_pfe_v4` ; le présent dépôt le contient intégralement, complété par les scripts de relecture (`06_relecture`) et par le protocole corrigé (`07_protocole_corrige`).

## Protocole corrigé (5 octobre 2026) : c'est lui qui produit les chiffres présentés en soutenance

Une relecture externe a montré que la première version découpait l'apprentissage sur la seule date de la nuit : le modèle d'un bloc apprenait des dénouements encore inconnus à la date de décision (jusqu'à 47,9 % des observations à J-90 du dernier bloc). Le dossier `07_protocole_corrige` applique la règle de disponibilité des cibles : pour chaque bloc et chaque horizon *h*, l'apprentissage ne retient que les nuits antérieures au début du bloc diminué de *h*. Il retire aussi les variables fiscales (TVA, taxe de séjour), donne la zone à la régression logistique, estime le revenu de référence sur le passé seulement et rejoue la capacité jour par jour.

**Reproduire les résultats depuis le panel livré** (fichiers confidentiels remis au jury, à placer dans le dossier `07_protocole_corrige`) :

```
panel.pkl  perim.pkl  p2w.pkl  Calendrier_exogene_v2.xlsx  sejours_pseudonymises.csv
evenements.xlsx  type_bien.pkl
```

Les panels reconstruits pour les seuils de 30 et 60 jours (`panel_30.pkl`, `perim_30.pkl`, `win_30.pkl` et leurs équivalents à 60 jours), nécessaires à `sensi_30_v6.py` et `sensi_60_v6.py`, sont fournis au jury sur demande en raison de leur taille ; le seuil de 45 jours correspond au panel principal.

puis, dans cet ordre :

```
python protocole_v6.py      # 4 modeles + reference naive, 3 blocs x 6 horizons, intervalles (chapitre 4, annexe C.5, C.7)
python recalibration_v6.py  # recalibration temporelle (section 4.4)
python calib_ic_v6.py       # intervalles des mesures de calibration (annexe C.5)
python decision_v6.py       # tableau 5.1, courbes de decision, capacite quotidienne, rejeu du prototype (chapitre 5)
python shap_v6.py           # valeurs de Shapley (section 6.1)
python exogenes_v6.py       # familles exogenes, fiscalite, evenements (tableau 4.4)
python sensi_45_v6.py       # idem pour 30 et 60 : sensibilite au seuil d'interruption (annexe C.1)
python type_bien_v6.py ; python aleatoire_v6.py ; python fuite_seeds_v6.py ; python sans_plages_v6.py ; python annexe_c_v6.py
python figures_v6.py ; python fig_blocs_v6.py
```

**Reconstruire le panel depuis les extractions brutes** (`01_panel`) exige des fichiers et des scripts de préparation couverts par l'autorisation d'exploitation (identifiants d'annonce, libellés) ; ils ne sont pas dans ce dépôt. Les scripts de `03_modelisation` et `06_relecture` sont conservés pour l'historique : ils utilisent le découpage initial.

## Ordre d'exécution

```
01_panel/lags.py            construit le panel bien × nuit × horizon, variables retardées
01_panel/export.py          exporte le panel et ses neuf contrôles d'intégrité
01_panel/type_bien.py       type de bien déduit du libellé (seuls le code et le type sont écrits)

02_exogene/exo.py                   squelette du calendrier : fériés, ponts, régime fiscal
02_exogene/vacances.py              vacances scolaires des deux communautés
02_exogene/irm.py                   extraction des bilans climatiques IRM
02_exogene/irm_export.py            mise en forme, avec la règle d'admissibilité
02_exogene/meteo_previous_runs.py   archive de prévisions Open-Meteo (point-in-time)
02_exogene/meteo_build.py           filtrage des colonnes admissibles

03_modelisation/model_reg.py    entraînement, validation par blocs, calibration
03_modelisation/meteo_test2.py  la météo améliore-t-elle la prédiction ? (non)
03_modelisation/vac_test.py     les vacances scolaires ? (oui, et le gain croît avec l'horizon)
03_modelisation/comparaison.py  4 modèles × 4 protocoles
03_modelisation/fuite_graines.py part de l'optimisme due à la duplication de la cible, dix tirages
03_modelisation/final.py        courbes de décision, valeurs de Shapley, valorisation en euros
03_modelisation/sensibilite_seuil.py       seuil d'interruption 30, 45, 60 jours (3 modèles)
03_modelisation/sensibilite_seuil_lstm.py  même test pour le LSTM
03_modelisation/test_type_bien.py          le type de bien améliore-t-il le modèle ? (non)
03_modelisation/test_attributs_plateforme.py  2 attributs du rapport de la plateforme (non)
03_modelisation/erreurs_capacite.py       analyse des erreurs (section 4.5) et contrainte de capacite (5.4)
03_modelisation/bn_realise.py             benefice net realise sous capacite, Singh, Shah et Vickers (2023)
03_modelisation/recalage.py               recalage glissant du niveau, exploratoire (section 6.3)

04_figures/figures.py           figures 1 à 3
04_figures/fig_protocoles.py    figure 4
04_figures/fig_modeles.py       figures 5 à 7
04_figures/fig_attributs_plateforme.py  figure du rapport de la plateforme
04_figures/fig_activite_annuelle.py     activite annuelle du parc (chapitre 1)

05_livrables/classeur_resultats.py  classeur documenté : formules, exemples, données
05_livrables/prototype_rejeu.py     scores du prototype Hospitalis AI, rejeu du dernier bloc
06_relecture/relecture_tests.py      référence naïve, intervalles de confiance par rééchantillonnage (4 octobre)
06_relecture/sans_plages.py          poids des plages d'invendu longues dans l'écart de l'été 2026
06_relecture/canal_direct.py         nuits fermées sur la plateforme, hypothèse du canal direct
06_relecture/exogenes_ablation.py    apport de chaque famille exogène, événements sous hypothèse (section 4.5)
06_relecture/sans_fiscal_corr.py     modèle sans C4 et C5, corrélations entre variables (section 6.2)
06_relecture/figures_relecture.py    courbe de réservation, blocs temporels, AUC par horizon

05_livrables/build_memoire.py        assemblage du mémoire, citations numérotées (citations_num.py)
05_livrables/maj_toc_lo.py           mise à jour de la table des matières et export PDF
```

Chaque script est autonome et lit les fichiers produits par les précédents.

## Configuration

Les scripts qui lisent des données brutes utilisent une racine unique :

```bash
export PFE_DONNEES=/chemin/vers/vos/donnees/
```

À défaut, `./donnees/` est utilisé. Aucun chemin absolu n'est codé en dur.

## Dépendances

```bash
pip install -r requirements.txt
```

`torch` n'est nécessaire que pour le volet LSTM de `comparaison.py`.

---

## Les résultats que ce code produit (protocole corrigé)

**Le revenu à risque, vérifié en euros.** `RaR = P(invendu) × R`, avec *R* le revenu hôte hors ménage par nuit vendue, estimé sur les séjours terminés avant le premier jour de décision (64,79 € pour le dernier bloc). Sur le dernier bloc (mars à août 2026), la somme des probabilités × *R* sous-estime la perte imputée aux invendus de 3,3 à 7,1 % de J-30 à J-3, et de 12,1 à 13,1 % à J-60 et J-90. C'est une vérification de calibration exprimée dans l'unité de la décision, pas une prévision de revenu.

**Les modèles.** AUC moyenne sur 3 blocs × 6 horizons : XGBoost 0,6292, CatBoost 0,6284, régression logistique (avec la zone) 0,6230, LSTM 0,6230, référence naïve 0,5933. Aucun écart d'AUC avec CatBoost n'est établi ; CatBoost est retenu pour sa calibration (ordonnée à l'origine la plus faible, meilleur score de Brier).

**La décision sous capacité.** Politique exécutable : chaque jour, seules les observations du jour ; 25 actions par semaine communes à tous les horizons ; une nuit traitée une fois. Sur 26 semaines, 83,2 % des nuits traitées restent invendues (77,5 % en traitant les nuits les plus proches) ; en se limitant aux horizons de J-15 à J-90, 68,3 % contre 61,5 % pour les annonces les moins remplies et 47,6 % au hasard.

**Ce que le protocole fait au résultat.** Le découpage aléatoire gonfle l'AUC de +0,015 (régression logistique) à +0,050 (XGBoost). La part due à la seule duplication de la cible entre horizons, mesurée sur 10 tirages, est de +0,001 à +0,006. La règle de disponibilité des cibles laisse l'AUC presque inchangée mais aggrave la sous-estimation en euros aux horizons longs.

**Ce qui a été testé et écarté.** TVA et taxe de séjour (aucun apport une fois le protocole corrigé), type de bien, attributs du rapport de la plateforme, météo, événements sous hypothèse.

## Reproductibilité

Les scripts fixent les graines aléatoires (`random_state=0`, `torch.manual_seed(0)`) et les bornes temporelles sont écrites en clair. À données identiques, les résultats le sont aussi.

Ce qui ne se reproduit pas sans les données : tout le volet empirique. Ce dépôt sert à **vérifier la méthode**, pas à refaire les chiffres.

## Sources externes et licences

| Source | Usage | Licence |
|---|---|---|
| Open-Meteo, Previous Runs API | prévisions point-in-time, J-3 et J-7 | CC BY 4.0 : attribution obligatoire |
| Institut Royal Météorologique | bilans climatiques, station d'Uccle | consultation, non redistribués |
| enseignement.be / onderwijs.vlaanderen.be | calendriers scolaires | données publiques |
| Moniteur belge, SPF Finances | ordonnances, circulaire TVA | données publiques |

## Déclaration d'usage de l'intelligence artificielle

Ce code a été écrit et exécuté par un assistant d'intelligence artificielle générative (Claude, d'Anthropic), sous la direction de l'auteur, qui a fixé les règles de construction, les protocoles et les critères d'évaluation et vérifié les résultats. Le détail par phase figure dans la déclaration et dans le journal d'usage (annexe E du mémoire).

## Licence

Code sous licence MIT. **Les données n'y sont pas soumises** : elles ne sont pas publiées et restent la propriété de leur détenteur.
