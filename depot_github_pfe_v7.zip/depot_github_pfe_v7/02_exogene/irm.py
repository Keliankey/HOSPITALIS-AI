"""Extraction des bilans climatiques IRM (station d'Uccle) en donnees tabulaires.

Ce que contiennent reellement ces documents : des agregats ANNUELS (bilans annuels)
et SAISONNIERS (bilans saisonniers), accompagnes de la normale 1991-2020 et des
records. Les valeurs MENSUELLES n'y figurent que sous forme de graphiques :
elles ne sont pas extractibles du texte et ne sont donc pas reconstituees ici.
"""
import subprocess, re, unicodedata, pandas as pd, numpy as np

import os
# Racine des donnees, hors depot : elles sont confidentielles et ne sont pas publiees.
# Definir la variable d environnement PFE_DONNEES, ou adapter la valeur par defaut.
DONNEES = os.environ.get('PFE_DONNEES', './donnees/')

U = DONNEES + 'irm/'
DOCS = [
    ('bf097b92-bilan_climatique_annuel_2023.pdf', 'annuel', '2023', '2023-01-01', '2023-12-31'),
    ('419450ee-bilan_climatique_annuel_2024.pdf', 'annuel', '2024', '2024-01-01', '2024-12-31'),
    ('eb70878b-bilan_climatique_annuel_2025.pdf', 'annuel', '2025', '2025-01-01', '2025-12-31'),
    ('6580606a-bilan_climatique_saisonnier_2026_S1.pdf', 'saisonnier', 'hiver 2026',     '2025-12-01', '2026-02-28'),
    ('e267fdee-bilan_climatique_saisonnier_2026_S2.pdf', 'saisonnier', 'printemps 2026', '2026-03-01', '2026-05-31'),
    ('f9437c30-bilan_climatique_saisonnier_2026_S3.pdf', 'saisonnier', 'ete 2026',       '2026-06-01', '2026-08-31'),
]

PARAMS = [
    'Température moyenne', 'Température maximale moyenne', 'Température minimale moyenne',
    'Nombre de jours de gel', "Nombre de jours d'hiver", "Nombre de jours d'été",
    'Nombre de jours de chaleur', 'Total des précipitations',
    'Nombre de jours de précipitations', 'Nombre de jours de neige',
    "Nombre de jours d'orage en Belgique", 'Vitesse moyenne du vent',
    "Durée d'insolation", 'Rayonnement solaire global', 'Humidité relative',
    'Tension de vapeur', 'Pression atmosphérique',
]

def norm(s):
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]', '', s.lower())

PN = {norm(p): p for p in PARAMS}

def hhmm(x):
    if isinstance(x, str) and ':' in x:
        h, m = x.split(':'); return round(int(h) + int(m) / 60, 2)
    return x

def to_num(t):
    t = t.replace(',', '.')
    if re.fullmatch(r'\d{1,4}:\d{2}', t): return hhmm(t)
    try: return float(t)
    except ValueError: return None

rows = []
for f, typ, per, d1, d2 in DOCS:
    txt = subprocess.run(['pdftotext', '-layout', U + f, '-'],
                         capture_output=True, text=True).stdout
    # la table des matieres repete les titres : on part de la DERNIERE occurrence
    # de "Bilan des valeurs", puis on s'arrete au "Records et classement" suivant.
    a = txt.rfind('Bilan des valeurs')
    b = txt.find('Records et classement', a)
    head = txt[a:b] if (a >= 0 and b > a) else txt
    for line in head.split('\n'):
        s = line.strip()
        if not s: continue
        m = re.match(r'^(.*?)\s{2,}(°C|mm|d|m/s|hh:mm|kWh/m2|%|hPa)\s{2,}(.*)$', s)
        if not m: continue
        lab, unite, reste = m.group(1).strip(), m.group(2), m.group(3)
        key = norm(lab)
        if key not in PN: continue
        toks = [t for t in re.split(r'\s{1,}', reste.strip()) if t]
        nums = [to_num(t) for t in toks]
        nums = [n for n in nums if n is not None]
        if len(nums) < 2: continue
        val, normale = nums[0], nums[1]
        # les deux derniers couples sont record+/annee et record-/annee
        rec_p = rec_pa = rec_m = rec_ma = None
        if len(nums) >= 6:
            rec_p, rec_pa, rec_m, rec_ma = nums[2], int(nums[3]), nums[4], int(nums[5])
        clas = ''.join(re.findall(r'(?<![\w.])([+]{1,3}|[-–—]{1,3})(?![\w.])', reste))
        clas = clas.replace('–', '-').replace('—', '-')   # tirets typographiques du PDF
        rows.append(dict(
            periode=per, type=typ, debut=d1, fin=d2, parametre=PN[key], unite=unite,
            origine='tableau « Bilan des valeurs »',
            valeur=val, normale_1991_2020=normale,
            anomalie=round(val - normale, 2) if (val is not None and normale is not None) else None,
            classement=clas if clas in ('+', '++', '+++', '-', '--', '---') else '',
            record_haut=rec_p, annee_record_haut=rec_pa,
            record_bas=rec_m, annee_record_bas=rec_ma))

# --- comptages de jours absents du tableau saisonnier, mais chiffres dans le TEXTE
# du bilan (valeur et normale explicites, aucune lecture de graphique).
TEXTE = [
    ('hiver 2026',     '2025-12-01', '2026-02-28', "Nombre de jours d'hiver",    'd',  2.0,  5.6),
    ('hiver 2026',     '2025-12-01', '2026-02-28', 'Nombre de jours de gel',     'd', 22.0, 29.7),
    ('printemps 2026', '2026-03-01', '2026-05-31', "Nombre de jours d'été",      'd',  9.0,  3.5),
    ('printemps 2026', '2026-03-01', '2026-05-31', 'Nombre de jours de chaleur', 'd',  2.0,  0.2),
    ('ete 2026',       '2026-06-01', '2026-08-31', "Nombre de jours d'été",      'd', 46.0, 23.9),
    ('ete 2026',       '2026-06-01', '2026-08-31', 'Nombre de jours de chaleur', 'd', 15.0,  5.0),
]
for per, d1, d2, par, unite, val, nor in TEXTE:
    rows.append(dict(
        periode=per, type='saisonnier', debut=d1, fin=d2, parametre=par, unite=unite,
        origine='texte du bilan (valeur et normale citees explicitement)',
        valeur=val, normale_1991_2020=nor, anomalie=round(val - nor, 2),
        classement='', record_haut=None, annee_record_haut=None,
        record_bas=None, annee_record_bas=None))

D = pd.DataFrame(rows)
D['ratio_a_la_normale_%'] = np.where(
    D.normale_1991_2020.abs() > 1e-9,
    (100 * D.valeur / D.normale_1991_2020).round(1), np.nan)
D.to_pickle('irm.pkl')
print(D.groupby(['type', 'periode']).size().to_string())
print()
print(D[D.parametre == 'Température moyenne'][
    ['periode', 'valeur', 'normale_1991_2020', 'anomalie', 'classement']].to_string(index=False))
print()
print(D[D.parametre == 'Total des précipitations'][
    ['periode', 'valeur', 'normale_1991_2020', 'anomalie', 'ratio_a_la_normale_%']].to_string(index=False))
print()
print('parametres captes :', D.parametre.nunique(), '| lignes :', len(D))
