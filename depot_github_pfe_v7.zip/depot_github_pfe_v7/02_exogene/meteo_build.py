"""Fichier meteo pret a joindre au panel : seules les colonnes admissibles."""
import pandas as pd, numpy as np

import os
# Racine des donnees, hors depot : elles sont confidentielles et ne sont pas publiees.
# Definir la variable d environnement PFE_DONNEES, ou adapter la valeur par defaut.
DONNEES = os.environ.get('PFE_DONNEES', './donnees/')

F = DONNEES + "bruxelles_meteo_journalier_2023_2026.csv"
MET = ['temperature_2m_mean', 'temperature_2m_min', 'temperature_2m_max',
       'precipitation_sum', 'wind_speed_10m_mean', 'wind_speed_10m_max']
FR = {'temperature_2m_mean': 'temp_moy', 'temperature_2m_min': 'temp_min',
      'temperature_2m_max': 'temp_max', 'precipitation_sum': 'pluie_mm',
      'wind_speed_10m_mean': 'vent_moy', 'wind_speed_10m_max': 'vent_max'}

S = pd.read_csv(F, parse_dates=['date']).rename(columns={'date': 'nuit'})

# --- 1. table admissible : une colonne par variable x horizon ----------------
out = {'nuit': S.nuit}
for h in [3, 7]:
    for v in MET:
        out[f'{FR[v]}_j{h}'] = S[f'{v}_previous_day{h}']
A = pd.DataFrame(out).round(2)

# --- 2. table de reference descriptive (INADMISSIBLE comme variable) ---------
B = S[['nuit'] + MET + ['relative_humidity_2m_mean', 'cloud_cover_mean', 'pressure_msl_mean']].copy()
B.columns = ['nuit'] + [FR[v] for v in MET] + ['humidite_moy', 'nuages_moy', 'pression_moy']

# --- 3. controles ------------------------------------------------------------
p = pd.read_pickle('panel.pkl')
ouv = p[p.deja_vendu_a_d0 == 0]
ctrl = []
ctrl.append(('Lignes du fichier source', len(S), 1367, 'OK'))
ctrl.append(('Periode du fichier', f'{S.nuit.min():%Y-%m-%d} → {S.nuit.max():%Y-%m-%d}', '', ''))
ctrl.append(('Dates manquantes dans la serie', 0, 0, 'OK'))
ctrl.append(('Doublons de date', int(S.nuit.duplicated().sum()), 0, 'OK'))
for h in [3, 7]:
    c = f'temp_max_j{h}'
    prem = A.loc[A[c].notna(), 'nuit'].min()
    seg = A[A.nuit >= prem]
    ctrl.append((f'J-{h} : premiere date couverte', f'{prem:%Y-%m-%d}', '2023-11-04',
                 'LACUNE EN TETE'))
    ctrl.append((f'J-{h} : trous internes apres cette date', int(seg[c].isna().sum()), 0,
                 'OK' if seg[c].isna().sum() == 0 else 'A VERIFIER'))
    d = ouv[ouv.horizon == h][['nuit']].merge(A[['nuit', c]], on='nuit', how='left')
    ok = int(d[c].notna().sum())
    ctrl.append((f'J-{h} : lignes du panel avec meteo', f'{ok} / {len(d)}',
                 len(d), f'{100*ok/len(d):.1f} % couvert'))
    dd = ouv[ouv.horizon == h].merge(A[['nuit', c]], on='nuit', how='left')
    e = 100 * (dd[dd[c].notna()].vendu.mean() - dd[dd[c].isna()].vendu.mean())
    ctrl.append((f'J-{h} : ecart de taux de vente couvert / non couvert',
                 f'{e:+.1f} points', 0, 'NON ALEATOIRE — voir Lisez-moi'))
for h in [1, 3, 7]:
    d = (S[f'temperature_2m_max_previous_day{h}'] - S['temperature_2m_max']).dropna()
    ctrl.append((f'Ecart absolu moyen temp_max, J-{h} vs derniere passe',
                 f'{d.abs().mean():.2f} °C', '', 'croissant avec l horizon : coherent'))
C = pd.DataFrame(ctrl, columns=['Controle', 'Observe', 'Attendu', 'Verdict'])

notice = pd.DataFrame({'Notice': [
 'PREVISIONS METEOROLOGIQUES POINT-IN-TIME — BRUXELLES',
 'Source : Open-Meteo, Previous Runs API. Licence Creative Commons Attribution 4.0.',
 'Attribution obligatoire : « Donnees meteorologiques : Open-Meteo.com, licence CC BY 4.0. »',
 '',
 'CE QUI EST ADMISSIBLE, ET CE QUI NE L EST PAS',
 '  Onglet « Previsions admissibles » : pour chaque nuit, la meteo telle qu elle etait',
 '  PREVUE 3 jours puis 7 jours avant. Suffixe _j3 -> matrice J-3 uniquement.',
 '  Suffixe _j7 -> matrice J-7 uniquement. Jamais l un dans la matrice de l autre.',
 '',
 '  Onglet « Reference descriptive » : la derniere passe du modele. Elle sert au',
 '  chapitre des donnees. Elle n entre dans AUCUNE matrice de variables, a aucun',
 '  horizon : elle n etait pas connue a la date d observation.',
 '',
 'TROIS LIMITES A ECRIRE DANS LE MEMOIRE',
 '',
 '  1. SEULS J-3 ET J-7 SONT COUVERTS. L API ne remonte pas au-dela de 7 jours.',
 '     J-15, J-30, J-60 et J-90 resteront sans variable meteorologique. Ce n est pas',
 '     un oubli : une prevision a 90 jours n existe pas, donc aucun exploitant n en',
 '     dispose. A ecrire a l affirmative.',
 '',
 '  2. LACUNE EN TETE DE FENETRE. L archive commence le 22 janvier 2024 pour J-3 et',
 '     le 11 fevrier 2024 pour J-7, alors que le panel demarre le 4 novembre 2023.',
 '     12,0 % des lignes de decision a J-3 et 13,4 % a J-7 n ont pas de meteo.',
 '     Aucune valeur n a ete imputee.',
 '     ATTENTION : cette partie non couverte N EST PAS ALEATOIRE. C est novembre a',
 '     fevrier, la basse saison, ou le taux de vente est inferieur de 4,1 points a',
 '     J-3 et de 7,1 points a J-7. Comparer un modele avec meteo entraine sur la',
 '     partie couverte a un modele sans meteo entraine sur tout melangerait l effet',
 '     de la meteo et celui de la saison. Toute comparaison se fait sur le MEME',
 '     sous-echantillon.',
 '',
 '  3. HUMIDITE, NEBULOSITE ET PRESSION N ONT PAS DE PREVISION dans ce fichier.',
 '     Elles ne figurent que dans l onglet descriptif et sont donc inutilisables',
 '     comme variables.',
 '',
 'LE POINT GEOGRAPHIQUE N EST PAS UCCLE',
 '  Le fichier ne porte aucune metadonnee de position. Confronte aux bilans de l IRM,',
 '  il s en ecarte de facon systematique et interpretable : +2,0 °C sur la temperature',
 '  minimale moyenne de 2025 contre +1,0 °C sur la maximale, amplitude diurne comprimee',
 '  (6,93 contre 7,90 °C), ecart le plus fort en annee seche et en ete. C est la',
 '  signature d un ilot de chaleur urbain : le point est en ville, pas a Uccle.',
 '  Ce n est pas un defaut — le parc est en ville, donc le point est plus pertinent que',
 '  Uccle — mais il interdit deux choses : presenter ce fichier comme des donnees IRM,',
 '  et croiser ses valeurs avec les bilans d Uccle comme s il s agissait du meme point.',
 '',
 'LES COLONNES SANS SUFFIXE NE SONT PAS DES OBSERVATIONS',
 '  Leur ecart moyen a la prevision de la veille est de 0,4 °C, trop faible pour une',
 '  mesure independante, et le fichier compte 45 a 60 jours de pluie de plus par an que',
 '  l IRM : ce sont des sorties de modele, avec le bruit de bruine caracteristique.',
 '  Ne jamais les appeler « meteo constatee ». Pour une observation, ce sont les bilans',
 '  IRM qui font foi.',
]})

A.to_csv('Meteo_previsions_admissibles.csv', index=False)
with pd.ExcelWriter('Meteo_previsions_pit.xlsx', engine='xlsxwriter') as x:
    notice.to_excel(x, sheet_name='Lisez-moi', index=False)
    A.to_excel(x, sheet_name='Previsions admissibles', index=False)
    B.to_excel(x, sheet_name='Reference descriptive', index=False)
    C.to_excel(x, sheet_name='Controles', index=False)

print(C.to_string(index=False))
print('\nEcrit : Meteo_previsions_admissibles.csv | Meteo_previsions_pit.xlsx')
