#!/usr/bin/env python3
"""
Archive de PREVISIONS meteorologiques point-in-time — Open-Meteo Previous Runs API.

POURQUOI CE SCRIPT EXISTE
-------------------------
Les bilans climatiques de l'IRM sont des OBSERVATIONS publiees apres coup : les
employer comme variables explicatives ferait entrer le futur dans le modele a tous
les horizons. La seule grandeur meteorologique admissible a l'horizon J-h est la
PREVISION telle qu'elle etait disponible h jours avant la nuit. C'est ce que fournit
l'API « Previous Runs » d'Open-Meteo : le suffixe _previous_dayN renvoie la valeur
qui etait predite N jours (N x 24 h) avant l'instant de validite.

CE QUE CE SCRIPT NE PEUT PAS FAIRE, ET IL FAUT LE LIRE AVANT DE LANCER
----------------------------------------------------------------------
1. N va de 0 a 7. Au-dela, l'API ne renvoie rien. Seuls J-3 et J-7 du panel sont
   donc couverts. J-15, J-30, J-60 et J-90 n'ont PAS de prevision archivee ici et
   resteront sans variable meteorologique. Ce n'est pas une limite du script : c'est
   une limite de la donnee, a ecrire dans le memoire. Aucune valeur n'est extrapolee.
2. La couverture commence en JANVIER 2024 pour la plupart des modeles. La fenetre
   d'observation demarre le 4 novembre 2023 : les deux premiers mois seront vides.
   Le script le mesure et le declare au lieu de le combler.
3. previous_day0 est la derniere passe du modele, pas une mesure. Il sert a decrire
   la fenetre, jamais comme variable explicative.

LICENCE
-------
Open-Meteo, donnees sous Creative Commons Attribution 4.0 (CC BY 4.0).
Attribution obligatoire dans le memoire : « Donnees meteorologiques : Open-Meteo.com,
Previous Runs API, licence CC BY 4.0. »

USAGE
-----
    pip install requests pandas xlsxwriter
    python3 meteo_previous_runs.py
Produit : Meteo_previsions_pit.csv, Meteo_previsions_pit.xlsx
"""

import time, sys
import requests
import pandas as pd
import numpy as np

# --- Parametres --------------------------------------------------------------
LAT, LON = 50.7997, 4.3581          # Uccle — meme point que les bilans IRM
TZ = 'Europe/Brussels'
DEBUT, FIN = '2024-01-01', '2026-09-23'   # debut = premiere date archivee par l'API
HORIZONS = [3, 7]                   # les seuls horizons du panel que l'API couvre
OFFSETS = [0] + HORIZONS            # 0 = derniere passe, pour la description seulement
VARS = ['temperature_2m', 'precipitation', 'wind_speed_10m',
        'cloud_cover', 'relative_humidity_2m']
URL = 'https://previous-runs-api.open-meteo.com/v1/forecast'
PAS = 180                           # jours par requete
PAUSE = 2                           # secondes entre requetes

# --- Telechargement ----------------------------------------------------------
champs = [f'{v}_previous_day{n}' if n else v for v in VARS for n in OFFSETS]

bornes = pd.date_range(DEBUT, FIN, freq=f'{PAS}D').tolist()
if pd.Timestamp(FIN) not in bornes:
    bornes.append(pd.Timestamp(FIN))

morceaux = []
for i in range(len(bornes) - 1):
    d1 = bornes[i].strftime('%Y-%m-%d')
    d2 = (bornes[i + 1] - pd.Timedelta(days=1 if i + 2 < len(bornes) else 0)).strftime('%Y-%m-%d')
    p = dict(latitude=LAT, longitude=LON, timezone=TZ,
             start_date=d1, end_date=d2, hourly=','.join(champs))
    print(f'  {d1} -> {d2} ...', end=' ', flush=True)
    try:
        r = requests.get(URL, params=p, timeout=120)
        r.raise_for_status()
    except Exception as e:
        print(f'ECHEC : {e}')
        print('  Le script s arrete plutot que de livrer une serie trouee sans le dire.')
        sys.exit(1)
    h = r.json().get('hourly')
    if not h:
        print('reponse sans bloc hourly :', r.text[:200]); sys.exit(1)
    morceaux.append(pd.DataFrame(h))
    print(f'{len(h["time"])} heures')
    time.sleep(PAUSE)

H = pd.concat(morceaux, ignore_index=True).drop_duplicates('time')
H['time'] = pd.to_datetime(H.time)
H['nuit'] = H.time.dt.normalize()
print(f'\n{len(H)} lignes horaires, {H.nuit.nunique()} jours.')

# --- Agregation au jour ------------------------------------------------------
# Convention : la nuit D est decrite par la meteo du jour calendaire D, jour
# d arrivee du voyageur. A declarer ; toute autre convention (18h D -> 10h D+1)
# se code ici et nulle part ailleurs.
def col(v, n):
    return f'{v}_previous_day{n}' if n else v

sorties = {}
for n in OFFSETS:
    suf = f'_j{n}' if n else '_passe0'
    g = H.groupby('nuit')
    sorties[f'temp_max{suf}']   = g[col('temperature_2m', n)].max()
    sorties[f'temp_min{suf}']   = g[col('temperature_2m', n)].min()
    sorties[f'temp_moy{suf}']   = g[col('temperature_2m', n)].mean()
    sorties[f'pluie_mm{suf}']   = g[col('precipitation', n)].sum()
    sorties[f'heures_pluie{suf}'] = g[col('precipitation', n)].apply(lambda s: (s > 0.1).sum())
    sorties[f'vent_max{suf}']   = g[col('wind_speed_10m', n)].max()
    sorties[f'nuages_moy{suf}'] = g[col('cloud_cover', n)].mean()
    sorties[f'humidite_moy{suf}'] = g[col('relative_humidity_2m', n)].mean()

D = pd.DataFrame(sorties).round(2).reset_index()

# --- Erreur de prevision : ce qui rend la variable interpretable --------------
for n in HORIZONS:
    D[f'err_temp_max_j{n}'] = (D[f'temp_max_j{n}'] - D['temp_max_passe0']).round(2)
    D[f'err_pluie_j{n}']    = (D[f'pluie_mm_j{n}'] - D['pluie_mm_passe0']).round(2)

# --- Controles ---------------------------------------------------------------
attendu = pd.date_range(DEBUT, FIN, freq='D')
ctrl = [('Jours attendus', len(attendu), len(attendu), 'OK'),
        ('Jours obtenus', D.nuit.nunique(), len(attendu),
         'OK' if D.nuit.nunique() == len(attendu) else 'LACUNE')]
for n in HORIZONS:
    manq = int(D[f'temp_max_j{n}'].isna().sum())
    ctrl.append((f'Valeurs manquantes temp_max a J-{n}', manq, 0,
                 'OK' if manq == 0 else f'{100*manq/len(D):.1f} % manquants'))
for n in HORIZONS:
    e = D[f'err_temp_max_j{n}'].dropna()
    ctrl.append((f'Erreur absolue moyenne temp_max a J-{n} (degC)',
                 round(e.abs().mean(), 2), None,
                 'plausible' if e.abs().mean() < 4 else 'A VERIFIER'))
ctrl.append(('Fenetre du panel non couverte (2023-11-04 -> 2023-12-31)',
             (pd.Timestamp('2023-12-31') - pd.Timestamp('2023-11-04')).days + 1, 0,
             'LACUNE CONNUE — API archivee a partir de janvier 2024'))
C = pd.DataFrame(ctrl, columns=['Controle', 'Observe', 'Attendu', 'Verdict'])

notice = pd.DataFrame({'Notice': [
 'PREVISIONS METEOROLOGIQUES POINT-IN-TIME — UCCLE (BRUXELLES)',
 f'Source : Open-Meteo, Previous Runs API. Point {LAT} N, {LON} E. Fuseau {TZ}.',
 'Licence Creative Commons Attribution 4.0. Attribution obligatoire dans le memoire.',
 f'Periode : {DEBUT} au {FIN}. Telecharge le ' + pd.Timestamp.today().strftime('%d/%m/%Y') + '.',
 '',
 'CE QUE CONTIENT CE FICHIER',
 '  Pour chaque nuit, la meteo TELLE QU ELLE ETAIT PREVUE 3 jours puis 7 jours avant.',
 '  Suffixe _j3  : prevision disponible a J-3.   Admissible dans la matrice a J-3.',
 '  Suffixe _j7  : prevision disponible a J-7.   Admissible dans la matrice a J-7.',
 '  Suffixe _passe0 : derniere passe du modele. DESCRIPTION SEULEMENT, jamais variable.',
 '  Colonnes err_* : ecart entre la prevision et la derniere passe. Elles mesurent la',
 '  qualite de la prevision et servent au chapitre des donnees ; elles ne sont PAS',
 '  admissibles comme variables, puisqu elles utilisent une information posterieure.',
 '',
 'LES DEUX LIMITES A ECRIRE DANS LE MEMOIRE',
 '  1. L API ne remonte qu a 7 jours. J-15, J-30, J-60 et J-90 n ont aucune prevision',
 '     archivee et resteront sans variable meteorologique. Ce n est pas un oubli : une',
 '     prevision a 90 jours n existe pas, et le delai de reservation median de 6 jours',
 '     rend la question secondaire. A dire ainsi plutot que de le laisser paraitre',
 '     comme une lacune.',
 '  2. L archive commence en janvier 2024. Du 4 novembre au 31 decembre 2023, la',
 '     fenetre du panel n est pas couverte. Aucune valeur n a ete imputee.',
 '',
 'CONVENTION D AGREGATION',
 '  La nuit D est decrite par la meteo du jour calendaire D, jour d arrivee.',
 '  Toute autre convention se recode dans la section « Agregation » du script.',
]})

D.to_csv('Meteo_previsions_pit.csv', index=False)
with pd.ExcelWriter('Meteo_previsions_pit.xlsx', engine='xlsxwriter') as x:
    notice.to_excel(x, sheet_name='Lisez-moi', index=False)
    D.to_excel(x, sheet_name='Previsions par nuit', index=False)
    C.to_excel(x, sheet_name='Controles', index=False)

print('\n=== CONTROLES ===')
print(C.to_string(index=False))
print('\nEcrit : Meteo_previsions_pit.csv et Meteo_previsions_pit.xlsx')
print("Joindre au panel sur la colonne 'nuit', et n injecter _j3 que dans la matrice")
print("J-3, _j7 que dans la matrice J-7. Aucune colonne ailleurs.")
