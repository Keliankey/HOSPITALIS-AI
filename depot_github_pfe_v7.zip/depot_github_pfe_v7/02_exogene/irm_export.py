"""Bilans climatiques IRM (Uccle) -> classeur exploitable + indicateur journalier."""
import pandas as pd, numpy as np

D = pd.read_pickle('irm.pkl')
ORD = ['2023', '2024', '2025', 'hiver 2026', 'printemps 2026', 'ete 2026']
D['periode'] = pd.Categorical(D.periode, ORD, ordered=True)
D = D.sort_values(['periode', 'parametre'])

# ---- 1. synthese : parametre x periode -------------------------------------
piv = D.pivot_table(index=['parametre', 'unite'], columns='periode',
                    values='valeur', observed=True, aggfunc='first')
nor = D.pivot_table(index=['parametre', 'unite'], columns='periode',
                    values='normale_1991_2020', observed=True, aggfunc='first')
ano = (piv - nor).round(2)
piv = piv.reset_index(); ano = ano.reset_index()

# ---- 2. vagues de chaleur : le seul signal journalier exploitable ----------
VAGUES = [
    ('2023-09-04', '2023-09-11', 'la plus tardive jamais enregistree ; premiere en septembre (mesures depuis 1892)'),
    ('2025-06-28', '2025-07-02', ''),
    ('2025-08-10', '2025-08-15', ''),
    ('2026-06-17', '2026-06-28', 'la plus longue et la plus intense de l ete 2026 ; 12 jours ; max 35,5 C le 26/06 ; min la plus elevee jamais enregistree lors d une vague : 24,1 C'),
    ('2026-07-28', '2026-08-05', '9 jours ; max 34,4 C le 29/07'),
    ('2026-08-08', '2026-08-16', '9 jours ; max 35,9 C le 14/08'),
]
V = pd.DataFrame(VAGUES, columns=['debut', 'fin', 'remarque'])
V['jours'] = (pd.to_datetime(V.fin) - pd.to_datetime(V.debut)).dt.days + 1
V = V[['debut', 'fin', 'jours', 'remarque']]

# calendrier journalier joignable au panel
jours = pd.date_range('2023-08-01', '2026-09-30', freq='D')
J = pd.DataFrame({'date': jours, 'canicule': 0})
for d1, d2, _ in VAGUES:
    J.loc[(J.date >= d1) & (J.date <= d2), 'canicule'] = 1
J['annee'] = J.date.dt.year
# saison meteorologique
sais = {12: 'hiver', 1: 'hiver', 2: 'hiver', 3: 'printemps', 4: 'printemps', 5: 'printemps',
        6: 'ete', 7: 'ete', 8: 'ete', 9: 'automne', 10: 'automne', 11: 'automne'}
J['saison'] = J.date.dt.month.map(sais)
J['couverture_irm'] = np.where(J.date <= '2026-08-31', 'oui', 'NON — bilan automne 2026 non paru')

# ---- 3. faits dates --------------------------------------------------------
FAITS = [
 ['2023', '2023-07-08', 'Temperature maximale absolue de l annee a Uccle : 32,1 C', 'bilan annuel 2023'],
 ['2023', '2023-12-02', 'Temperature minimale absolue de l annee a Uccle : -4,1 C', 'bilan annuel 2023'],
 ['2023', '2023-05-16 → 2023-06-16', 'Aucune precipitation a Uccle pendant un mois', 'bilan annuel 2023'],
 ['2023', '2023-03-08', 'Epaisseur de neige maximale a Uccle : 3,5 cm', 'bilan annuel 2023'],
 ['2023', 'novembre 2023', 'Record absolu de precipitations mensuelles a Uccle, tous mois confondus (precedent : 240,1 mm en sept. 2001)', 'bilan annuel 2023'],
 ['2024', '—', 'AUCUNE vague de chaleur officielle en 2024 (precedente annee sans vague : 2021)', 'bilan annuel 2024'],
 ['2024', '2024-03-20', 'Premiere temperature maximale >= 20 C de l annee', 'bilan annuel 2024'],
 ['2024', '2024-06-25', 'Premiere temperature maximale >= 30 C de l annee', 'bilan annuel 2024'],
 ['2024', '2024-07-09', 'Plus grand total journalier de precipitations a Uccle : 41,8 mm', 'bilan annuel 2024'],
 ['2024', '2024-11-27', 'Record absolu annuel de precipitations atteint (precedent : 1088,5 mm en 2001, mesures depuis 1833)', 'bilan annuel 2024'],
 ['2025', '2025-01-05', 'Plus grand total journalier de precipitations a Uccle : 30,4 mm', 'bilan annuel 2025'],
 ['2025', '2025-04-12', 'Premier jour d ete de 2025 (25,3 C)', 'bilan annuel 2025'],
 ['2025', '2025-06-13', 'Temperature maximale de juin : 32,7 C', 'bilan annuel 2025'],
 ['2025', '2025-10-02', 'Maximum d octobre : 18,4 C ; le mois n a pas depasse cette valeur', 'bilan annuel 2025'],
 ['hiver 2026', '2025-12-25', 'Jour de Noel le plus froid depuis 2010', 'bilan saisonnier hiver 2026'],
 ['hiver 2026', '2025-12-26', 'Minimum de la saison a Uccle : -4,6 C', 'bilan saisonnier hiver 2026'],
 ['hiver 2026', '2026-01-09', 'Plus grand total journalier de precipitations : 31,1 mm', 'bilan saisonnier hiver 2026'],
 ['hiver 2026', '2026-02-25', 'Maximum de la saison a Uccle : 19,8 C (barre des 20 C non franchie)', 'bilan saisonnier hiver 2026'],
 ['printemps 2026', '2026-03-13', 'Plus grand total journalier de precipitations : 14,0 mm', 'bilan saisonnier printemps 2026'],
 ['printemps 2026', '2026-03-27', 'Minimum de la saison a Uccle : -1,3 C', 'bilan saisonnier printemps 2026'],
 ['printemps 2026', '2026-05-21 → 2026-05-31', 'Troisieme decade de mai la plus chaude jamais enregistree', 'bilan saisonnier printemps 2026'],
 ['printemps 2026', '2026-05-29', 'Maximum de la saison a Uccle : 30,5 C', 'bilan saisonnier printemps 2026'],
 ['ete 2026', '2026-06-15', 'Minimum de la saison a Uccle : 8,6 C', 'bilan saisonnier ete 2026'],
 ['ete 2026', '2026-06-16', 'Bascule : premiere quinzaine de juin ~1 C sous la normale, puis temperatures au-dessus de la normale la majeure partie de l ete', 'bilan saisonnier ete 2026'],
 ['ete 2026', '2026-08-14', 'Maximum de la saison a Uccle : 35,9 C (record absolu : 39,7 C en 2019)', 'bilan saisonnier ete 2026'],
 ['ete 2026', 'saison', 'ETE LE PLUS CHAUD JAMAIS ENREGISTRE a Uccle (depuis 1833) : 20,3 C, premiere fois au-dessus de 20 C. 46 jours d ete, 15 jours de chaleur, 3 vagues de chaleur.', 'bilan saisonnier ete 2026'],
]
F = pd.DataFrame(FAITS, columns=['periode', 'date', 'fait', 'source'])

# ---- 4. notice -------------------------------------------------------------
notice = pd.DataFrame({'Notice': [
 "DONNEES CLIMATIQUES IRM — STATION D UCCLE (BRUXELLES)",
 "Source : Institut Royal Meteorologique de Belgique, bilans climatiques annuels 2023, 2024, 2025",
 "et bilans saisonniers hiver, printemps et ete 2026. Normales de reference : periode 1991-2020.",
 "",
 "CE QUE CES DOCUMENTS CONTIENNENT REELLEMENT",
 "  Des agregats ANNUELS et SAISONNIERS, avec la normale 1991-2020, le classement et les records.",
 "  17 parametres : temperatures moyenne / maximale / minimale, jours de gel, d hiver, d ete et de",
 "  chaleur, precipitations et jours de precipitations, neige, orages, vent, insolation, rayonnement,",
 "  humidite, tension de vapeur, pression.",
 "",
 "  La colonne ORIGINE de l onglet Detail complet distingue deux provenances. La quasi-totalite des",
 "  lignes vient du tableau « Bilan des valeurs » de chaque bilan. Six lignes viennent du TEXTE : les",
 "  bilans saisonniers ne font pas figurer les comptages de jours de gel, d hiver, d ete et de chaleur",
 "  dans leur tableau, mais les citent dans le corps du bilan avec leur normale. Ces six valeurs sont",
 "  donc des chiffres publies, pas des estimations ; aucune valeur n a ete lue sur un graphique.",
 "",
 "CE QU ILS NE CONTIENNENT PAS, ET C EST DETERMINANT",
 "  1. Aucune serie JOURNALIERE exploitable. Les valeurs journalieres et mensuelles n y figurent que",
 "     sous forme de GRAPHIQUES. Elles n ont pas ete reconstituees : lire des valeurs sur une courbe",
 "     produirait des chiffres faux presentes comme des mesures.",
 "  2. Aucune PREVISION. Ce sont des observations publiees APRES coup — le bilan de l ete 2026 est",
 "     date du 1er septembre 2026.",
 "",
 "CONSEQUENCE POUR LE MODELE — a lire avant tout usage",
 "  Une variable n est admissible a l horizon J-h que si sa valeur etait connue h jours avant la nuit.",
 "  Ces bilans sont publies apres la periode qu ils decrivent. Les utiliser comme variables explicatives",
 "  ferait donc entrer le futur dans le modele, a TOUS les horizons. C est la faute la plus courante et",
 "  la plus facile a detecter en soutenance.",
 "",
 "  TROIS USAGES LEGITIMES, ET TROIS SEULEMENT :",
 "",
 "  (a) LA NORMALE 1991-2020 est admissible a tous les horizons. Une normale climatologique est connue",
 "      des decennies a l avance : elle ne depend pas de l annee observee. C est la seule grandeur de ce",
 "      classeur qui puisse entrer dans la matrice de variables sans reserve.",
 "",
 "  (b) LES VAGUES DE CHALEUR sont datees au jour pres (onglet correspondant) et une vague est annoncee",
 "      par les previsions 3 a 7 jours a l avance. L indicateur journalier est donc defendable a J-3 et",
 "      J-7, discutable a J-15, INADMISSIBLE a J-30, J-60 et J-90. Cette regle doit etre ecrite.",
 "",
 "  (c) LA DESCRIPTION CLIMATIQUE DE LA FENETRE sert le chapitre des donnees, pas le modele. Elle",
 "      caracterise le terrain : trois annees consecutives au-dessus de la normale thermique, une annee",
 "      2024 record en precipitations, une annee 2025 seche, et un ete 2026 le plus chaud jamais",
 "      enregistre depuis 1833.",
 "",
 "LACUNE DE COUVERTURE",
 "  Le bilan de l automne 2026 n est pas paru. La periode du 1er au 22 septembre 2026, qui appartient a",
 "  la fenetre d observation, n est donc couverte par aucun document. A signaler explicitement.",
 "",
 "CE QUI RESTE HORS DE PORTEE",
 "  Pour obtenir la PREVISION telle qu elle etait disponible a J-h — la seule grandeur meteorologique",
 "  reellement utilisable aux horizons courts — il faut une archive de previsions, pas un bilan",
 "  climatique. Voir le script meteo_fetch.py.",
]})

with pd.ExcelWriter('IRM_Uccle_2023_2026.xlsx', engine='xlsxwriter') as x:
    notice.to_excel(x, sheet_name='Lisez-moi', index=False)
    piv.to_excel(x, sheet_name='Valeurs par periode', index=False)
    ano.to_excel(x, sheet_name='Anomalies vs normale', index=False)
    D.to_excel(x, sheet_name='Detail complet', index=False)
    V.to_excel(x, sheet_name='Vagues de chaleur', index=False)
    J.to_excel(x, sheet_name='Indicateur journalier', index=False)
    F.to_excel(x, sheet_name='Faits dates', index=False)

J.to_csv('irm_canicule_journalier.csv', index=False)

print('IRM_Uccle_2023_2026.xlsx ecrit')
print(' periodes :', len(ORD), '| parametres :', D.parametre.nunique(), '| lignes de detail :', len(D))
print(' vagues de chaleur :', len(V), '| jours sous canicule :', int(J.canicule.sum()))
print()
print(piv[piv.parametre.isin(['Température moyenne', 'Total des précipitations',
                              "Durée d'insolation", "Nombre de jours d'été"])].to_string(index=False))
