"""Squelette du calendrier exogene, 1 ligne par date.
Ce qui est calculable hors ligne est calcule et certifie.
Ce qui demande une source externe est laisse en colonne typee, a remplir.
"""
import pandas as pd, numpy as np

DEB, FIN = '2023-08-01', '2026-12-31'

def paques(y):
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mo = (h + l - 7 * m + 114) // 31
    da = ((h + l - 7 * m + 114) % 31) + 1
    return pd.Timestamp(y, mo, da)

def feries(y):
    p = paques(y)
    return {
        pd.Timestamp(y, 1, 1):   "Nouvel An",
        p + pd.Timedelta(days=1):  "Lundi de Paques",
        pd.Timestamp(y, 5, 1):   "Fete du Travail",
        p + pd.Timedelta(days=39): "Ascension",
        p + pd.Timedelta(days=50): "Lundi de Pentecote",
        pd.Timestamp(y, 7, 21):  "Fete nationale",
        pd.Timestamp(y, 8, 15):  "Assomption",
        pd.Timestamp(y, 11, 1):  "Toussaint",
        pd.Timestamp(y, 11, 11): "Armistice",
        pd.Timestamp(y, 12, 25): "Noel",
    }

d = pd.date_range(DEB, FIN, freq='D')
cal = pd.DataFrame({'date': d})

# --- calculable exactement -------------------------------------------------
cal['quantieme'] = cal.date.dt.dayofyear
bis = cal.date.dt.is_leap_year & (cal.date.dt.month > 2)
cal.loc[bis, 'quantieme'] -= 1                    # agnostique a l'annee (consigne Souheil)
cal['annee'] = cal.date.dt.year
cal['mois'] = cal.date.dt.month
cal['jour_semaine'] = cal.date.dt.dayofweek       # 0 = lundi
cal['semaine_iso'] = cal.date.dt.isocalendar().week.astype(int)
cal['week_end'] = cal.jour_semaine.isin([4, 5]).astype(int)   # nuits ven. et sam.

F = {}
for y in range(2023, 2027):
    F.update(feries(y))
cal['ferie'] = cal.date.map(lambda x: 1 if x in F else 0)
cal['ferie_nom'] = cal.date.map(lambda x: F.get(x, ''))
s = set(F)
cal['veille_ferie'] = cal.date.map(lambda x: 1 if (x + pd.Timedelta(days=1)) in s else 0)
# pont : jour ouvre isole entre un ferie et un week-end
cal['pont'] = [
    1 if (dw < 5 and f == 0 and
          ((dw == 0 and (dt - pd.Timedelta(days=3)) in s) or
           (dw == 4 and (dt + pd.Timedelta(days=3)) in s) or
           (dt - pd.Timedelta(days=1)) in s or (dt + pd.Timedelta(days=1)) in s))
    else 0
    for dt, dw, f in zip(cal.date, cal.jour_semaine, cal.ferie)]

# --- regime fiscal : dates fixees par le pouvoir reglementaire, connues a l'avance
cal['tva_taux'] = np.where(cal.date < '2026-03-01', 6.0, 12.0)
cal['tva_transitoire'] = ((cal.date >= '2026-03-01') & (cal.date <= '2026-06-30')).astype(int)
cal['taxe_sejour_eur'] = np.where(cal.date < '2026-01-01', 4.0, 5.0)

# --- a remplir depuis les sources externes ---------------------------------
for c in ['vac_fwb', 'vac_flandre', 'vac_fwb_nom', 'vac_flandre_nom',
          'pe_pleniere_strasbourg', 'pe_mini_pleniere_bxl', 'pe_commissions_bxl',
          'evenement_majeur', 'evenement_nom', 'evenement_jauge',
          'prev_tmax', 'prev_pluie_mm', 'prev_ensoleillement_h']:
    cal[c] = np.nan

with pd.ExcelWriter('Calendrier_exogene.xlsx', engine='xlsxwriter') as x:
    lisez = pd.DataFrame({'Notice': [
        "CALENDRIER EXOGENE — squelette, une ligne par date",
        f"Fenetre : {DEB} au {FIN} (couvre J-90 avant la premiere nuit et apres la derniere).",
        "",
        "COLONNES CERTIFIEES — calculees hors ligne, aucune source externe :",
        "  quantieme  : jour de l'annee, corrige des annees bissextiles (consigne du superviseur).",
        "  ferie      : les 10 jours feries legaux belges, Paques calculee par l'algorithme gregorien.",
        "  pont       : jour ouvre isole entre un ferie et un week-end.",
        "  week_end   : nuits du vendredi et du samedi — la nuit, pas le jour.",
        "  tva_taux, tva_transitoire, taxe_sejour_eur : dates fixees par la circulaire 2026/C/58",
        "               et par la taxe regionale. Connues a l'avance, donc admissibles a tout horizon.",
        "",
        "COLONNES A REMPLIR — voir l'onglet « Sources a collecter ». Elles sont vides :",
        "  aucune valeur n'a ete inventee. Une date non verifiee ne vaut pas mieux qu'une case vide.",
        "",
        "REGLE POINT-IN-TIME : une colonne n'est admissible a l'horizon J-h que si sa valeur",
        "etait connue h jours avant la nuit. Les calendriers scolaire, parlementaire et fiscal",
        "le sont a tous les horizons. La meteo ne l'est pas : il faut la PREVISION archivee,",
        "pas la mesure. Voir l'onglet « Sources a collecter », ligne 4.",
    ]})
    lisez.to_excel(x, sheet_name='Lisez-moi', index=False)
    cal.to_excel(x, sheet_name='Calendrier', index=False)

    src = pd.DataFrame([
        ["1. Vacances scolaires",
         "DEUX calendriers, pas un.",
         "Bruxelles est scolarisee dans les deux communautes. Depuis la reforme des rythmes de 2022-2023, "
         "le calendrier de la Federation Wallonie-Bruxelles (7 semaines de cours / 2 de conge, ete raccourci a 7 semaines) "
         "ne coincide plus avec le calendrier flamand (rentree au 1er septembre, ete du 1er juillet au 31 aout). "
         "Les fusionner en une variable unique detruit l'information. D'ou deux colonnes.",
         "FWB : enseignement.be/calendrierscolaire (PDF et ICS, annees a venir) ; annees passees au Moniteur belge. "
         "Flandre : onderwijs.vlaanderen.be, rubrique schoolvakanties."],
        ["2. Calendrier du Parlement europeen",
         "Le signe de l'effet n'est pas celui qu'on croit.",
         "Une semaine de pleniere a STRASBOURG VIDE Bruxelles : deputes, assistants et journalistes partent. "
         "L'effet attendu sur la demande bruxelloise est NEGATIF. Ce sont les semaines de commissions et de mini-plenieres "
         "a Bruxelles qui la soutiennent. Trois colonnes distinctes, donc, et pas un indicateur unique de « semaine parlementaire ».",
         "europarl.europa.eu publie le calendrier annuel des sessions. Consultation manuelle : la page des reunions "
         "de commissions interdit la collecte automatisee dans son robots.txt, et cette interdiction est respectee."],
        ["3. Salons, congres et grands evenements",
         "Renseigner la jauge, pas seulement la presence.",
         "Un congres de 300 personnes et un salon de 40 000 n'ont pas le meme effet sur un parc de quelques dizaines d'unites. "
         "Une colonne binaire les confond. Retenir la jauge annoncee, meme approximative, ou a defaut une classe de taille. "
         "Se limiter aux evenements connus plus de 90 jours a l'avance, sinon la variable est inutilisable a l'horizon long.",
         "visit.brussels (agenda professionnel), Brussels Expo (calendrier des salons), "
         "Palais 12 / Forest National / Cirque Royal pour les concerts."],
        ["4. Meteo",
         "Il faut la PREVISION archivee, pas la mesure.",
         "Utiliser la meteo constatee pour predire a J-90 fait entrer le futur dans le modele : c'est la faute "
         "la plus courante et la plus facile a detecter en soutenance. Il faut, pour chaque couple (nuit, horizon), "
         "la prevision telle qu'elle etait disponible h jours avant la nuit. Au-dela de ~15 jours, aucune prevision "
         "utile n'existe : la colonne doit alors etre vide, et ce vide est un resultat, pas un manque. "
         "L'IRM fournit des series mesurees ; pour des previsions archivees, l'API Historical Forecast d'Open-Meteo "
         "(ERA5 + archives de previsions) est la source praticable. Script pret : meteo_fetch.py.",
         "meteo.be (mesures, IRM) ; open-meteo.com/en/docs/historical-forecast-api (previsions archivees, libre)."],
    ], columns=['Source', 'Le point a ne pas rater', 'Pourquoi', 'Ou'])
    src.to_excel(x, sheet_name='Sources a collecter', index=False)

print('Calendrier_exogene.xlsx ecrit :', len(cal), 'dates,',
      int(cal.ferie.sum()), 'jours feries,', int(cal.pont.sum()), 'ponts')
print(cal[cal.ferie == 1].groupby('annee').size().to_string())
