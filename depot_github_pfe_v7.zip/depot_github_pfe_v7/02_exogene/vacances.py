"""Vacances scolaires des DEUX communautes, integrees au calendrier exogene.

POURQUOI DEUX COLONNES ET PAS UNE
Bruxelles est scolarisee dans les deux communautes. Depuis la reforme des rythmes
scolaires de 2022-2023, le calendrier de la Federation Wallonie-Bruxelles (periodes
de 7 a 8 semaines, conges de deux semaines, annee close le premier vendredi de
juillet) ne coincide plus avec le calendrier flamand (rentree au 1er septembre,
herfst- et krokusvakantie d une semaine, ete du 1er juillet au 31 aout). Les fusionner
detruirait l information : en 2025-2026 les deux communautes ne partagent qu UNE
semaine de conge de detente, celle du 16 au 22 fevrier 2026.

CONVENTION RETENUE
Les dates FWB sont ramenees au bloc COMPLET samedi -> dimanche, week-ends inclus.
Les sources de presse donnent tantot le bloc complet (2023-2024, 2024-2025), tantot
les seuls jours d ecole du lundi au vendredi (2025-2026). Pour une variable de
demande touristique, c est le bloc complet qui compte : une famille part le samedi.
Les dates flamandes sont deja publiees en blocs lundi -> dimanche.

ADMISSIBILITE
Un calendrier scolaire est arrete et publie plus d un an a l avance. Il est donc
connu a J-90 comme a J-3 : admissible a TOUS les horizons, sans reserve. C est ce
qui le distingue de la meteo, plafonnee a sept jours.

SOURCES — a citer dans le memoire, et a reverifier sur la circulaire FWB
  FWB    : enseignement.be/calendrier-scolaire (annees 2026+) ; pour 2023-2026,
           dates reprises de la presse de reference (RTBF) et recoupees entre annees.
           LA SOURCE DE DROIT EST LA CIRCULAIRE FWB DE CHAQUE ANNEE — a substituer.
  Flandre: onderwijs.vlaanderen.be / vlaanderen.be, rubrique schoolvakanties.
"""
import pandas as pd, numpy as np

# --- FWB : blocs complets samedi -> dimanche ---------------------------------
FWB = [
    ('ete 2023',            '2023-07-08', '2023-08-27'),   # rentree lundi 28/08/2023
    ('automne 2023',        '2023-10-21', '2023-11-05'),
    ('hiver 2023-2024',     '2023-12-23', '2024-01-07'),
    ('detente 2024',        '2024-02-24', '2024-03-10'),
    ('printemps 2024',      '2024-04-27', '2024-05-12'),
    ('ete 2024',            '2024-07-06', '2024-08-25'),   # rentree lundi 26/08/2024
    ('automne 2024',        '2024-10-19', '2024-11-03'),
    ('hiver 2024-2025',     '2024-12-21', '2025-01-05'),
    ('detente 2025',        '2025-02-22', '2025-03-09'),
    ('printemps 2025',      '2025-04-26', '2025-05-11'),
    ('ete 2025',            '2025-07-05', '2025-08-31'),   # rentree lundi 01/09/2025
    ('automne 2025',        '2025-10-18', '2025-11-02'),
    ('hiver 2025-2026',     '2025-12-20', '2026-01-04'),
    ('detente 2026',        '2026-02-14', '2026-03-01'),
    ('printemps 2026',      '2026-04-25', '2026-05-10'),
    ('ete 2026',            '2026-07-04', '2026-08-23'),   # rentree lundi 24/08/2026
]

# --- Flandre : blocs lundi -> dimanche, tels que publies ---------------------
VLA = [
    ('zomer 2023',          '2023-07-01', '2023-08-31'),
    ('herfst 2023',         '2023-10-30', '2023-11-05'),
    ('kerst 2023-2024',     '2023-12-25', '2024-01-07'),
    ('krokus 2024',         '2024-02-12', '2024-02-18'),
    ('pasen 2024',          '2024-04-01', '2024-04-14'),
    ('hemelvaart 2024',     '2024-05-09', '2024-05-10'),
    ('zomer 2024',          '2024-07-01', '2024-08-31'),
    ('herfst 2024',         '2024-10-28', '2024-11-03'),
    ('kerst 2024-2025',     '2024-12-23', '2025-01-05'),
    ('krokus 2025',         '2025-03-03', '2025-03-09'),
    ('pasen 2025',          '2025-04-07', '2025-04-21'),
    ('hemelvaart 2025',     '2025-05-29', '2025-05-30'),
    ('zomer 2025',          '2025-07-01', '2025-08-31'),
    ('herfst 2025',         '2025-10-27', '2025-11-02'),
    ('kerst 2025-2026',     '2025-12-22', '2026-01-04'),
    ('krokus 2026',         '2026-02-16', '2026-02-22'),
    ('pasen 2026',          '2026-04-06', '2026-04-19'),
    ('zomer 2026',          '2026-07-01', '2026-08-31'),
]

C = pd.read_excel('Calendrier_exogene.xlsx', sheet_name='Calendrier')
C['date'] = pd.to_datetime(C.date)

def pose(df, liste, col, colnom):
    df[col] = 0
    df[colnom] = pd.NA
    for nom, d1, d2 in liste:
        m = (df.date >= d1) & (df.date <= d2)
        df.loc[m, col] = 1
        df.loc[m, colnom] = nom
    return df

C = pose(C, FWB, 'vac_fwb', 'vac_fwb_nom')
C = pose(C, VLA, 'vac_flandre', 'vac_flandre_nom')

# --- variables derivees, celles qui portent le signal ------------------------
C['vac_les_deux'] = ((C.vac_fwb == 1) & (C.vac_flandre == 1)).astype(int)
C['vac_une_seule'] = ((C.vac_fwb + C.vac_flandre) == 1).astype(int)
C['vac_aucune'] = ((C.vac_fwb + C.vac_flandre) == 0).astype(int)
# jour de la periode : le premier et le dernier week-end d un conge ne valent pas
# le milieu de semaine. Un compteur le dit au modele sans qu il ait a le deviner.
def rang(df, col):
    g = (df[col] != df[col].shift()).cumsum()
    r = df.groupby(g).cumcount() + 1
    return np.where(df[col] == 1, r, 0)
C['vac_fwb_jour'] = rang(C, 'vac_fwb')
C['vac_flandre_jour'] = rang(C, 'vac_flandre')

# --- controles ---------------------------------------------------------------
ctrl = []
for lab, col in [('FWB', 'vac_fwb'), ('Flandre', 'vac_flandre')]:
    n = int(C[col].sum())
    ctrl.append((f'{lab} : jours de conge sur la fenetre', n, '', f'{100*n/len(C):.1f} % des jours'))
ctrl.append(('Jours ou les DEUX communautes sont en conge', int(C.vac_les_deux.sum()), '',
             f'{100*C.vac_les_deux.mean():.1f} %'))
ctrl.append(('Jours ou UNE SEULE l est', int(C.vac_une_seule.sum()), '',
             'c est l information que la fusion detruirait'))
ctrl.append(('Semaine commune de detente 2026 (16-22/02)',
             int(C[(C.date >= '2026-02-16') & (C.date <= '2026-02-22')].vac_les_deux.sum()), 7,
             'OK' if C[(C.date >= '2026-02-16') & (C.date <= '2026-02-22')].vac_les_deux.sum() == 7 else 'A VERIFIER'))
# aucun trou, aucun chevauchement de periodes
for lab, liste in [('FWB', FWB), ('Flandre', VLA)]:
    d = pd.DataFrame(liste, columns=['nom', 'd1', 'd2'])
    d['d1'] = pd.to_datetime(d.d1); d['d2'] = pd.to_datetime(d.d2)
    d = d.sort_values('d1')
    chev = int((d.d1.shift(-1) <= d.d2).sum())
    ctrl.append((f'{lab} : periodes qui se chevauchent', chev, 0, 'OK' if chev == 0 else 'ERREUR'))
    ctrl.append((f'{lab} : periodes declarees', len(d), '', f'{d.d1.min():%Y-%m-%d} → {d.d2.max():%Y-%m-%d}'))
K = pd.DataFrame(ctrl, columns=['Controle', 'Observe', 'Attendu', 'Verdict'])

C.to_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier', index=False)
C[['date', 'vac_fwb', 'vac_flandre', 'vac_les_deux', 'vac_une_seule',
   'vac_fwb_jour', 'vac_flandre_jour']].to_csv('Vacances_scolaires.csv', index=False)

print(K.to_string(index=False))
print()
print('=== RECOUVREMENT DES DEUX CALENDRIERS, PAR MOIS ===')
m = C[(C.date >= '2023-11-04') & (C.date <= '2026-09-23')].copy()
m['ym'] = m.date.dt.to_period('M')
t = m.groupby('ym')[['vac_fwb', 'vac_flandre', 'vac_les_deux']].sum()
print(t[t.sum(axis=1) > 0].to_string())
