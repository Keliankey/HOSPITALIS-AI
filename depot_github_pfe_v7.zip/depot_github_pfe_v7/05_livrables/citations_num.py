"""Numérotation des références : [n] dans le texte après chaque citation datée, [n] devant chaque entrée de la bibliographie."""
import re
KEYS=[('Aas',['2021']),('politique hors plateforme',None),('synchronisation des calendriers',None),('Alharbi',['2023']),('Bergmeir',['2012']),('Carriero',['2025']),('Casamatta',['2022']),('Chawla',['2002']),
('Chen',['2016']),('Chernozhukov',['2018']),('Deboosere',['2019']),('Distelmans',['2025']),('Endrich',['2022']),
('Giannoni',['2023']),('Giannoni',['2021']),('Gibbs',['2018']),('Grinsztajn',['2022']),
('Hevner',['2004']),('Hochreiter',['1997']),('Inside Airbnb',['2026']),('Kalehbasti',['2021']),('Ke',['2017']),('Kourentzes',['2019']),
('Littlewood',['1972','2005']),('Lundberg',['2017']),('Oskam',['2018']),('Peffers',['2007']),('Prokhorenkova',['2018']),('Queenan',['2007']),
('ordonnance du 8 mai 2014',['2014']),('ordonnance du 1er février 2024',['2024']),('Rental Ninja',None),('arrêté royal du 14 février 2026',['2026']),
('Rudin',['2019']),('2026/C/58',['2026']),('Singh',['2023']),('Smith',['1992']),('Talluri',['2004']),('Braak',['2024']),
('Van Calster|van Calster',['2019']),('Goorbergh',['2022']),('Vickers',['2006']),('Weatherford',['2003']),('Wilson',['2001']),('Ye',['2018']),
('Young',['1985']),('Zhu',['2022'])]
def numerote(chapitres, refs_md):
    entries=[r for r in refs_md.split('\n\n') if r.strip() and not r.lstrip().startswith('#')]
    assert len(entries)==len(KEYS), (len(entries),len(KEYS))
    cited=set(); out=[]
    nm=[k for k,_ in KEYS]; i_ar=nm.index('arrêté royal du 14 février 2026'); i_ci=nm.index('2026/C/58'); i_ia=nm.index('Inside Airbnb')
    paren=re.compile(r'\(([^()]*)\)')
    for txt in chapitres:
        res=[]; last=0
        for m in paren.finditer(txt):
            inner=m.group(1); yrs=re.findall(r'\b(1[89]\d\d|20[0-2]\d)\b',inner)
            win=txt[max(0,m.start()-220):m.start()]+' '+inner
            # citations multiples dans la parenthèse : (Auteur, année ; Auteur, année)
            inside=[]
            for i,(k,ys) in enumerate(KEYS):
                if ys is None: continue
                for h in re.finditer(r'(?<![\w-])(?:'+k+r')(?![\w])[^;]*?\b('+'|'.join(ys)+r')\b',inner):
                    if i==14 and 'Yao' not in inner: pass
                    inside.append((h.start(),i))
            if inside:
                ids=[]
                for _,i in sorted(inside):
                    if i not in ids: ids.append(i)
                after=txt[m.end():m.end()+3]
                if not after.startswith(' ['):
                    res.append(txt[last:m.end()]+' ['+', '.join(str(i+1) for i in ids)+']'); last=m.end(); cited.update(ids)
                continue
            best=None; bestpos=-1
            for i,(k,ys) in enumerate(KEYS):
                if ys is None:
                    if re.search(k,inner): pos=10**6
                    else: continue
                else:
                    if not any(y in yrs for y in ys): continue
                    hits=[h.end() for h in re.finditer(r'(?<![\w-])(?:'+k+r')(?![\w])',win)]
                    if not hits: continue
                    pos=hits[-1]
                if pos>bestpos: best,bestpos=i,pos
            if best is None: continue
            after=txt[m.end():m.end()+3]
            if after.startswith(' ['): continue
            res.append(txt[last:m.end()]+f' [{best+1}]'); last=m.end(); cited.add(best)
        res.append(txt[last:]); txt=''.join(res)
        # mentions sans parenthèse datée : première occurrence
        for i,k in [(i_ar,'arrêté royal du 14 février 2026'),(i_ci,'circulaire 2026/C/58 du 29 avril 2026'),(i_ia,'Inside Airbnb, initiative indépendante')]:
            mm=re.search(re.escape(k),txt)
            if mm and f'[{i+1}]' not in txt[mm.end():mm.end()+6]:
                txt=txt[:mm.end()]+f' [{i+1}]'+txt[mm.end():]; cited.add(i)
        out.append(txt)
    biblio=refs_md.split('\n\n')[0]+'\n\n'+'\n\n'.join(f'[{i+1}] '+e.strip() for i,e in enumerate(entries))
    return out, biblio, cited, entries
