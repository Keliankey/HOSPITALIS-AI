import uno, sys, time, subprocess
from com.sun.star.beans import PropertyValue
def P(n,v): p=PropertyValue(); p.Name=n; p.Value=v; return p
src, out_docx, out_pdf = sys.argv[1:4]
proc=subprocess.Popen(['soffice','--headless','--norestore','--accept=socket,host=localhost,port=2002;urp;'])
ctx=None
for _ in range(40):
    try:
        local=uno.getComponentContext(); res=local.ServiceManager.createInstanceWithContext('com.sun.star.bridge.UnoUrlResolver',local)
        ctx=res.resolve('uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext'); break
    except Exception: time.sleep(1)
desk=ctx.ServiceManager.createInstanceWithContext('com.sun.star.frame.Desktop',ctx)
doc=desk.loadComponentFromURL(uno.systemPathToFileUrl(src),'_blank',0,(P('Hidden',True),))
idx=doc.getDocumentIndexes()
for i in range(idx.getCount()): idx.getByIndex(i).update()
doc.refresh()
for i in range(idx.getCount()): idx.getByIndex(i).update()
doc.storeToURL(uno.systemPathToFileUrl(out_docx),(P('FilterName','MS Word 2007 XML'),))
doc.storeToURL(uno.systemPathToFileUrl(out_pdf),(P('FilterName','writer_pdf_Export'),))
print('indexes:',idx.getCount())
doc.close(True)
try: desk.terminate()
except Exception: pass
proc.wait(timeout=30)
