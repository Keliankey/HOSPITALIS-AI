"""Assemble le mémoire, produit le Word (table des matières à points de suite et liens,
numéros de page en bas à droite) puis met à jour la table avec LibreOffice et exporte le PDF."""
import re, subprocess, zipfile, shutil, os, sys
os.chdir(os.environ.get('DOSSIER_MEMOIRE', os.path.dirname(os.path.abspath(__file__))))
A="[À rédiger par l'auteur.]"
TOC=r"""```{=openxml}
<w:p><w:pPr><w:pStyle w:val="TOCHeading"/><w:pageBreakBefore/></w:pPr><w:r><w:t>Table des matières</w:t></w:r></w:p><w:p><w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve">TOC \o "1-2" \h \z \u</w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>Clic droit, puis Mettre à jour les champs.</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>
```"""
def P(txt,before=0,after=160,sz=24):
    return (f'<w:p><w:pPr><w:spacing w:before="{before}" w:after="{after}" w:line="276" w:lineRule="auto"/><w:ind w:left="0" w:right="0" w:firstLine="0"/><w:jc w:val="center"/></w:pPr>'
            f'<w:r><w:rPr><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos" w:cs="Aptos"/><w:sz w:val="{sz}"/></w:rPr><w:t xml:space="preserve">{txt}</w:t></w:r></w:p>')
titre="« I.A explicable (xAI) pour anticiper l’inoccupation et le revenu à risque : conception et évaluation d’un système prédictif multi-horizon pour les locations de courte durée à Bruxelles »"
front=("```{=openxml}\n"+P('',before=3600,after=0)+"\n```\n\n![](media/logo-aivancity.png){width=6.2cm}\n\n```{=openxml}\n"
 +P('CASTLE LINE SRL – HOSPITALIS AI',before=240,after=1400)+P("Projet de fin d’études",after=200)+P(titre,after=2000)
 +P('Master of Science Artificial Intelligence for Business')+P('Promotion 2026')+P('Kelian SUAMI')+P('Professeur superviseur : Dr. Souheil HANOUNE')+"\n```\n")
ref=open('resultats-reference-31-aout.md').read()
import annexe_c_v6 as AC
sec7=AC.tab_c1(); NOTE_C1=AC.NOTE_C1
assert sec7 is not None, 'tests de sensibilite v6 manquants'
NOTE_C2=("Note. Ce test porte sur le sous-ensemble des 32 annonces couvertes par le rapport de la plateforme. Les aires sous la courbe y sont plus élevées que dans le panel complet "
 "parce que la population diffère, et seul l'écart entre les 2 colonnes est interprétable. Il a été conduit avec le découpage initial, avant la règle de disponibilité des cibles de la section 3.6.")
TAB_C4=AC.tab_c4(); NOTE_C4=AC.NOTE_C4; TAB_C5=AC.TAB_C5; NOTE_C5=AC.NOTE_C5
att=ref[ref.index("| Horizon | AUC sans |"):ref.index("Aucun gain.")]
typ=AC.tab_c3(); TAB_C7=AC.tab_c7(); NOTE_C7=AC.NOTE_C7
from citations_num import numerote
_ch,_bib,_cited,_ent=numerote([open(f).read() for f in ['chapitre-1-complet.md','chapitre-2-assemble.md','chapitre-3-methodologie.md','chapitres-4-a-7-corrige.md']],open('references.md').read())
assert len(_cited)==len(_ent), 'référence non citée'
parts=[front,open('front_matter.md').read(),TOC,
 open('glossaire-court.md').read(),_ch[0],_ch[1],_ch[2],_ch[3],_bib,
 "# Annexes\n\n## Annexe A. Dictionnaire des variables\n\n"+open("annexe-a-dictionnaire.md").read()+"\n\n## Annexe B. Code source et dépôt\n\nLe code est livré sous la forme d'un dépôt (depot_github_pfe_v6), sans aucune donnée, joint au dossier de dépôt sous forme d'archive. Il comprend la construction du panel, les variables exogènes, la modélisation, les figures et les livrables ; le dossier 07_protocole_corrige contient les scripts du protocole corrigé dont proviennent tous les résultats des chapitres 4 à 6 : apprentissage purgé et comparaison des 4 modèles, recalibration, politique de capacité et rejeu du prototype, valeurs de Shapley, familles exogènes, sensibilité au seuil d'interruption, type de bien, découpage aléatoire. Deux usages sont à distinguer. La reproduction des résultats part du panel pseudonymisé fourni au jury (fichiers panel, périmètre, fenêtres des annonces et calendrier exogène) et se relance script par script, selon l'ordre du fichier README, avec les versions de bibliothèques fixées dans requirements.txt. La reconstruction du panel à partir des extractions brutes de la plateforme exige des fichiers et des scripts de préparation qui contiennent des éléments couverts par l'autorisation d'exploitation ; ils ne figurent pas dans le dépôt et ne sont accessibles au jury que sur demande. Les résultats de 2 tests, sur les attributs du rapport de la plateforme et sur la météo, proviennent des scripts du dossier 03_modelisation, antérieurs à la correction du protocole.\n\n"
 "## Annexe C. Tableaux complémentaires\n\nTableau C.1. Sensibilité au seuil d'interruption longue, 4 modèles, apprentissage purgé\n\n"+sec7.strip()+"\n\n"+NOTE_C1+"\n\nTableau C.2. Apport des 2 attributs du rapport de la plateforme (XGBoost, intervalles à 95 % par rééchantillonnage en grappes sur les annonces)\n\n"+att.strip()+"\n\n"+NOTE_C2+"\n\nTableau C.3. Apport du type de bien, CatBoost, 3 blocs temporels, apprentissage purgé\n\n"+typ.strip()+"\n\nTableau C.4. Comparaison à 2 références simples, aire sous la courbe par horizon\n\n"+TAB_C4+"\n\n"+NOTE_C4+"\n\nTableau C.5. Intervalles de confiance des écarts commentés aux chapitres 4 et 5\n\n"+TAB_C5+"\n\n"+NOTE_C5+"\n\nTableau C.6. Chiffres du parc retenu, par annonce\n\n"+open("annexe-c6-parc.md").read()+"\n\n"+"Tableau C.7. Calibration de 3 modèles par bloc et par horizon, apprentissage purgé\n\n"+TAB_C7+"\n\n"+NOTE_C7+"\n\n"
 "## Annexe D. Autorisation d'exploitation des données\n\nL'exploitation des données repose sur 2 documents. Le premier, signé par la gérance, autorise l'usage des revenus, des réservations, des taux d'occupation et des durées de séjour de 2023 à 2026. Le second, une autorisation manuscrite de l'administrateur datée du 4 octobre 2026, étend cet usage aux charges d'exploitation. Les 2 documents sont joints au dossier de dépôt à l'attention du jury ; ils ne sont pas reproduits ici parce qu'ils portent le nom réel de la société, que la convention de confidentialité exclut du mémoire.\n\n## Annexe E. Journal d'usage de l'intelligence artificielle\n\n"+open("annexe-e-journal-ia.md").read()+"\n\n## Annexe F. Réponse à l'énigme de l'interlude\n\n![](annexe_f_reponse_1.png){width=14cm}\n\n![](annexe_f_reponse_2.png){width=14cm}\n"]
open('memoire-complet-03-10.md','w').write("\n\n".join(parts).replace('\\.','.'))
raw='/tmp/m_raw.docx'
subprocess.run(['pandoc','memoire-complet-03-10.md','--reference-doc=reference-pfe.docx','-M','lang=fr-FR','-o',raw],check=True)
# --- post-traitement XML
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
z=zipfile.ZipFile(raw); files={n:z.read(n) for n in z.namelist()}; z.close()
doc=files['word/document.xml'].decode()
sect=('<w:sectPr><w:footerReference w:type="default" r:id="rIdPied"/><w:pgSz w:w="11906" w:h="16838"/>'
      '<w:pgMar w:top="1418" w:right="1418" w:bottom="1418" w:left="1418" w:header="709" w:footer="709" w:gutter="0"/><w:titlePg/></w:sectPr>')
doc=doc.replace('<w:sectPr />',sect)
if 'xmlns:r=' not in doc[:2000]:
    doc=doc.replace('<w:document ','<w:document xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ',1)
i=doc.find('<w:drawing'); ps=doc.rfind('<w:p>',0,i); ps2=doc.rfind('<w:p ',0,i); ps=max(ps,ps2)
seg=doc[ps:i]
seg2=re.sub(r'<w:pPr>.*?</w:pPr>','',seg,flags=re.S)
seg2=seg2.replace('<w:p>','<w:p><w:pPr><w:spacing w:before="0" w:after="0"/><w:ind w:left="0" w:firstLine="0"/><w:jc w:val="center"/></w:pPr>',1)
doc=doc[:ps]+seg2+doc[i:]
# --- glossaire : tableau à bordures, sigle face à sa définition, définition justifiée
gi=doc.find('Glossaire des sigles'); gt=doc.find('<w:tbl>',gi); ge=doc.find('</w:tbl>',gt)+len('</w:tbl>')
tb=doc[gt:ge]
B=''.join(f'<w:{c} w:val="single" w:sz="4" w:space="0" w:color="000000"/>' for c in ('top','left','bottom','right','insideH','insideV'))
tb=re.sub(r'<w:tblPr>.*?</w:tblPr>',
  '<w:tblPr><w:tblW w:type="dxa" w:w="9070"/><w:jc w:val="center"/><w:tblBorders>'+B+'</w:tblBorders>'
  '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:left w:w="100" w:type="dxa"/>'
  '<w:bottom w:w="40" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr>',tb,count=1,flags=re.S)
tb=re.sub(r'<w:tblGrid>.*?</w:tblGrid>','<w:tblGrid><w:gridCol w:w="2268"/><w:gridCol w:w="6802"/></w:tblGrid>',tb,count=1,flags=re.S)
def _row(m):
    r=m.group(0); cells=re.findall(r'<w:tc>.*?</w:tc>',r,flags=re.S); out=r
    for k,c in enumerate(cells):
        w,jc=(2268,'left') if k==0 else (6802,'both')
        c2=c.replace('<w:tcPr />',f'<w:tcPr><w:tcW w:w="{w}" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>',1)
        c2=re.sub(r'<w:jc w:val="[^"]*" />',f'<w:spacing w:before="0" w:after="0"/><w:ind w:left="0" w:firstLine="0"/><w:jc w:val="{jc}"/>',c2)
        out=out.replace(c,c2,1)
    return out
tb=re.sub(r'<w:tr>.*?</w:tr>',_row,tb,flags=re.S)
doc=doc[:gt]+tb+doc[ge:]
def _noind(m):
    return re.sub(r'(<w:pStyle w:val="Compact" />)(?!<w:spacing)',r'\1<w:ind w:left="0" w:firstLine="0"/>',m.group(0))
doc=re.sub(r'<w:tbl>.*?</w:tbl>',_noind,doc,flags=re.S)
files['word/document.xml']=doc.encode()
files['word/footer1.xml']=(f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr xmlns:w="{W}"><w:p><w:pPr><w:jc w:val="right"/></w:pPr>'
 '<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r>'
 '<w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>').encode()
rels=files['word/_rels/document.xml.rels'].decode()
rels=rels.replace('</Relationships>','<Relationship Id="rIdPied" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
files['word/_rels/document.xml.rels']=rels.encode()
ct=files['[Content_Types].xml'].decode()
ct=ct.replace('</Types>','<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
files['[Content_Types].xml']=ct.encode()
st=files['word/styles.xml'].decode()
st=re.sub(r'<w:style [^>]*w:styleId="TOC[12]".*?</w:style>','',st,flags=re.S)
def toc(i,ind): return (f'<w:style w:type="paragraph" w:styleId="TOC{i}"><w:name w:val="toc {i}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="39"/><w:unhideWhenUsed/>'
  f'<w:pPr><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9070"/></w:tabs><w:spacing w:before="0" w:after="100" w:line="276" w:lineRule="auto"/><w:ind w:left="{ind}" w:right="0" w:firstLine="0"/><w:jc w:val="left"/></w:pPr></w:style>')
st=st.replace('</w:styles>',toc(1,0)+toc(2,284)+'</w:styles>')
st=re.sub(r'(<w:style [^>]*w:styleId="Heading1"[^>]*>.*?<w:pPr>)',r'\1<w:pageBreakBefore/>',st,count=1,flags=re.S)
files['word/styles.xml']=st.encode()
se=files['word/settings.xml'].decode()
if 'updateFields' not in se: se=re.sub(r'(<w:settings[^>]*>)',r'\1<w:updateFields w:val="true"/>',se,count=1)
files['word/settings.xml']=se.encode()
inter='/tmp/m_inter.docx'
with zipfile.ZipFile(inter,'w',zipfile.ZIP_DEFLATED) as zo:
    for n,b in files.items(): zo.writestr(n,b)
print('docx intermediaire pret')
