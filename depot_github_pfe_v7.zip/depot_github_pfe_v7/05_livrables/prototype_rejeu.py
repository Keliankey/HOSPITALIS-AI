"""Prototype de demonstration : rejeu du dernier bloc (mars-aout 2026).
Modele CatBoost final entraine sur les nuits anterieures au 1er mars 2026, comme final.py.
Pour chaque lundi du bloc de test, liste des nuits encore ouvertes a chaque horizon,
avec probabilite d'invendu, revenu a risque et recommandation."""
import numpy as np, pandas as pd, warnings, json
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE=['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne','penalite_visibilite','ferie','veille_ferie','pont','tva_taux','taxe_sejour']
FEAT=BASE+VAC; CAT=['zone']; HOR=[90,60,30,15,7,3]; REV=65.87
p=pd.read_pickle('panel.pkl')
p = p[p.nuit <= '2026-08-31']   # FIN_FENETRE, chapitre 3, section 3.8
C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['date']=pd.to_datetime(C.date)
cal=C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC]; cal.columns=['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour']+VAC
p=p.merge(cal,on='nuit',how='left').merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']],on='code',how='left')
p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int); p['mois']=p.nuit.dt.month
ouv=p[p.deja_vendu_a_d0==0]
# plages de seuils ou le modele domine les 2 regles (figure 1)
D=pd.read_csv('courbes_decision.csv'); plage={}
for h in HOR:
    d=D[D.horizon==h]; g=d[(d.modele>d.tout_remiser)&(d.modele>d.rien_remiser)]
    plage[h]=(float(g.seuil.min()),float(g.seuil.max()))
rows=[]
for h in HOR:
    d=ouv[ouv.horizon==h].sort_values('nuit'); tr=d[d.nuit<'2026-03-01']; te=d[d.nuit>='2026-03-01'].copy()
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False).fit(pd.concat([tr[FEAT],tr[CAT]],axis=1),tr.invendu,cat_features=CAT)
    te['p']=m.predict_proba(pd.concat([te[FEAT],te[CAT]],axis=1))[:,1]
    te=te[te.d0.dt.dayofweek==0]          # le tableau de bord est consulte le lundi
    lo,hi=plage[h]
    te['reco']=np.where(te.p>hi,'Agir : risque très élevé',np.where(te.p>=lo,'À traiter','Surveiller'))
    rows.append(te[['d0','nuit','code','zone','horizon','p','invendu','reco']])
R=pd.concat(rows); R['rar']=(R.p*REV).round(2); R['p']=R.p.round(3)
R=R[(R.d0>='2026-03-02')]
R.to_pickle('prototype/rejeu.pkl'); json.dump({str(k):v for k,v in plage.items()},open('prototype/plages.json','w'))
print(len(R), R.d0.nunique(), R.d0.min().date(), R.d0.max().date()); print(R.groupby('reco').size()); print(plage)
