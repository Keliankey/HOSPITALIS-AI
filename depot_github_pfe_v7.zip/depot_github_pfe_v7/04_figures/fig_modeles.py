"""Figures 5, 6 et 7 : comparaison des modeles, calibration, encodage du quantieme."""
import pandas as pd, numpy as np, warnings
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

def virgule(fig):
    """Virgule decimale sur toutes les graduations, sans modifier les limites."""
    fig.canvas.draw()
    for ax in fig.axes:
        lx, ly = ax.get_xlim(), ax.get_ylim()
        for axis in (ax.xaxis, ax.yaxis):
            labs = [t.get_text() for t in axis.get_majorticklabels()]
            if any('.' in l for l in labs):
                axis.set_ticks(axis.get_majorticklocs())
                axis.set_ticklabels([l.replace('.', ',') for l in labs])
        ax.set_xlim(lx); ax.set_ylim(ly)
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from catboost import CatBoostClassifier
import xgboost as xgb
warnings.filterwarnings('ignore')

BLEU, ORANGE, AQUA, ENCRE, ENCRE2, GRILLE = '#2a78d6', '#eb6834', '#1baf7a', '#0b0b0b', '#52514e', '#d9d8d4'
VIOLET = '#4a3aa7'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
    'axes.edgecolor': GRILLE, 'axes.linewidth': .8, 'axes.labelcolor': ENCRE2,
    'xtick.color': ENCRE2, 'ytick.color': ENCRE2, 'xtick.labelsize': 8.5,
    'ytick.labelsize': 8, 'axes.titlesize': 10, 'axes.titleweight': 'bold',
    'axes.titlecolor': ENCRE, 'figure.facecolor': 'white',
    'savefig.facecolor': 'white', 'savefig.bbox': 'tight', 'savefig.dpi': 200})
HOR = [90, 60, 30, 15, 7, 3]

def soigne(ax, axe='y'):
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
    ax.grid(axis=axe, color=GRILLE, lw=.6); ax.set_axisbelow(True)

# =========================================================== FIGURE 5
# Pourquoi chaque modele a ete teste : ce que chacun repond.
R = pd.read_csv('comparaison_protocoles.csv')
A = R[R.protocole == 'A. blocs temporels']
STY = [('Regression logistique', 'Régression logistique', BLEU,  '-',  'o'),
       ('XGBoost',               'XGBoost',               ORANGE, '--', 's'),
       ('CatBoost',              'CatBoost',              AQUA,  '-.', '^'),
       ('LSTM',                  'LSTM',                  VIOLET, ':',  'D')]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.4))
x = np.arange(6)
for k, (m, lab, c, ls, mk) in enumerate(STY):
    v = [A[(A.modele == m) & (A.horizon == h)].AUC.mean() for h in HOR]
    a1.plot(x, v, color=c, ls=ls, marker=mk, ms=6, lw=2, mfc='white', mew=1.5, label=lab, zorder=3)
    a1.annotate(lab, (x[-1], v[-1]), xytext=(8, [-2, 6, -10, 2][k]),
                textcoords='offset points', fontsize=7.8, color=c, fontweight='bold', va='center')
a1.set_xticks(x); a1.set_xticklabels([f'J−{h}' for h in HOR])
a1.set_ylabel('Aire sous la courbe ROC'); a1.set_xlim(-.3, 6.6); a1.set_ylim(.58, .66)
a1.set_title('Discrimination : les 4 modèles se tiennent', loc='left')
soigne(a1)

for k, (m, lab, c, ls, mk) in enumerate(STY):
    v = [A[(A.modele == m) & (A.horizon == h)].cal_pente.mean() for h in HOR]
    a2.plot(x, v, color=c, ls=ls, marker=mk, ms=6, lw=2, mfc='white', mew=1.5, label=lab, zorder=3)
a2.axhline(1, color=ENCRE2, lw=1.2, ls=(0, (1, 2)), zorder=1)
a2.text(5.15, 1.015, 'calibration parfaite', fontsize=7.5, color=ENCRE2, style='italic', ha='right')
a2.set_xticks(x); a2.set_xticklabels([f'J−{h}' for h in HOR])
a2.set_ylabel('Pente de calibration'); a2.set_ylim(.45, 1.45)
a2.set_title("Calibration : c'est là qu'ils se séparent", loc='left')
a2.legend(frameon=False, fontsize=8, loc='lower left', ncol=2, labelcolor=ENCRE2)
soigne(a2)
fig.suptitle('Pourquoi 4 familles de modèles, et ce que chacune répond',
             fontsize=12, fontweight='bold', color=ENCRE, x=.012, ha='left', y=1.03)
fig.text(.012, -.06,
  "Protocole retenu : blocs temporels successifs, moyennes sur 3 blocs. À gauche, l'écart de discrimination entre le modèle le plus simple et le plus complexe\n"
  "reste au plus de l'ordre de 0,04. À droite, une pente inférieure à 1 signale des probabilités trop extrêmes, signe de sur-apprentissage. Le revenu à risque étant un produit\n"
  "probabilité × montant, c'est ce second critère qui départage.",
  fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout(); virgule(fig); fig.savefig('fig5_modeles.png'); plt.close(fig)

# =========================================================== FIGURE 6
# Courbes de calibration reelles, dernier bloc, a J-30.
VAC = ['vac_fwb', 'vac_flandre', 'vac_les_deux', 'vac_une_seule', 'vac_fwb_jour', 'vac_flandre_jour']
BASE = ['quantieme', 'jour_semaine', 'week_end', 'mois', 'occ_30j', 'occ_60j',
        'jours_depuis_resa', 'jours_depuis_remise_en_ligne', 'penalite_visibilite',
        'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour']
FEAT = BASE + VAC
FIN_FENETRE = '2026-08-31'   # derniere nuit modelisee : dernier mois complet avant l extraction (chapitre 3, section 3.8)
p = pd.read_pickle('panel.pkl')
p = p[p.nuit <= FIN_FENETRE]
C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier')
C['date'] = pd.to_datetime(C.date)
cal = C[['date', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour_eur'] + VAC]
cal.columns = ['nuit', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour'] + VAC
p = p.merge(cal, on='nuit', how='left')
p = p.merge(pd.read_pickle('p2w.pkl').reset_index()[['code', 'zone']], on='code', how='left')
p['invendu'] = 1 - p.vendu
p['week_end'] = p.jour_semaine.isin([4, 5]).astype(int)
p['mois'] = p.nuit.dt.month
p['zone_i'] = pd.factorize(p.zone)[0]
ouv = p[p.deja_vendu_a_d0 == 0]
d = ouv[ouv.horizon == 30].sort_values('nuit')
tr, te = d[d.nuit < '2026-03-01'], d[d.nuit >= '2026-03-01']
y = te.invendu.values
sc = StandardScaler().fit(tr[FEAT].fillna(tr[FEAT].median()))
preds = {}
preds['Régression logistique'] = LogisticRegression(max_iter=2000).fit(
    sc.transform(tr[FEAT].fillna(tr[FEAT].median())), tr.invendu.values)\
    .predict_proba(sc.transform(te[FEAT].fillna(tr[FEAT].median())))[:, 1]
preds['XGBoost'] = xgb.XGBClassifier(n_estimators=150, max_depth=3, learning_rate=.03,
    subsample=.7, colsample_bytree=.7, reg_lambda=10., min_child_weight=50,
    eval_metric='logloss', tree_method='hist').fit(tr[FEAT + ['zone_i']], tr.invendu.values)\
    .predict_proba(te[FEAT + ['zone_i']])[:, 1]
preds['CatBoost'] = CatBoostClassifier(iterations=150, depth=3, learning_rate=.03,
    l2_leaf_reg=20, verbose=0, allow_writing_files=False).fit(
    pd.concat([tr[FEAT], tr[['zone']]], axis=1), tr.invendu.values, cat_features=['zone'])\
    .predict_proba(pd.concat([te[FEAT], te[['zone']]], axis=1))[:, 1]

fig, ax = plt.subplots(figsize=(6.6, 5.2))
ax.plot([0, 1], [0, 1], color=ENCRE2, lw=1.2, ls=(0, (1, 2)), zorder=1, label='Calibration parfaite')
for (nom, c, ls, mk) in [('Régression logistique', BLEU, '-', 'o'),
                         ('XGBoost', ORANGE, '--', 's'), ('CatBoost', AQUA, '-.', '^')]:
    pr = preds[nom]
    q = pd.qcut(pr, 10, labels=False, duplicates='drop')
    ob = pd.Series(y).groupby(q).mean().values
    at = pd.Series(pr).groupby(q).mean().values
    ax.plot(at, ob, color=c, ls=ls, marker=mk, ms=7, lw=2, mfc='white', mew=1.6, label=nom, zorder=3)
ax.set_xlabel('Probabilité prédite (moyenne du décile)')
ax.set_ylabel("Fréquence observée d'invendu")
ax.set_xlim(.15, .75); ax.set_ylim(.15, .75)
ax.set_title("Courbes de calibration à J−30, dernier bloc", loc='left')
ax.legend(frameon=False, fontsize=8.5, loc='upper left', labelcolor=ENCRE2)
soigne(ax, 'both')
fig.text(0, -.055,
  "Déciles de probabilité prédite. Un point au-dessus de la diagonale signale une sous-estimation du risque, en dessous une surestimation.\n"
  "Les 3 modèles suivent la diagonale de près ; l'écart se joue aux extrémités, là où le revenu à risque en euros se calcule.",
  fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout(); virgule(fig); fig.savefig('fig6_calibration.png'); plt.close(fig)

# =========================================================== FIGURE 7
# L encodage du quantieme, et ce qu il coute.
j = pd.date_range('2024-02-24', '2024-03-08')
brut = j.dayofyear.values
bis = j.is_leap_year & (j.month > 2)
corr = np.where(bis, brut - 1, brut)
j25 = pd.date_range('2025-02-24', '2025-03-08')
fig, (b1, b2) = plt.subplots(1, 2, figsize=(11, 4.2))
xx = np.arange(len(j))
b1.plot(xx, brut, color=ORANGE, ls='--', marker='s', ms=6, lw=2, mfc='white', mew=1.5,
        label='Quantième brut (dayofyear)', zorder=3)
b1.plot(xx, corr, color=BLEU, marker='o', ms=6, lw=2.2, mfc='white', mew=1.6,
        label='Quantième corrigé (retenu)', zorder=4)
b1.axvline(5, color=ENCRE2, lw=1, ls=(0, (1, 2)))
b1.annotate('29 février', (5, 60), xytext=(-6, 16), textcoords='offset points',
            fontsize=8, color=ENCRE, fontweight='bold', ha='right')
b1.annotate('1ᵉʳ mars\nramené à 60', (6, 60), xytext=(12, -22), textcoords='offset points',
            fontsize=8, color=BLEU, fontweight='bold')
b1.set_xticks(xx[::2]); b1.set_xticklabels([d.strftime('%d/%m') for d in j][::2], rotation=45, ha='right')
b1.set_ylabel('Quantième'); b1.set_title('Année bissextile : 2024', loc='left')
b1.legend(frameon=False, fontsize=8, loc='upper left', labelcolor=ENCRE2)
soigne(b1)

DATES = ['01-01', '01-03', '01-06', '15-09', '31-12']
LIB = ['1ᵉʳ janvier', '1ᵉʳ mars', '1ᵉʳ juin', '15 septembre', '31 décembre']
def q(an, jm):
    d = pd.Timestamp(f'{an}-{jm[3:]}-{jm[:2]}')
    return d.dayofyear - (1 if (d.is_leap_year and d.month > 2) else 0)
yy = np.arange(len(DATES))
for k, (an, c, mk, off) in enumerate([(2024, BLEU, 'o', -.16), (2025, ORANGE, 's', 0), (2026, AQUA, '^', .16)]):
    b2.scatter([q(an, j) for j in DATES], yy + off, s=90, facecolor='white',
               edgecolor=c, linewidth=2, marker=mk, label=f'{an}' + (' (bissextile)' if an == 2024 else ''), zorder=3)
for i, j in enumerate(DATES):
    v = q(2024, j)
    b2.annotate(f'{v}', (v, yy[i]), xytext=(14, 0), textcoords='offset points',
                fontsize=8.5, color=ENCRE, fontweight='bold', va='center')
b2.set_yticks(yy); b2.set_yticklabels(LIB, fontsize=9)
b2.set_xlabel('Quantième corrigé'); b2.set_xlim(-12, 400); b2.invert_yaxis()
b2.set_title("Même date civile, même valeur les 3 années", loc='left')
b2.legend(frameon=False, fontsize=8, loc='upper right', labelcolor=ENCRE2)
soigne(b2, 'x')

fig.suptitle("Le quantième corrigé des bissextiles : ce qu'il aligne, ce qu'il coûte",
             fontsize=12, fontweight='bold', color=ENCRE, x=.012, ha='left', y=1.03)
fig.text(.012, -.10,
  "La correction retranche 1 au quantième brut pour toute date postérieure à février d'une année bissextile. Le 1ᵉʳ mars porte alors la même valeur toutes les\n"
  "années, ce qui est le but : le modèle voit une position dans l'année, pas une date. Le prix à payer est une collision : le 29 février et le 1ᵉʳ mars 2024\n"
  "partagent le quantième 60. Elle concerne 42 nuits-bien sur 31 993, soit 0,13 % du périmètre, et le jour de la semaine les distingue de toute façon.",
  fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout(); virgule(fig); fig.savefig('fig7_quantieme.png'); plt.close(fig)
print('fig5_modeles.png | fig6_calibration.png | fig7_quantieme.png')
