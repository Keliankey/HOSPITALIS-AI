"""Figures du memoire. PNG 200 dpi, francais, lisibles en noir et blanc.

Regles appliquees : une seule echelle par axe, jamais de double axe ; trois series
au maximum par panneau ; couleur DOUBLEE d un style de trait et d un marqueur
distincts, pour que la figure reste lisible imprimee en niveaux de gris ;
etiquettes directes en plus de la legende ; grille recessive.
Palette validee (CVD all-pairs) : #2a78d6 bleu, #eb6834 orange, #1baf7a aqua.
"""
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def virgule(fig):
    """Virgule decimale sur toutes les graduations, sans modifier les limites."""
    fig.canvas.draw()
    for ax in fig.axes:
        lx, ly = ax.get_xlim(), ax.get_ylim()
        for axis in (ax.xaxis, ax.yaxis):
            labs = [t.get_text() for t in axis.get_majorticklabels()]
            if any('.' in l for l in labs):
                axis.set_ticks(axis.get_majorticklocs())
                axis.set_ticklabels([l.replace('.', ',') for l in labs])
        ax.set_xlim(lx); ax.set_ylim(ly)
from matplotlib.ticker import PercentFormatter, FuncFormatter

BLEU, ORANGE, AQUA = '#2a78d6', '#eb6834', '#1baf7a'
ENCRE, ENCRE2, GRILLE = '#0b0b0b', '#52514e', '#d9d8d4'
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 9,
    'axes.edgecolor': GRILLE, 'axes.linewidth': 0.8, 'axes.labelcolor': ENCRE2,
    'xtick.color': ENCRE2, 'ytick.color': ENCRE2,
    'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'axes.titlesize': 10, 'axes.titleweight': 'bold', 'axes.titlecolor': ENCRE,
    'figure.facecolor': 'white', 'axes.facecolor': 'white',
    'savefig.facecolor': 'white', 'savefig.bbox': 'tight', 'savefig.dpi': 200,
})
HOR = [90, 60, 30, 15, 7, 3]

def soigne(ax):
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
    ax.grid(axis='y', color=GRILLE, lw=0.6, alpha=0.8)
    ax.set_axisbelow(True)

# ============================================================ FIGURE 1
# Courbes de decision : benefice net contre seuil, six horizons.
D = pd.read_csv('courbes_decision.csv')
fig, axes = plt.subplots(2, 3, figsize=(11, 6.4), sharex=True, sharey=True)
for k, h in enumerate(HOR):
    ax = axes[k // 3][k % 3]; d = D[D.horizon == h].sort_values('seuil')
    ax.axhline(0, color=ENCRE2, lw=1.0, ls=(0, (1, 2)), zorder=1)
    ax.plot(d.seuil, d.tout_remiser, color=ORANGE, lw=1.6, ls='--', marker='s',
            ms=3.2, mfc='white', mew=1.0, label='Tout remiser', zorder=2)
    ax.plot(d.seuil, d.modele, color=BLEU, lw=2.2, marker='o', ms=4.2,
            mfc='white', mew=1.4, label='Modèle', zorder=4)
    sup = d[(d.modele > d.tout_remiser) & (d.modele > 0)]
    if len(sup):
        ax.fill_between(sup.seuil, np.maximum(sup.tout_remiser, 0), sup.modele,
                        color=BLEU, alpha=0.13, lw=0, zorder=3)
        ax.annotate(f'{sup.seuil.min():.2f}–{sup.seuil.max():.2f}'.replace('.', ','),
                    xy=(sup.seuil.mean(), sup.modele.max()), xytext=(0, 7),
                    textcoords='offset points', ha='center', fontsize=7.5,
                    color=BLEU, fontweight='bold')
    ax.set_title(f'J−{h}', loc='left')
    ax.set_ylim(-0.32, 0.92); ax.set_xlim(0, 1)
    soigne(ax)
axes[0][0].legend(frameon=False, fontsize=8, loc='lower left',
                  labelcolor=ENCRE2, handlelength=2.4)
axes[0][0].text(0.05, -0.055, 'Ne rien remiser', fontsize=7.5, color=ENCRE2, style='italic')
for ax in axes[1]: ax.set_xlabel('Seuil de probabilité $p_t$')
for r in axes: r[0].set_ylabel('Bénéfice net')
fig.suptitle("Courbes de décision : le modèle contre les 2 règles uniformes",
             fontsize=12, fontweight='bold', color=ENCRE, x=0.012, ha='left', y=1.005)
fig.text(0.012, -0.035,
         "Bénéfice net de Vickers & Elkin (2006), dernier bloc temporel (nuits à partir du 1ᵉʳ mars 2026), "
         "nuits encore ouvertes à la date d'observation.\nLa zone bleutée marque la plage de seuils où le modèle "
         "domine simultanément les 2 règles de référence ; les bornes sont indiquées au-dessus.",
         fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout()
virgule(fig); fig.savefig('fig1_courbes_decision.png'); plt.close(fig)

# ============================================================ FIGURE 2
# Bascule des valeurs de Shapley entre J-90 et J-3.
S = pd.read_csv('shap_importance.csv')
NOM = {'zone': 'Zone du bien', 'taxe_sejour': 'Taxe de séjour', 'occ_60j': 'Occupation 60 j',
       'occ_30j': 'Occupation 30 j', 'week_end': 'Week-end', 'quantieme': 'Quantième',
       'jours_depuis_resa': 'Jours depuis dernière réservation', 'jour_semaine': 'Jour de semaine',
       'jours_depuis_remise_en_ligne': 'Jours depuis remise en ligne',
       'penalite_visibilite': 'Pénalité de visibilité', 'tva_taux': 'Taux de TVA',
       'vac_fwb': 'Vacances FWB', 'vac_flandre': 'Vacances Flandre', 'mois': 'Mois',
       'vac_fwb_jour': 'Rang du jour, congé FWB', 'vac_flandre_jour': 'Rang du jour, congé Flandre',
       'vac_les_deux': 'Congé dans les deux', 'vac_une_seule': 'Congé dans une seule',
       'ferie': 'Jour férié', 'veille_ferie': 'Veille de férié', 'pont': 'Pont'}
a = S[S.horizon == 90].set_index('variable').shap_abs_moyen
b = S[S.horizon == 3].set_index('variable').shap_abs_moyen
ordre = (a + b).nlargest(9).index[::-1]
y = np.arange(len(ordre)); hh = 0.38
fig, ax = plt.subplots(figsize=(8.6, 4.6))
ax.barh(y + hh/2, a[ordre], hh, color=BLEU, label='J−90', zorder=3)
ax.barh(y - hh/2, b[ordre], hh, color=ORANGE, hatch='///', edgecolor='white',
        lw=0.8, label='J−3', zorder=3)
for i, v in enumerate(ordre):
    ax.text(a[v] + .006, i + hh/2, f'{a[v]:.3f}'.replace('.', ','), va='center', fontsize=7.2, color=ENCRE2)
    ax.text(b[v] + .006, i - hh/2, f'{b[v]:.3f}'.replace('.', ','), va='center', fontsize=7.2, color=ENCRE2)
ax.set_yticks(y); ax.set_yticklabels([NOM.get(v, v) for v in ordre], fontsize=8.5, color=ENCRE)
ax.set_xlabel("Valeur de Shapley absolue moyenne  |φ|  (échelle du log-odds)")
ax.set_xlim(0, max(a[ordre].max(), b[ordre].max()) * 1.18)
ax.legend(frameon=False, fontsize=8.5, loc='lower right', labelcolor=ENCRE2)
for s in ('top', 'right'): ax.spines[s].set_visible(False)
ax.grid(axis='x', color=GRILLE, lw=0.6); ax.set_axisbelow(True)
ax.set_title("Ce qui pèse à 90 jours n'est pas ce qui pèse à 3 jours",
             loc='left', pad=12)
fig.text(0.0, -0.06,
         "Valeurs de Shapley marginales, moyennées en valeur absolue sur les nuits du dernier bloc. "
         "La zone du bien domine à J−90 ; à J−3 c'est le délai depuis la dernière\nréservation. Le modèle passe "
         "d'une logique structurelle à une logique conjoncturelle. Variables corrélées par construction : "
         "ces valeurs indiquent une direction, non une contribution causale.",
         fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout(); virgule(fig); fig.savefig('fig2_shapley.png'); plt.close(fig)

# ============================================================ FIGURE 3
# Revenu a risque : validation en euros, et montant par nuit ouverte.
E = pd.read_csv('revenu_a_risque.csv').set_index('horizon').loc[HOR].reset_index()
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.1))
x = np.arange(len(HOR)); w = 0.38
ax1.bar(x - w/2, E.revenu_a_risque_total/1000, w, color=BLEU, label='Revenu à risque prédit', zorder=3)
ax1.bar(x + w/2, E.perte_reelle/1000, w, color=ORANGE, hatch='///', edgecolor='white',
        lw=0.8, label='Perte réellement constatée', zorder=3)
for i, r in E.iterrows():
    ax1.text(i, max(r.revenu_a_risque_total, r.perte_reelle)/1000 + 3,
             f'{r.ecart_pct:+.1f} %'.replace('.', ','), ha='center', fontsize=7.8,
             color=ENCRE, fontweight='bold')
ax1.set_xticks(x); ax1.set_xticklabels([f'J−{h}' for h in HOR])
ax1.set_ylabel('Milliers d\'euros'); ax1.set_ylim(0, 132)
ax1.legend(frameon=False, fontsize=8, loc='upper center', bbox_to_anchor=(0.5,-0.12),
           ncol=2, labelcolor=ENCRE2)
ax1.set_title(f'Montant prédit et perte observée : écart de {E.ecart_pct.min():+.1f} à {E.ecart_pct.max():+.1f} %'.replace('.', ','), loc='left')
soigne(ax1)

ax2.plot(x, E.revenu_a_risque_moyen, color=BLEU, lw=2.2, marker='o', ms=6,
         mfc='white', mew=1.6, zorder=3)
for i, v in enumerate(E.revenu_a_risque_moyen):
    ax2.annotate(f'{v:.2f} €'.replace('.', ','), (i, v), textcoords='offset points',
                 xytext=(0, 11), ha='center', fontsize=8, color=ENCRE, fontweight='bold')
ax2.set_xticks(x); ax2.set_xticklabels([f'J−{h}' for h in HOR])
ax2.set_ylabel('Euros par nuit encore ouverte'); ax2.set_ylim(0, 60)
ax2.set_title("L'enjeu par nuit double à mesure que la date approche", loc='left')
soigne(ax2)
fig.suptitle('Valorisation monétaire du revenu à risque', fontsize=12,
             fontweight='bold', color=ENCRE, x=0.012, ha='left', y=1.02)
fig.text(0.012, -0.05,
         "Revenu à risque = P(invendu) × 65,87 €, revenu net moyen par nuit vendue du parc "
         "(1 438 335 € sur 21 836 nuits, net des frais de ménage).\nÀ gauche, somme sur les nuits du dernier bloc ; "
         "l'écart au montant réellement perdu va de " + f"{E.ecart_pct.min():+.1f}".replace('.', ',') + " % à " + f"{E.ecart_pct.max():+.1f}".replace('.', ',') + " % selon l'horizon.",
         fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout(); virgule(fig); fig.savefig('fig3_revenu_a_risque.png'); plt.close(fig)

print('fig1_courbes_decision.png | fig2_shapley.png | fig3_revenu_a_risque.png')
