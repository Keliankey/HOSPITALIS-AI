"""Figure 8 : couverture des champs du rapport plateforme, et ecart d'AUC des 2 attributs retenus.
Ne lit que des comptages de cellules renseignees et les resultats agreges du test."""
import os, pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
ENCRE, ENCRE2, GRILLE, BLEU, GRIS = '#1f2a37', '#5b6675', '#d9dee5', '#2f5d8a', '#b8c2cc'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'axes.edgecolor': GRILLE, 'axes.linewidth': .8,
    'axes.labelcolor': ENCRE2, 'xtick.color': ENCRE2, 'ytick.color': ENCRE2, 'xtick.labelsize': 8,
    'ytick.labelsize': 8, 'axes.titlesize': 10, 'axes.titleweight': 'bold', 'axes.titlecolor': ENCRE,
    'savefig.facecolor': 'white', 'savefig.bbox': 'tight', 'savefig.dpi': 200})

CHAMPS = [('Prix des concurrents (nuitée)', 'pricing_compset__nightly__current_price__0'),
          ('Réglages de réservation', 'booking_settings__max_lead__current_setting'),
          ('Réduction réservation anticipée', 'pricing_compset__early_bird__current_setting'),
          ('Frais de ménage comparés', 'pricing_compset__cleaning__current_setting'),
          ('Remise mensuelle', 'pricing_compset__monthly__current_discount'),
          ('Remise hebdomadaire', 'pricing_compset__weekly__current_discount'),
          ('Statut qualité', 'latest_quality_status'),
          ('Note moyenne des voyageurs', 'listing_avg_guest_rating_of_reviewed_stays_published_lifetime'),
          ('Rang équipements', 'Rank Amenities')]
PRIX = [f'pricing_compset__nightly__current_price__{k}' for k in range(7)]
raw = pd.read_excel(os.environ.get('RAPPORT_PLATEFORME', 'rapport_plateforme.xlsx'),
                    sheet_name='Raw Data', usecols=lambda c: c == 'Id Listing' or c in [x for _, x in CHAMPS] or c in PRIX)
# une annonce figure sur 2 lignes (2 types de jour) : on agrege par annonce avant de compter
raw = raw.groupby('Id Listing').agg(lambda v: v.dropna().iloc[0] if v.notna().any() else np.nan).reset_index()
raw['pricing_compset__nightly__current_price__0'] = raw[[c for c in PRIX if c in raw]].notna().any(axis=1).where(lambda b: b)
res = pd.read_pickle('res.pkl')[['logement_id']].drop_duplicates()
raw = raw[raw['Id Listing'].isin(res.logement_id)]          # les 32 annonces rattachees au parc
N = len(raw); cnt = [int(raw[c].notna().sum()) for _, c in CHAMPS]
ordre = np.argsort(cnt, kind='stable'); CHAMPS = [CHAMPS[i] for i in ordre]; cnt = [cnt[i] for i in ordre]
pd.DataFrame({'champ': [n for n, _ in CHAMPS], 'annonces_renseignees': cnt, 'sur': N}).to_csv(
    'couverture_champs_airbnb.csv', index=False)
IC = pd.read_csv('ic_attributs_airbnb.csv')

fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.4), gridspec_kw={'width_ratios': [1.05, 1]})
y = np.arange(len(CHAMPS))
col = [BLEU if k == N else GRIS for k in cnt]
a1.barh(y, cnt, color=col, height=.62, zorder=3)
for i, k in enumerate(cnt):
    a1.text(k + .5, i, f'{k} / {N}', va='center', fontsize=7.8, color=ENCRE2)
a1.set_yticks(y); a1.set_yticklabels([n for n, _ in CHAMPS], fontsize=8.3, color=ENCRE)
a1.set_xlim(0, N + 6); a1.set_xlabel('Annonces pour lesquelles le champ est renseigné')
a1.axvline(N, color=GRILLE, lw=.8, ls=':', zorder=1)
a1.grid(axis='x', color=GRILLE, lw=.5, zorder=0); a1.spines[['top', 'right']].set_visible(False)
a1.set_title('Seuls 2 champs couvrent toutes les annonces', loc='left')

x = np.arange(len(IC))
a2.axhline(0, color=ENCRE2, lw=.9, zorder=2)
a2.vlines(x, IC.ic_bas, IC.ic_haut, color=BLEU, lw=2.2, zorder=3)
a2.plot(x, IC.ecart, 'o', ms=6.5, mfc='white', mec=BLEU, mew=1.6, zorder=4)
for i, r in IC.iterrows():
    a2.annotate(f'{r.ecart:+.3f}'.replace('.', ',').replace('-', '−'), (i, r.ic_haut), xytext=(0, 6),
                textcoords='offset points', ha='center', fontsize=7.6, color=ENCRE)
a2.set_xlim(-.6, len(IC) - .4); a2.set_xticks(x); a2.set_xticklabels([f'J−{h}' for h in IC.horizon])
a2.set_ylabel("Écart d'AUC (avec − sans les 2 attributs)")
lim = max(abs(IC.ic_bas.min()), IC.ic_haut.max()) * 1.25; a2.set_ylim(-lim, lim)
a2.grid(axis='y', color=GRILLE, lw=.5, zorder=0); a2.spines[['top', 'right']].set_visible(False)
n_zero = int(((IC.ic_bas <= 0) & (IC.ic_haut >= 0)).sum())
n_neg = int((IC.ic_haut < 0).sum())
a2.set_title(f'Aucun gain : {n_zero} intervalles sur {len(IC)} contiennent zéro' + (f', {n_neg} est négatif' if n_neg == 1 else (f', {n_neg} sont négatifs' if n_neg else '')), loc='left')

fig.canvas.draw()
for ax in (a1, a2):
    lx, ly = ax.get_xlim(), ax.get_ylim()
    for axis in (ax.xaxis, ax.yaxis):
        labs = [t.get_text() for t in axis.get_majorticklabels()]
        if any('.' in l for l in labs):
            axis.set_ticks(axis.get_majorticklocs()); axis.set_ticklabels([l.replace('.', ',') for l in labs])
    ax.set_xlim(lx); ax.set_ylim(ly)
fig.suptitle('Le rapport de la plateforme comme source de variables : couverture et apport',
             fontsize=12, fontweight='bold', color=ENCRE, x=0.012, ha='left', y=1.03)
na = f'{IC.n_annonces.min()} à {IC.n_annonces.max()}' if IC.n_annonces.nunique() > 1 else f'{IC.n_annonces.min()}'
fig.text(0.012, -0.06,
  f"Instantané unique du 22 février 2026, {N} annonces rattachées au parc. À droite : XGBoost, nuits ouvertes observées après l'instantané et jusqu'au 31 août 2026,\n"
  f"découpage temporel 70/30 ; intervalles à 95 % par rééchantillonnage en grappes, l'annonce étant l'unité de tirage ({na} annonces dans l'échantillon de test).",
  fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout(); fig.savefig('fig8_attributs_airbnb.png'); plt.close(fig)
print(list(zip([n for n, _ in CHAMPS], cnt)), N)
