"""Figure 4 : ce que le protocole de validation fait au resultat."""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

def virgule(fig):
    """Virgule decimale sur toutes les graduations, sans modifier les limites."""
    fig.canvas.draw()
    for ax in fig.axes:
        lx, ly = ax.get_xlim(), ax.get_ylim()
        for axis in (ax.xaxis, ax.yaxis):
            labs = [t.get_text() for t in axis.get_majorticklabels()]
            if any('.' in l for l in labs):
                axis.set_ticks(axis.get_majorticklocs())
                axis.set_ticklabels([l.replace('.', ',') for l in labs])
        ax.set_xlim(lx); ax.set_ylim(ly)

BLEU, ORANGE = '#2a78d6', '#eb6834'
ENCRE, ENCRE2, GRILLE = '#0b0b0b', '#52514e', '#d9d8d4'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
    'axes.edgecolor': GRILLE, 'axes.linewidth': .8, 'axes.labelcolor': ENCRE2,
    'xtick.color': ENCRE2, 'ytick.color': ENCRE2, 'xtick.labelsize': 8.5,
    'ytick.labelsize': 8, 'axes.titlesize': 10, 'axes.titleweight': 'bold',
    'axes.titlecolor': ENCRE, 'figure.facecolor': 'white',
    'savefig.facecolor': 'white', 'savefig.bbox': 'tight', 'savefig.dpi': 200})

R = pd.read_csv('comparaison_protocoles.csv')
A = R.groupby(['protocole', 'modele']).AUC.mean()
MOD = ['Regression logistique', 'XGBoost', 'CatBoost', 'LSTM']
ETQ = ['Régression\nlogistique', 'XGBoost', 'CatBoost', 'LSTM']
x = np.arange(4); w = .38

fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.3))

# --- panneau 1 : blocs temporels contre aleatoire
t = [A[('A. blocs temporels', m)] for m in MOD]
r = [A[('B. aleatoire 80/20, par horizon', m)] for m in MOD]
a1.bar(x - w/2, t, w, color=BLEU, label='Blocs temporels successifs', zorder=3)
a1.bar(x + w/2, r, w, color=ORANGE, hatch='///', edgecolor='white', lw=.8,
       label='Découpage aléatoire 80/20', zorder=3)
for i in range(4):
    a1.text(i - w/2, t[i] + .004, f'{t[i]:.3f}'.replace('.', ','), ha='center', fontsize=7.6, color=ENCRE2)
    a1.text(i + w/2, r[i] + .004, f'{r[i]:.3f}'.replace('.', ','), ha='center', fontsize=7.6, color=ENCRE2)
    a1.annotate('', xy=(i + w/2, r[i]), xytext=(i - w/2, t[i]),
                arrowprops=dict(arrowstyle='->', color=ENCRE, lw=1.1,
                                connectionstyle='arc3,rad=-.3'), zorder=4)
    a1.text(i, max(t[i], r[i]) + .022, f'+{r[i]-t[i]:.3f}'.replace('.', ','), ha='center',
            fontsize=8, color=ENCRE, fontweight='bold')
a1.set_xticks(x); a1.set_xticklabels(ETQ); a1.set_ylim(.55, .76)
a1.set_ylabel("Aire sous la courbe ROC")
a1.set_title("Le découpage aléatoire gonfle le résultat d'environ 5 points", loc='left')
a1.legend(frameon=False, fontsize=8, loc='upper center', bbox_to_anchor=(.5,-.17),
          ncol=1, labelcolor=ENCRE2)

# --- panneau 2 : la fuite par duplication de la cible, mesuree sur 10 tirages
G = pd.read_csv('fuite_10_graines.csv')
MOD2 = ['Regression logistique', 'XGBoost', 'CatBoost']; ETQ2 = ['Régression\nlogistique', 'XGBoost', 'CatBoost']
moy = [G[G.modele == m].fuite.mean() for m in MOD2]; ety = [G[G.modele == m].fuite.std() for m in MOD2]
opt = [A[('B. aleatoire 80/20, par horizon', m)] - A[('A. blocs temporels', m)] for m in MOD2]
x2 = np.arange(3)
a2.bar(x2 - w/2, opt, w, color=ORANGE, hatch='///', edgecolor='white', lw=.8,
       label='Optimisme total du découpage aléatoire (panneau de gauche)', zorder=3)
a2.bar(x2 + w/2, moy, w, yerr=ety, capsize=3, color=BLEU,
       label='Part imputable à la duplication de la cible (moyenne et écart-type, 10 tirages)', zorder=3)
for i in range(3):
    a2.text(i - w/2, opt[i] + .002, f'+{opt[i]:.3f}'.replace('.', ','), ha='center', fontsize=7.8, color=ENCRE, fontweight='bold')
    a2.text(i + w/2, moy[i] + ety[i] + .002, f'{moy[i]:+.3f}'.replace('.', ','), ha='center', fontsize=7.8, color=ENCRE, fontweight='bold')
a2.axhline(0, color=ENCRE2, lw=.8)
a2.set_xticks(x2); a2.set_xticklabels(ETQ2); a2.set_ylim(-.02, .07)
a2.set_ylabel("Écart d'aire sous la courbe ROC")
a2.set_title("La duplication n'explique qu'une faible part de l'écart", loc='left')
a2.legend(frameon=False, fontsize=8, loc='upper center', bbox_to_anchor=(.5,-.17),
          ncol=1, labelcolor=ENCRE2)

for ax in (a1, a2):
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
    ax.grid(axis='y', color=GRILLE, lw=.6); ax.set_axisbelow(True)

fig.suptitle("Ce que le protocole de validation fait au résultat", fontsize=12,
             fontweight='bold', color=ENCRE, x=.012, ha='left', y=1.03)
fig.text(.012, -.07,
  "À gauche : mêmes modèles, mêmes variables, même population ; seul le découpage change. Le gain apparent du découpage aléatoire n'est pas une performance,\n"
  "c'est de l'information qui ne serait pas disponible en exploitation. À droite : comparaison de 2 découpages aléatoires, l'un laissant les 6 lignes d'une même nuit\n"
  "de part et d'autre de la coupure, l'autre les regroupant ; l'écart moyen sur 10 tirages mesure la part de l'optimisme due à la seule duplication de la cible.",
  fontsize=7.5, color=ENCRE2, ha='left', va='top')
fig.tight_layout(); virgule(fig); fig.savefig('fig4_protocoles.png'); plt.close(fig)
print('fig4_protocoles.png')
