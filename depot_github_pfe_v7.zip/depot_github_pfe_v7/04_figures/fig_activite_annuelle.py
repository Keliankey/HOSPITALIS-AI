"""Figure 2 du chapitre 1 : activite annuelle du parc sur la plateforme, 2023 a 2026.
Source : export des reservations du compte hote (5 578 reservations), ventilation par annee d'arrivee."""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
ENCRE, ENCRE2, GRILLE, BLEU, BLEU_C = '#1f2a37', '#5b6675', '#d9dee5', '#2f5d8a', '#c9d7e6'
plt.rcParams.update({'font.family':'DejaVu Sans','axes.edgecolor':GRILLE,'axes.linewidth':.8,'xtick.color':ENCRE2,'ytick.color':ENCRE2,
  'xtick.labelsize':9,'ytick.labelsize':8,'axes.titlesize':10.5,'axes.titleweight':'bold','axes.titlecolor':ENCRE,'savefig.facecolor':'white','savefig.bbox':'tight','savefig.dpi':200,'hatch.color':BLEU,'hatch.linewidth':.6})
r=pd.read_pickle('res.pkl'); r=r[r.nuits>0]; r['an']=r.date_arrivee.dt.year
g=r.groupby('an').agg(res=('id_reservation','size'),nuits=('nuits','sum'),ca=('revenu_brut_eur','sum'))
g.to_csv('activite_annuelle.csv')
fr=lambda v: f'{v:,.0f}'.replace(',', ' ')
ans=list(g.index); x=np.arange(len(ans)); partiel={2023:'nov.-déc.',2026:'janv.-sept.'}
fig,axs=plt.subplots(1,3,figsize=(11,3.6))
for ax,(col,titre,fmt) in zip(axs,[('ca',"Revenu brut hôte (milliers d'euros)",lambda v: fr(v/1000)),('res','Réservations',fr),('nuits','Nuits vendues',fr)]):
    v=g[col].values; vv=v/1000 if col=='ca' else v
    for i,a in enumerate(ans):
        p=a in partiel
        ax.bar(i,vv[i],.62,color=BLEU_C if p else BLEU,edgecolor=BLEU,linewidth=.8,hatch='///' if p else None,zorder=3)
        ax.text(i,vv[i]*1.02,fmt(v[i]),ha='center',va='bottom',fontsize=8.5,color=ENCRE)
    ax.set_xticks(x); ax.set_xticklabels([f'{a}\n{partiel[a]}' if a in partiel else f'{a}\n' for a in ans],fontsize=8.5)
    ax.set_ylim(0,vv.max()*1.18); ax.set_title(titre,loc='left'); ax.grid(axis='y',color=GRILLE,lw=.5,zorder=0)
    ax.spines[['top','right']].set_visible(False); ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda t,p: fr(t)))
fig.text(.012,-.06,"Années 2023 et 2026 partielles (hachurées) : la fenêtre d'extraction couvre les arrivées du 4 novembre 2023 au 20 septembre 2026. "
 "Total : 1 585 908 € de revenu brut hôte,\n5 578 réservations et 21 836 nuits vendues, ventilés par année d'arrivée. Canal de la plateforme uniquement : la location directe hors plateforme n'y figure pas.\n"
 "Source : export des réservations du compte hôte de la plateforme de location de courte durée, calcul de l'auteur.",fontsize=7.5,color=ENCRE2,ha='left',va='top')
fig.tight_layout(); fig.savefig('fig_activite_annuelle.png'); print(g)
