exec(open('protocole_v6.py').read().split("MODELES = ['Regression logistique'")[0])
def cb(tr,te,f):
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False)
    m.fit(pd.concat([tr[f],tr[CAT]],axis=1),tr.invendu,cat_features=CAT); return m.predict_proba(pd.concat([te[f],te[CAT]],axis=1))[:,1]
q=pd.read_pickle('perim.pkl').sort_values(['code','nuit']); q['inv']=1-q.vendu
q['brk']=(q.inv!=q.groupby('code').inv.shift())|(q.nuit-q.groupby('code').nuit.shift()!=pd.Timedelta('1D')); q['run']=q.brk.cumsum()
r=q[q.inv==1].groupby('run').nuit.size(); q['long']=q.run.isin(set(r[(r>=22)&(r<=44)].index))
o=ouv.merge(q[['code','nuit','long']],on=['code','nuit'],how='left'); o=o[~o.long.fillna(False).astype(bool)]
for h in HOR:
    d=o[o.horizon==h].sort_values(['nuit','code']); cp=pd.Timestamp('2026-03-01')-pd.Timedelta(days=h)
    tr=d[d.nuit<cp]; te=d[d.nuit>='2026-03-01']; pr=cb(tr,te,FEAT); y=te.invendu.values
    print(f'J-{h:2d}: ecart {100*(pr.sum()-y.sum())/y.sum():+5.1f} %  AUC {roc_auc_score(y,pr):.3f}  invendu app {100*tr.invendu.mean():.1f} test {100*y.mean():.1f}',flush=True)
