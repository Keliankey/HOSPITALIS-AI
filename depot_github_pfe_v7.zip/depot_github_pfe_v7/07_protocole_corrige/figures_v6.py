import pandas as pd, numpy as np, warnings
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
exec(open('fig_modeles.py').read().split('# =========================================================== FIGURE 5')[0].split('from sklearn.linear_model')[0])
BLEU, ORANGE, AQUA, ENCRE, ENCRE2, GRILLE, VIOLET = '#2a78d6', '#eb6834', '#1baf7a', '#0b0b0b', '#52514e', '#d9d8d4', '#4a3aa7'
GRIS='#8a8984'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.edgecolor':GRILLE,'axes.linewidth':.8,'axes.labelcolor':ENCRE2,'xtick.color':ENCRE2,'ytick.color':ENCRE2,
 'xtick.labelsize':8.5,'ytick.labelsize':8,'axes.titlesize':10,'axes.titleweight':'bold','axes.titlecolor':ENCRE,'figure.facecolor':'white','savefig.facecolor':'white','savefig.bbox':'tight','savefig.dpi':200})
HOR=[90,60,30,15,7,3]; x=np.arange(6)
def soigne(ax,axe='y'):
    for s in ('top','right'): ax.spines[s].set_visible(False)
    ax.grid(axis=axe,color=GRILLE,lw=.6); ax.set_axisbelow(True)
STY=[('Regression logistique','Régression logistique',BLEU,'-','o'),('XGBoost','XGBoost',ORANGE,'--','s'),('CatBoost','CatBoost',AQUA,'-.','^'),('LSTM','LSTM',VIOLET,':','D')]
R=pd.read_csv('cellules_v6.csv'); O='fig/'
import os; os.makedirs(O,exist_ok=True)
# ---- Figure 5 : AUC par horizon
fig,ax=plt.subplots(figsize=(9,4.2))
for k,(m,lab,c,ls,mk) in enumerate(STY+[('Reference naive','Référence naïve',GRIS,(0,(4,2)),'x')]):
    v=[R[(R.modele==m)&(R.horizon==h)].AUC.mean() for h in HOR]
    ax.plot(x,v,color=c,ls=ls,marker=mk,ms=6,lw=2,mfc='white',mew=1.5,label=lab,zorder=3)
ax.set_xticks(x); ax.set_xticklabels([f'J−{h}' for h in HOR]); ax.set_ylabel('Aire sous la courbe ROC'); ax.set_ylim(.56,.66)
ax.legend(frameon=False,ncol=5,loc='upper center',bbox_to_anchor=(.5,1.12),fontsize=8); soigne(ax); virgule(fig); fig.savefig(O+'fig_auc_horizon.png'); plt.close(fig)
# ---- Figure 6 : protocoles
Al=pd.read_csv('aleatoire_v6.csv').groupby('modele').AUC.mean(); Te=R.groupby('modele').AUC.mean(); F=pd.read_csv('fuite_10_graines_v6.csv')
fig,(a1,a2)=plt.subplots(1,2,figsize=(11,4.2),gridspec_kw={'width_ratios':[1.4,1]})
ms=['Regression logistique','XGBoost','CatBoost','LSTM']; labs=['Régression\nlogistique','XGBoost','CatBoost','LSTM']; xx=np.arange(4)
a1.bar(xx-.19,[Te[m] for m in ms],.36,color=AQUA,label='Blocs temporels, apprentissage purgé'); a1.bar(xx+.19,[Al[m] for m in ms],.36,color=ORANGE,label='Découpage aléatoire')
for i,m in enumerate(ms): a1.annotate(f"+{Al[m]-Te[m]:.3f}".replace('.',','),(i+.19,Al[m]),xytext=(0,3),textcoords='offset points',ha='center',fontsize=8,color=ENCRE2)
a1.set_xticks(xx); a1.set_xticklabels(labs); a1.set_ylim(.58,.70); a1.set_ylabel('Aire sous la courbe ROC, moyenne'); a1.legend(frameon=False,fontsize=8,loc='upper left')
a1.set_title('Le découpage aléatoire flatte surtout les modèles flexibles',loc='left'); soigne(a1)
col=[c for c in F.columns if c not in ('graine','seed')]
g=F.groupby('modele') if 'modele' in F.columns else None
if g is not None:
    ycol=[c for c in F.columns if F[c].dtype!=object and c not in ('graine','seed')][-1]
    mm=['Regression logistique','XGBoost','CatBoost']; mu=[F[F.modele==m][ycol].mean() for m in mm]; sd=[F[F.modele==m][ycol].std() for m in mm]
    a2.bar(np.arange(3),mu,.5,yerr=sd,color=[BLEU,ORANGE,AQUA],capsize=4); a2.axhline(0,color=ENCRE2,lw=.8)
    a2.set_xticks(np.arange(3)); a2.set_xticklabels(['Régression\nlogistique','XGBoost','CatBoost']); a2.set_ylabel("Écart d'AUC dû à la duplication")
a2.set_title('Part de la seule duplication, 10 tirages',loc='left'); soigne(a2); virgule(fig); fig.savefig(O+'fig4_protocoles.png'); plt.close(fig)
# ---- Figure 7 : calibration, dernier bloc, 6 horizons, 4 modeles
cells=pd.read_pickle('predictions_v6.pkl')
fig,axs=plt.subplots(2,3,figsize=(11,7),sharex=True,sharey=True)
for ax,h in zip(axs.flat,HOR):
    c=[c for c in cells if c['bloc']==3 and c['h']==h][0]; y=c['te'].invendu.values
    for m,lab,col,ls,mk in STY:
        p=c['P'][m]; q=pd.qcut(p,10,labels=False,duplicates='drop'); d=pd.DataFrame({'p':p,'y':y,'q':q}).groupby('q').mean()
        ax.plot(d.p,d.y,color=col,ls=ls,marker=mk,ms=4,lw=1.6,mfc='white',label=lab)
    ax.plot([0,1],[0,1],color=ENCRE2,lw=1,ls=(0,(1,2))); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.set_title(f'J−{h}',loc='left'); soigne(ax,'both')
for ax in axs[1]: ax.set_xlabel('Probabilité prédite, par décile')
for ax in axs[:,0]: ax.set_ylabel("Taux d'invendu observé")
axs[0,0].legend(frameon=False,fontsize=7.5,loc='upper left'); virgule(fig); fig.savefig(O+'fig6_calibration.png'); plt.close(fig)
# ---- Figure 8 : discrimination et calibration par horizon
fig,(a1,a2)=plt.subplots(1,2,figsize=(11,4.4))
for m,lab,c,ls,mk in STY:
    a1.plot(x,[R[(R.modele==m)&(R.horizon==h)].AUC.mean() for h in HOR],color=c,ls=ls,marker=mk,ms=6,lw=2,mfc='white',mew=1.5,label=lab)
    a2.plot(x,[R[(R.modele==m)&(R.horizon==h)].intercept.mean() for h in HOR],color=c,ls=ls,marker=mk,ms=6,lw=2,mfc='white',mew=1.5,label=lab)
a2.axhline(0,color=ENCRE2,lw=1.2,ls=(0,(1,2)))
for a,t,yl in [(a1,'Discrimination : les 4 modèles se tiennent','Aire sous la courbe ROC'),(a2,"Calibration : CatBoost a l'erreur de niveau la plus faible","Ordonnée à l'origine de calibration (0 = idéal)")]:
    a.set_xticks(x); a.set_xticklabels([f'J−{h}' for h in HOR]); a.set_title(t,loc='left'); a.set_ylabel(yl); soigne(a)
a1.legend(frameon=False,fontsize=8,loc='lower center',ncol=2); virgule(fig); fig.savefig(O+'fig5_modeles.png'); plt.close(fig)
# ---- Figure 10 : revenu a risque
T=pd.read_csv('tableau_5_1_v6.csv').set_index('horizon').loc[HOR]
fig,ax=plt.subplots(figsize=(9,4.2)); w=.38
ax.bar(x-w/2,T.rar_total/1000,w,color=AQUA,label='Revenu à risque prédit'); ax.bar(x+w/2,T.perte_imputee/1000,w,color=GRIS,label='Perte imputée aux nuits invendues')
for i,(h,r) in enumerate(T.iterrows()): ax.annotate(f"{r.ecart:+.1f} %".replace('.',',').replace('-','−'),(i,max(r.rar_total,r.perte_imputee)/1000),xytext=(0,4),textcoords='offset points',ha='center',fontsize=8.5,color=ENCRE)
ax.set_xticks(x); ax.set_xticklabels([f'J−{h}' for h in HOR]); ax.set_ylabel('Milliers d’euros'); ax.set_ylim(0,125); ax.legend(frameon=False,fontsize=8,loc='upper left',ncol=2); soigne(ax); virgule(fig)
fig.savefig(O+'fig3_revenu_a_risque.png'); plt.close(fig)
# ---- Figure 11 : courbes de decision
D=pd.read_csv('courbes_decision_v6.csv'); fig,axs=plt.subplots(2,3,figsize=(11,6.6),sharex=True)
for ax,h in zip(axs.flat,HOR):
    d=D[D.horizon==h]; ax.plot(d.seuil,d.modele,color=AQUA,lw=2,label='Modèle'); ax.plot(d.seuil,d.tout_remiser,color=ORANGE,lw=1.6,ls='--',label='Tout remiser'); ax.axhline(0,color=ENCRE2,lw=1.2,ls=':',label='Ne rien remiser')
    lo=min(d.modele.min(),0)-.02; ax.set_ylim(max(lo,-.15),max(d.tout_remiser.max(),d.modele.max())+.03); ax.set_title(f'J−{h}',loc='left'); soigne(ax)
for ax in axs[1]: ax.set_xlabel('Seuil de décision')
for ax in axs[:,0]: ax.set_ylabel('Bénéfice net')
axs[0,0].legend(frameon=False,fontsize=7.5); virgule(fig); fig.savefig(O+'fig1_courbes_decision.png'); plt.close(fig)
# ---- Figure 13 : Shapley J-90 et J-3
S=pd.read_csv('shap_v6.csv'); LAB={'zone':'Zone','week_end':'Week-end','jours_depuis_resa':'Jours depuis la dernière réservation','occ_60j':'Occupation 60 jours','occ_30j':'Occupation 30 jours',
 'quantieme':'Quantième','jours_depuis_remise_en_ligne':'Jours depuis la remise en ligne','jour_semaine':'Jour de la semaine','mois':'Mois','penalite_visibilite':'Pénalité de visibilité','vac_fwb':'Vacances FWB','vac_flandre':'Vacances flamandes',
 'vac_fwb_jour':'Rang du jour, vacances FWB','vac_flandre_jour':'Rang du jour, vacances flamandes','vac_les_deux':'Les 2 communautés en congé','vac_une_seule':'Une seule communauté en congé','ferie':'Jour férié','veille_ferie':'Veille de férié','pont':'Pont'}
fig,axs=plt.subplots(1,2,figsize=(11,4.6))
for ax,h,c in [(axs[0],90,BLEU),(axs[1],3,AQUA)]:
    s=S[S.horizon==h].nlargest(10,'shap_abs_moyen').iloc[::-1]
    ax.barh([LAB.get(v,v) for v in s.variable],s.shap_abs_moyen,color=c); ax.set_title(f'J−{h}',loc='left'); ax.set_xlabel('Valeur de Shapley absolue moyenne'); soigne(ax,'x')
virgule(fig); fig.savefig(O+'fig2_shapley.png'); plt.close(fig)
print('ok', os.listdir(O))
