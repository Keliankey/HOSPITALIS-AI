exec(open('protocole_v6.py').read().split("MODELES = ['Regression logistique'")[0])
from catboost import Pool
rows=[]
for h in HOR:
    d=ouv[ouv.horizon==h].sort_values(['nuit','code']); cp=pd.Timestamp('2026-03-01')-pd.Timedelta(days=h)
    tr=d[d.nuit<cp]; te=d[(d.nuit>='2026-03-01')&(d.nuit<'2026-09-01')]
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False).fit(pd.concat([tr[FEAT],tr[CAT]],axis=1),tr.invendu,cat_features=CAT)
    X=pd.concat([te[FEAT],te[CAT]],axis=1); sv=m.get_feature_importance(type='ShapValues',data=Pool(X,te.invendu,cat_features=CAT))
    for nom,v in zip(X.columns,np.abs(sv[:,:-1]).mean(0)): rows.append(dict(horizon=h,variable=nom,shap_abs_moyen=round(float(v),5)))
S=pd.DataFrame(rows); S.to_csv('shap_v6.csv',index=False)
for h in HOR:
    s=S[S.horizon==h].nlargest(6,'shap_abs_moyen'); print(f'J-{h}: '+' | '.join(f'{r.variable} {r.shap_abs_moyen:.3f}' for r in s.itertuples()))
