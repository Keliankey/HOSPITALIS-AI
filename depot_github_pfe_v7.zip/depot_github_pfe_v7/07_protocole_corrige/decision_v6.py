import numpy as np, pandas as pd, json
cells = pd.read_pickle('predictions_v6.pkl')
HOR = [90, 60, 30, 15, 7, 3]; SEUILS = np.round(np.arange(0.05, 0.96, 0.05), 2)
def nb(y, trait, pt):
    n = len(y); tp = np.sum(trait & (y == 1)); fp = np.sum(trait & (y == 0)); return tp/n - fp/n*pt/(1-pt)
def courbes(bloc):
    out = []
    for c in cells:
        if c['bloc'] != bloc: continue
        y = c['te'].invendu.values; pr = c['P']['CatBoost']
        for pt in SEUILS:
            out.append(dict(bloc=bloc, horizon=c['h'], seuil=pt, modele=nb(y, pr >= pt, pt), tout_remiser=nb(y, np.ones(len(y), bool), pt), rien_remiser=0.0))
    return pd.DataFrame(out)
D3, D2 = courbes(3), courbes(2)
D3.to_csv('courbes_decision_v6.csv', index=False); D2.to_csv('courbes_decision_bloc2_v6.csv', index=False)
def dom(D):
    r = []
    for h in HOR:
        d = D[D.horizon == h]; g = d[(d.modele > d.tout_remiser) & (d.modele > d.rien_remiser)]
        r.append(dict(horizon=h, n=len(g), lo=g.seuil.min() if len(g) else None, hi=g.seuil.max() if len(g) else None))
    return pd.DataFrame(r)
T52 = dom(D3); print('=== Tableau 5.2 (bloc 3) ==='); print(T52.to_string(index=False))
P2 = dom(D2); print('=== plages fixees sur le bloc 2 (pour le prototype) ==='); print(P2.to_string(index=False))

# --- Tableau 5.1
REV3 = [c for c in cells if c['bloc'] == 3][0]['REV']; t51 = []
for c in cells:
    if c['bloc'] != 3: continue
    y = c['te'].invendu.values; pr = c['P']['CatBoost']
    t51.append(dict(horizon=c['h'], n=len(y), rar_moyen=round(pr.mean()*REV3, 2), rar_total=round(pr.sum()*REV3), perte_imputee=round(y.sum()*REV3), ecart=round(100*(pr.sum()-y.sum())/y.sum(), 1), invendus=int(y.sum())))
T51 = pd.DataFrame(t51); T51.to_csv('tableau_5_1_v6.csv', index=False); print(f'REV bloc 3 = {REV3:.2f}'); print(T51.to_string(index=False))

# --- exemple J-3 au seuil 0,80
c = [c for c in cells if c['bloc'] == 3 and c['h'] == 3][0]; y = c['te'].invendu.values; pr = c['P']['CatBoost']
for pt in [0.7, 0.75, 0.8]:
    t = pr >= pt; print(f'J-3 seuil {pt}: designees {t.sum()}, invendues {int((t & (y==1)).sum())}, NB {nb(y,t,pt):.4f} (= {nb(y,t,pt)*len(y):.0f} nuits), tout remiser {nb(y,np.ones(len(y),bool),pt):.4f}, n={len(y)}')

# --- politique executable : chaque jour, seules les lignes observees ce jour-la ; budget hebdomadaire commun a tous les horizons ; une nuit traitee une fois
L = pd.concat([c['te'].assign(p=c['P']['CatBoost']) for c in cells if c['bloc'] == 3], ignore_index=True)
L = L[(L.d0 >= '2026-03-02') & (L.d0 <= '2026-08-30')].copy()
L['cle'] = L.code + '|' + L.nuit.dt.strftime('%Y%m%d'); L['jour'] = (L.d0 - pd.Timestamp('2026-03-02')).dt.days
N_nuits = L.cle.nunique(); base = L.drop_duplicates('cle').invendu.mean()
def politique(K, regle, seed=0):
    rng = np.random.default_rng(seed); faits = set(); choisis = []
    for j, g in L.groupby('jour'):
        w, k = divmod(j, 7); quota = (K*(k+1))//7 - (K*k)//7
        g = g[~g.cle.isin(faits)]
        if quota == 0 or g.empty: continue
        if regle == 'modele': g = g.sort_values('p', ascending=False)
        elif regle == 'hasard': g = g.sample(frac=1, random_state=int(rng.integers(1e9)))
        elif regle == 'plus_proches': g = g.assign(u=rng.random(len(g))).sort_values(['horizon', 'u'])
        elif regle == 'moins_remplies': g = g.assign(u=rng.random(len(g))).sort_values(['occ_30j', 'u'], na_position='last')
        g = g.drop_duplicates('cle').head(quota); faits |= set(g.cle); choisis.append(g)
    return pd.concat(choisis)
E = {'e20': 0.15/(0.15+0.2*0.85), 'e40': 0.15/(0.15+0.4*0.85), 'e60': 0.15/(0.15+0.6*0.85)}
rows = []
for K in [10, 25, 50]:
    for regle in ['modele', 'plus_proches', 'moins_remplies', 'hasard']:
        reps = range(20) if regle != 'modele' else [0]
        acc = []
        for s in reps:
            S = politique(K, regle, s); tp = S.invendu.sum(); fp = len(S) - tp
            acc.append(dict(actions=len(S), invendues=tp, precision=100*tp/len(S), **{k: 100*(tp - fp*pt/(1-pt))/len(S) for k, pt in E.items()}))
        a = pd.DataFrame(acc).mean(); rows.append(dict(K=K, regle=regle, **a.round(1).to_dict()))
C5 = pd.DataFrame(rows); C5.to_csv('capacite_v6.csv', index=False)
print(f'=== Politique quotidienne, 26 semaines, {N_nuits} nuits distinctes candidates, taux d invendu {100*base:.1f} % ===')
print(C5.to_string(index=False)); print('seuils', {k: round(v, 3) for k, v in E.items()})
S = politique(25, 'modele'); print('repartition des actions par horizon (25/sem, modele):'); print(S.horizon.value_counts().sort_index().to_dict())

# --- prototype : lundi seulement, revenu propre a chaque annonce estime avant le premier jour de decision, seuils fixes sur le bloc 2
RES = pd.read_csv('sejours_pseudonymises.csv', parse_dates=['date_arrivee', 'date_depart']); RES = RES[(RES.nuits > 0) & (RES.revenu_brut_eur > 0)]
s = RES[RES.date_depart < pd.Timestamp('2025-12-01')]
ra = ((s.revenu_brut_eur - s.frais_menage_eur).groupby(s.code).sum() / s.nuits.groupby(s.code).sum())
print('R par annonce', round(ra.min(), 1), round(ra.max(), 1), 'annonces sans historique:', len(set(L.code) - set(ra.index)))
M = pd.concat([c['te'].assign(p=c['P']['CatBoost']) for c in cells if c['bloc'] == 3], ignore_index=True)
M = M[(M.d0.dt.dayofweek == 0) & (M.d0 >= '2026-03-02')].copy()
M['cle'] = M.code + '|' + M.nuit.dt.strftime('%Y%m%d'); M['R'] = M.code.map(ra).fillna(REV3)
M['rar'] = M.p*M.R; M['rar_cst'] = M.p*REV3
plage = {int(r.horizon): (r.lo, r.hi) for r in P2.itertuples()}
M['reco'] = [('Agir' if p > plage[h][1] else 'A traiter' if p >= plage[h][0] else 'Surveiller') if plage[h][0] is not None and not pd.isna(plage[h][0]) else 'Surveiller' for p, h in zip(M.p, M.horizon)]
def top(col):
    faits = set(); out = []
    for d, g in M.groupby('d0'):
        g = g[~g.cle.isin(faits)].sort_values(col, ascending=False).drop_duplicates('cle').head(25); faits |= set(g.cle); out.append(g)
    return pd.concat(out)
A, B = top('rar'), top('rar_cst')
print(f'Prototype : {M.d0.nunique()} lundis, {len(A)} nuits designees, {A.invendu.sum()} invendues ({100*A.invendu.mean():.1f} %), base des nuits affichees {100*M.drop_duplicates("cle").invendu.mean():.1f} %')
print(f'R propre vs R constant : recouvrement {100*len(set(A.cle)&set(B.cle))/len(A):.0f} %, perte imputee ciblee {(A.invendu*A.R).sum():.0f} vs {(B.invendu*B.R).sum():.0f} EUR')
print(M.groupby('reco').size().to_dict()); json.dump({str(k): v for k, v in plage.items()}, open('plages_bloc2_v6.json', 'w'))
M.to_pickle('rejeu_v6.pkl')
