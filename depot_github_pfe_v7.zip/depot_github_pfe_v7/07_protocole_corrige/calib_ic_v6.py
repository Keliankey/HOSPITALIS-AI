import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss
cells=pd.read_pickle('predictions_v6.pkl')
def pente(y,pr):
    eps=1e-6; lo=np.log(np.clip(pr,eps,1-eps)/(1-np.clip(pr,eps,1-eps)))
    return LogisticRegression(penalty=None,max_iter=1000).fit(lo.reshape(-1,1),y).coef_[0][0]
def citl(y,pr):
    eps=1e-6; lo=np.log(np.clip(pr,eps,1-eps)/(1-np.clip(pr,eps,1-eps))); a=0.0
    for _ in range(30):
        q=1/(1+np.exp(-(lo+a))); a+=(y-q).sum()/(q*(1-q)).sum()
    return a
M=['CatBoost','XGBoost','Regression logistique']
codes=sorted(set(np.concatenate([c['te'].code.unique() for c in cells])))
pos={(c['bloc'],c['h']):{a:np.flatnonzero(c['te'].code.values==a) for a in codes} for c in cells}
def met(idx=None):
    o={}
    for m in M:
        P,I,B=[],[],[]
        for c in cells:
            y=c['te'].invendu.values; pr=c['P'][m]
            if idx is not None: s=idx[c['bloc'],c['h']]; y=y[s]; pr=pr[s]
            P.append(abs(pente(y,pr)-1)); I.append(abs(citl(y,pr))); B.append(brier_score_loss(y,pr))
        o[m]=(np.mean(P),np.mean(I),np.mean(B))
    return o
obs=met(); rng=np.random.default_rng(1); bt=[]
for b in range(200):
    s=rng.choice(codes,len(codes)); bt.append(met({k:np.concatenate([v[a] for a in s]) for k,v in pos.items()}))
for j,nom in enumerate(['|pente-1|','|intercept|','Brier']):
    for m2 in ['XGBoost','Regression logistique']:
        d=[r['CatBoost'][j]-r[m2][j] for r in bt]
        print(f'{nom} CatBoost - {m2}: {obs["CatBoost"][j]-obs[m2][j]:+.4f} IC [{np.percentile(d,2.5):+.4f} ; {np.percentile(d,97.5):+.4f}]')
R=pd.read_csv('cellules_v6.csv'); c=R[R.modele=='CatBoost']; print('CatBoost pentes',c.pente.min().round(3),c.pente.max().round(3),'intercepts',c.intercept.min().round(3),c.intercept.max().round(3))
