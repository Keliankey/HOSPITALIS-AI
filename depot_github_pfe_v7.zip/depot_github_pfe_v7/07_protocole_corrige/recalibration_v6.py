exec(open('protocole_v6.py').read().split("MODELES = ['Regression logistique'")[0])
R = pd.read_csv('cellules_v6.csv')
R['abs_pente'] = (R.pente-1).abs(); R['abs_int'] = R.intercept.abs()
print(R.groupby('modele')[['AUC','Brier','pente','abs_pente','intercept','abs_int']].mean().round(4).to_string())
# recalibration temporelle : modele ajuste sans les 180 derniers jours avant la coupure, recalibre (Platt) sur ces 180 jours
def platt(pc, yc, pt):
    eps=1e-6; lo=lambda p: np.log(np.clip(p,eps,1-eps)/(1-np.clip(p,eps,1-eps)))
    m=LogisticRegression(C=1e6).fit(lo(pc).reshape(-1,1), yc); return m.predict_proba(lo(pt).reshape(-1,1))[:,1]
BORNES = ['2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']; rows=[]
for i in range(1,4):
    t1,t2=BORNES[i-1],BORNES[i]
    for h in HOR:
        d=ouv[ouv.horizon==h].sort_values(['nuit','code'])
        cp=pd.Timestamp(t1)-pd.Timedelta(days=h); cc=cp-pd.Timedelta(days=180)
        fit=d[d.nuit<cc]; cal_=d[(d.nuit>=cc)&(d.nuit<cp)]; te=d[(d.nuit>=t1)&(d.nuit<t2)]; y=te.invendu.values
        for m in ['Regression logistique','CatBoost']:
            both=pd.concat([cal_,te]); pr=ajuste(m,fit,both); pc,pt=pr[:len(cal_)],pr[len(cal_):]
            q=platt(pc,cal_.invendu.values,pt)
            rows.append(dict(bloc=i,horizon=h,modele=m+' recalibree',AUC=roc_auc_score(y,q),Brier=brier_score_loss(y,q),pente=pente(y,q),intercept=citl(y,q),ecart_pct=100*(q.sum()-y.sum())/y.sum()))
        print(i,h,flush=True)
Q=pd.DataFrame(rows); Q.to_csv('recalibration_v6.csv',index=False)
Q['abs_pente']=(Q.pente-1).abs(); Q['abs_int']=Q.intercept.abs()
print(Q.groupby('modele')[['AUC','Brier','pente','abs_pente','intercept','abs_int']].mean().round(4).to_string())
print(Q[Q.bloc==3].pivot_table(index='modele',columns='horizon',values='ecart_pct').round(1)[HOR].to_string())
