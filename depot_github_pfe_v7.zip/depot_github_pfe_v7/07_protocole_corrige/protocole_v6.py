"""Comparaison des protocoles de validation et des familles de modeles.

QUATRE MODELES : regression logistique, XGBoost, CatBoost, LSTM.
TROIS PROTOCOLES :
  A. Blocs temporels successifs        — celui du memoire
  B. Aleatoire 80/20, PAR horizon      — pas de fuite entre horizons, un horizon a la fois
  C. Aleatoire 80/20, TOUS horizons melanges, deux variantes :
       C1 sans regroupement  -> la meme nuit peut etre a la fois en apprentissage
                                (ligne J-90) et en test (ligne J-7). C est la fuite.
       C2 groupe par nuit    -> toutes les lignes d une nuit vont du meme cote.
     L ecart C1 - C2 MESURE la fuite. C est l argument empirique de la section 7.2.

Le LSTM prend en entree la sequence d occupation des 60 nuits precedant d0 pour le
meme bien — information connue a d0, puisque ces nuits sont passees — plus les
attributs statiques concatenes a l etat cache final.
"""
import numpy as np, pandas as pd, warnings, time
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, brier_score_loss
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
from catboost import CatBoostClassifier
import torch, torch.nn as nn
warnings.filterwarnings('ignore')
torch.manual_seed(0); np.random.seed(0)
torch.set_num_threads(2)

VAC = ['vac_fwb', 'vac_flandre', 'vac_les_deux', 'vac_une_seule', 'vac_fwb_jour', 'vac_flandre_jour']
BASE = ['quantieme', 'jour_semaine', 'week_end', 'mois', 'occ_30j', 'occ_60j',
        'jours_depuis_resa', 'jours_depuis_remise_en_ligne', 'penalite_visibilite',
        'ferie', 'veille_ferie', 'pont']
FEAT = BASE + VAC
CAT = ['zone']
HOR = [90, 60, 30, 15, 7, 3]
SEQ = 60

p = pd.read_pickle('panel.pkl')
C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier')
C['date'] = pd.to_datetime(C.date)
cal = C[['date', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour_eur'] + VAC]
cal.columns = ['nuit', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour'] + VAC
p = p.merge(cal, on='nuit', how='left')
p = p.merge(pd.read_pickle('p2w.pkl').reset_index()[['code', 'zone']], on='code', how='left')
p['invendu'] = 1 - p.vendu
p['week_end'] = p.jour_semaine.isin([4, 5]).astype(int)
p['mois'] = p.nuit.dt.month
p['zone_i'] = pd.factorize(p.zone)[0]
ouv = p[p.deja_vendu_a_d0 == 0].copy().reset_index(drop=True)
ouv['nuit_id'] = ouv.code.astype(str) + '|' + ouv.nuit.dt.strftime('%Y%m%d')

# --- sequences d occupation, connues a d0 -----------------------------------
per = pd.read_pickle('perim.pkl')
occ = {c: g.set_index('nuit').vendu.sort_index() for c, g in per.groupby('code')}
idx = {c: {d: i for i, d in enumerate(s.index)} for c, s in occ.items()}
arr = {c: s.values.astype(np.float32) for c, s in occ.items()}

def sequences(df):
    X = np.zeros((len(df), SEQ, 2), dtype=np.float32)
    for k, (c, d0) in enumerate(zip(df.code.values, df.d0.values)):
        s, ix = arr[c], idx[c]
        j = ix.get(pd.Timestamp(d0))
        if j is None:                       # d0 hors perimetre : sequence vide
            X[k, :, 1] = 0.0; continue
        a = max(0, j - SEQ); v = s[a:j]
        if len(v):
            X[k, SEQ-len(v):, 0] = v        # occupation
            X[k, SEQ-len(v):, 1] = 1.0      # masque de presence
    return X

class Reseau(nn.Module):
    def __init__(self, n_stat, n_zone):
        super().__init__()
        self.emb = nn.Embedding(n_zone, 4)
        self.lstm = nn.LSTM(2, 24, batch_first=True)
        self.tete = nn.Sequential(nn.Linear(24 + n_stat + 4, 32), nn.ReLU(),
                                  nn.Dropout(0.2), nn.Linear(32, 1))
    def forward(self, seq, stat, zone):
        _, (h, _) = self.lstm(seq)
        return self.tete(torch.cat([h[-1], stat, self.emb(zone)], 1)).squeeze(1)

def pente(y, pr):
    eps = 1e-6; lo = np.log(np.clip(pr, eps, 1-eps) / (1 - np.clip(pr, eps, 1-eps)))
    if len(np.unique(y)) < 2: return np.nan
    return LogisticRegression(penalty=None, solver='lbfgs', max_iter=1000)\
        .fit(lo.reshape(-1, 1), y).coef_[0][0]

def ajuste(nom, tr, te):
    """Entraine `nom` sur tr, renvoie les probabilites predites sur te."""
    ytr = tr.invendu.values
    if nom == 'Regression logistique':
        F = FEAT + ['zone_i']
        sc = StandardScaler().fit(tr[F].fillna(tr[F].median()))
        a = sc.transform(tr[F].fillna(tr[F].median()))
        b = sc.transform(te[F].fillna(tr[F].median()))
        m = LogisticRegression(max_iter=2000).fit(a, ytr)
        return m.predict_proba(b)[:, 1]
    if nom == 'XGBoost':
        m = xgb.XGBClassifier(n_estimators=150, max_depth=3, learning_rate=0.03,
                              subsample=0.7, colsample_bytree=0.7, reg_lambda=10.0,
                              min_child_weight=50, eval_metric='logloss',
                              tree_method='hist').fit(tr[FEAT + ['zone_i']], ytr)
        return m.predict_proba(te[FEAT + ['zone_i']])[:, 1]
    if nom == 'CatBoost':
        m = CatBoostClassifier(iterations=150, depth=3, learning_rate=0.03, l2_leaf_reg=20,
                               verbose=0, allow_writing_files=False)\
            .fit(pd.concat([tr[FEAT], tr[CAT]], axis=1), ytr, cat_features=CAT)
        return m.predict_proba(pd.concat([te[FEAT], te[CAT]], axis=1))[:, 1]
    # LSTM
    sc = StandardScaler().fit(tr[FEAT].fillna(tr[FEAT].median()))
    Str, Ste = sequences(tr), sequences(te)
    Xtr = torch.tensor(sc.transform(tr[FEAT].fillna(tr[FEAT].median())), dtype=torch.float32)
    Xte = torch.tensor(sc.transform(te[FEAT].fillna(tr[FEAT].median())), dtype=torch.float32)
    Ztr = torch.tensor(tr.zone_i.values, dtype=torch.long)
    Zte = torch.tensor(te.zone_i.values, dtype=torch.long)
    Ytr = torch.tensor(ytr, dtype=torch.float32)
    Qtr, Qte = torch.tensor(Str), torch.tensor(Ste)
    net = Reseau(len(FEAT), int(p.zone_i.max()) + 1)
    opt = torch.optim.Adam(net.parameters(), lr=2e-3, weight_decay=1e-4)
    perte = nn.BCEWithLogitsLoss()
    n, bs = len(tr), 512
    for ep in range(12):
        net.train(); ordre = torch.randperm(n)
        for i in range(0, n, bs):
            j = ordre[i:i+bs]; opt.zero_grad()
            l = perte(net(Qtr[j], Xtr[j], Ztr[j]), Ytr[j]); l.backward(); opt.step()
    net.eval()
    with torch.no_grad():
        return torch.sigmoid(net(Qte, Xte, Zte)).numpy()


def naive(tr, te):
    """Taux historique d'invendu de l'annonce pour le meme mois, a cet horizon (retrecissement k=20)."""
    g = tr.invendu.mean(); k = 20
    a = tr.groupby('code').invendu.agg(['sum', 'size']); ra = (a['sum'] + k*g) / (a['size'] + k)
    am = tr.groupby(['code', 'mois']).invendu.agg(['sum', 'size']).reset_index()
    am['ra'] = am.code.map(ra); am['r'] = (am['sum'] + k*am.ra) / (am['size'] + k)
    t = te[['code', 'mois']].merge(am[['code', 'mois', 'r']], on=['code', 'mois'], how='left')
    return t.r.fillna(te.code.map(ra).reset_index(drop=True)).fillna(g).values

def citl(y, pr):
    """Calibration dans l'ensemble : intercept a tel que logit(p) + a reproduit le taux observe."""
    eps = 1e-6; lo = np.log(np.clip(pr, eps, 1-eps) / (1 - np.clip(pr, eps, 1-eps))); a = 0.0
    for _ in range(50):
        q = 1/(1+np.exp(-(lo+a))); g = (y-q).sum(); hss = (q*(1-q)).sum(); a += g/hss
    return a

# revenu hote hors menage par nuit vendue, estime sur les sejours termines avant le premier jour de decision du bloc
RES = pd.read_csv('sejours_pseudonymises.csv', parse_dates=['date_arrivee', 'date_depart'])
RES = RES[(RES.nuits > 0) & (RES.revenu_brut_eur > 0)]
def rev_passe(borne):
    s = RES[RES.date_depart < pd.Timestamp(borne) - pd.Timedelta(days=90)]
    return float((s.revenu_brut_eur - s.frais_menage_eur).sum() / s.nuits.sum())

MODELES = ['Regression logistique', 'XGBoost', 'CatBoost', 'LSTM']
BORNES = ['2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']
res, cells = [], []
t0 = time.time()
for i in range(1, len(BORNES)):
    t1, t2 = BORNES[i-1], BORNES[i]; REV = rev_passe(t1)
    for h in HOR:
        d = ouv[ouv.horizon == h].sort_values(['nuit', 'code'])
        coupure = pd.Timestamp(t1) - pd.Timedelta(days=h)          # apprentissage purge : issue connue au premier jour de decision du bloc
        tr = d[d.nuit < coupure]; te = d[(d.nuit >= t1) & (d.nuit < t2)].reset_index(drop=True)
        y = te.invendu.values
        P = {m: ajuste(m, tr, te) for m in MODELES}; P['Reference naive'] = naive(tr, te)
        for m, pr in P.items():
            res.append(dict(bloc=i, periode=f'{t1[:7]}->{t2[:7]}', horizon=h, modele=m, n_train=len(tr), n_test=len(te),
                            coupure=str(coupure.date()), taux_invendu=round(100*y.mean(), 1), AUC=roc_auc_score(y, pr),
                            Brier=brier_score_loss(y, pr), pente=pente(y, pr), intercept=citl(y, pr),
                            somme_predite=pr.sum(), invendus=y.sum(), ecart_pct=100*(pr.sum()-y.sum())/y.sum(), REV=REV))
        cells.append(dict(bloc=i, h=h, REV=REV, te=te[['code', 'nuit', 'd0', 'horizon', 'invendu', 'occ_30j', 'jours_depuis_resa', 'zone', 'jour_semaine', 'mois']].copy(), P=P))
        print(f'bloc {i} J-{h}: ' + '  '.join(f'{m[:8]} {roc_auc_score(y, v):.4f}' for m, v in P.items()) + f'  ({time.time()-t0:.0f} s)', flush=True)

R = pd.DataFrame(res); R.to_csv('cellules_v6.csv', index=False)
pd.to_pickle(cells, 'predictions_v6.pkl')
print(R.groupby('modele')[['AUC', 'Brier', 'pente', 'intercept']].mean().round(4).to_string())
print(R.pivot_table(index='modele', columns='horizon', values='AUC').round(4)[HOR].to_string())
print(R[R.bloc == 3].pivot_table(index='modele', columns='horizon', values='ecart_pct').round(1)[HOR].to_string())

# --- intervalles par reechantillonnage en grappes sur les annonces (B = 300)
codes = sorted(ouv.code.unique()); rng = np.random.default_rng(42); B = 300
pos = {(c['bloc'], c['h']): {a: np.flatnonzero(c['te'].code.values == a) for a in codes} for c in cells}
noms = list(cells[0]['P'].keys())
def metr(idx=None):
    out = {}
    for k in noms:
        A, S = [], []
        for c in cells:
            y = c['te'].invendu.values; pr = c['P'][k]
            if idx is not None:
                s = idx[c['bloc'], c['h']]; y = y[s]; pr = pr[s]
            A.append(roc_auc_score(y, pr)); S.append(pente(y, pr))
        out['auc_'+k] = np.mean(A); out['pente_'+k] = np.mean(S)
    return out
obs = metr(); boot = []
for b in range(B):
    s = rng.choice(codes, len(codes), replace=True)
    boot.append(metr({k: np.concatenate([v[a] for a in s]) for k, v in pos.items()}))
Bt = pd.DataFrame(boot); Bt.to_csv('bootstrap_v6.csv', index=False)
def ic(x): return (round(np.percentile(x, 2.5), 4), round(np.percentile(x, 97.5), 4))
lignes = []
for nom, a, b in [('AUC CatBoost - reference naive', 'auc_CatBoost', 'auc_Reference naive'),
                  ('AUC XGBoost - CatBoost', 'auc_XGBoost', 'auc_CatBoost'),
                  ('AUC Regression logistique - CatBoost', 'auc_Regression logistique', 'auc_CatBoost'),
                  ('AUC LSTM - CatBoost', 'auc_LSTM', 'auc_CatBoost'),
                  ('Pente CatBoost - XGBoost', 'pente_CatBoost', 'pente_XGBoost'),
                  ('Pente CatBoost - Regression logistique', 'pente_CatBoost', 'pente_Regression logistique')]:
    lignes.append(dict(comparaison=nom, ecart=round(obs[a]-obs[b], 4), ic=ic(Bt[a]-Bt[b])))
L = pd.DataFrame(lignes); L.to_csv('ic_v6.csv', index=False); print(L.to_string())
pd.DataFrame([obs]).to_csv('moyennes_v6.csv', index=False)
print('fini', round(time.time()-t0), 's')
