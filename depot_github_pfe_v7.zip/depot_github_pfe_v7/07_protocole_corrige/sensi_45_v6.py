"""Comparaison des protocoles de validation et des familles de modeles.

QUATRE MODELES : regression logistique, XGBoost, CatBoost, LSTM.
TROIS PROTOCOLES :
  A. Blocs temporels successifs        — celui du memoire
  B. Aleatoire 80/20, PAR horizon      — pas de fuite entre horizons, un horizon a la fois
  C. Aleatoire 80/20, TOUS horizons melanges, deux variantes :
       C1 sans regroupement  -> la meme nuit peut etre a la fois en apprentissage
                                (ligne J-90) et en test (ligne J-7). C est la fuite.
       C2 groupe par nuit    -> toutes les lignes d une nuit vont du meme cote.
     L ecart C1 - C2 MESURE la fuite. C est l argument empirique de la section 7.2.

Le LSTM prend en entree la sequence d occupation des 60 nuits precedant d0 pour le
meme bien — information connue a d0, puisque ces nuits sont passees — plus les
attributs statiques concatenes a l etat cache final.
"""
import numpy as np, pandas as pd, warnings, time
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, brier_score_loss
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
from catboost import CatBoostClassifier
import torch, torch.nn as nn
warnings.filterwarnings('ignore')
torch.manual_seed(0); np.random.seed(0)
torch.set_num_threads(2)

VAC = ['vac_fwb', 'vac_flandre', 'vac_les_deux', 'vac_une_seule', 'vac_fwb_jour', 'vac_flandre_jour']
BASE = ['quantieme', 'jour_semaine', 'week_end', 'mois', 'occ_30j', 'occ_60j',
        'jours_depuis_resa', 'jours_depuis_remise_en_ligne', 'penalite_visibilite',
        'ferie', 'veille_ferie', 'pont']
FEAT = BASE + VAC
CAT = ['zone']
HOR = [90, 60, 30, 15, 7, 3]
SEQ = 60

p = pd.read_pickle('panel_45.pkl')
C = pd.read_excel('Calendrier_exogene_v2.xlsx', sheet_name='Calendrier')
C['date'] = pd.to_datetime(C.date)
cal = C[['date', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour_eur'] + VAC]
cal.columns = ['nuit', 'ferie', 'veille_ferie', 'pont', 'tva_taux', 'taxe_sejour'] + VAC
p = p.merge(cal, on='nuit', how='left')
p = p.merge(pd.read_pickle('win_45.pkl')[['code', 'zone']], on='code', how='left')
p['invendu'] = 1 - p.vendu
p['week_end'] = p.jour_semaine.isin([4, 5]).astype(int)
p['mois'] = p.nuit.dt.month
p['zone_i'] = pd.factorize(p.zone)[0]
ouv = p[p.deja_vendu_a_d0 == 0].copy().reset_index(drop=True)
ouv['nuit_id'] = ouv.code.astype(str) + '|' + ouv.nuit.dt.strftime('%Y%m%d')

# --- sequences d occupation, connues a d0 -----------------------------------
per = pd.read_pickle('perim_45.pkl')
occ = {c: g.set_index('nuit').vendu.sort_index() for c, g in per.groupby('code')}
idx = {c: {d: i for i, d in enumerate(s.index)} for c, s in occ.items()}
arr = {c: s.values.astype(np.float32) for c, s in occ.items()}

def sequences(df):
    X = np.zeros((len(df), SEQ, 2), dtype=np.float32)
    for k, (c, d0) in enumerate(zip(df.code.values, df.d0.values)):
        s, ix = arr[c], idx[c]
        j = ix.get(pd.Timestamp(d0))
        if j is None:                       # d0 hors perimetre : sequence vide
            X[k, :, 1] = 0.0; continue
        a = max(0, j - SEQ); v = s[a:j]
        if len(v):
            X[k, SEQ-len(v):, 0] = v        # occupation
            X[k, SEQ-len(v):, 1] = 1.0      # masque de presence
    return X

class Reseau(nn.Module):
    def __init__(self, n_stat, n_zone):
        super().__init__()
        self.emb = nn.Embedding(n_zone, 4)
        self.lstm = nn.LSTM(2, 24, batch_first=True)
        self.tete = nn.Sequential(nn.Linear(24 + n_stat + 4, 32), nn.ReLU(),
                                  nn.Dropout(0.2), nn.Linear(32, 1))
    def forward(self, seq, stat, zone):
        _, (h, _) = self.lstm(seq)
        return self.tete(torch.cat([h[-1], stat, self.emb(zone)], 1)).squeeze(1)

def pente(y, pr):
    eps = 1e-6; lo = np.log(np.clip(pr, eps, 1-eps) / (1 - np.clip(pr, eps, 1-eps)))
    if len(np.unique(y)) < 2: return np.nan
    return LogisticRegression(penalty=None, solver='lbfgs', max_iter=1000)\
        .fit(lo.reshape(-1, 1), y).coef_[0][0]

def ajuste(nom, tr, te):
    """Entraine `nom` sur tr, renvoie les probabilites predites sur te."""
    ytr = tr.invendu.values
    if nom == 'Regression logistique':
        F = FEAT + ['zone_i']
        sc = StandardScaler().fit(tr[F].fillna(tr[F].median()))
        a = sc.transform(tr[F].fillna(tr[F].median()))
        b = sc.transform(te[F].fillna(tr[F].median()))
        m = LogisticRegression(max_iter=2000).fit(a, ytr)
        return m.predict_proba(b)[:, 1]
    if nom == 'XGBoost':
        m = xgb.XGBClassifier(n_estimators=150, max_depth=3, learning_rate=0.03,
                              subsample=0.7, colsample_bytree=0.7, reg_lambda=10.0,
                              min_child_weight=50, eval_metric='logloss',
                              tree_method='hist').fit(tr[FEAT + ['zone_i']], ytr)
        return m.predict_proba(te[FEAT + ['zone_i']])[:, 1]
    if nom == 'CatBoost':
        m = CatBoostClassifier(iterations=150, depth=3, learning_rate=0.03, l2_leaf_reg=20,
                               verbose=0, allow_writing_files=False)\
            .fit(pd.concat([tr[FEAT], tr[CAT]], axis=1), ytr, cat_features=CAT)
        return m.predict_proba(pd.concat([te[FEAT], te[CAT]], axis=1))[:, 1]
    # LSTM
    sc = StandardScaler().fit(tr[FEAT].fillna(tr[FEAT].median()))
    Str, Ste = sequences(tr), sequences(te)
    Xtr = torch.tensor(sc.transform(tr[FEAT].fillna(tr[FEAT].median())), dtype=torch.float32)
    Xte = torch.tensor(sc.transform(te[FEAT].fillna(tr[FEAT].median())), dtype=torch.float32)
    Ztr = torch.tensor(tr.zone_i.values, dtype=torch.long)
    Zte = torch.tensor(te.zone_i.values, dtype=torch.long)
    Ytr = torch.tensor(ytr, dtype=torch.float32)
    Qtr, Qte = torch.tensor(Str), torch.tensor(Ste)
    net = Reseau(len(FEAT), int(p.zone_i.max()) + 1)
    opt = torch.optim.Adam(net.parameters(), lr=2e-3, weight_decay=1e-4)
    perte = nn.BCEWithLogitsLoss()
    n, bs = len(tr), 512
    for ep in range(12):
        net.train(); ordre = torch.randperm(n)
        for i in range(0, n, bs):
            j = ordre[i:i+bs]; opt.zero_grad()
            l = perte(net(Qtr[j], Xtr[j], Ztr[j]), Ytr[j]); l.backward(); opt.step()
    net.eval()
    with torch.no_grad():
        return torch.sigmoid(net(Qte, Xte, Zte)).numpy()


def naive(tr, te):
    """Taux historique d'invendu de l'annonce pour le meme mois, a cet horizon (retrecissement k=20)."""
    g = tr.invendu.mean(); k = 20
    a = tr.groupby('code').invendu.agg(['sum', 'size']); ra = (a['sum'] + k*g) / (a['size'] + k)
    am = tr.groupby(['code', 'mois']).invendu.agg(['sum', 'size']).reset_index()
    am['ra'] = am.code.map(ra); am['r'] = (am['sum'] + k*am.ra) / (am['size'] + k)
    t = te[['code', 'mois']].merge(am[['code', 'mois', 'r']], on=['code', 'mois'], how='left')
    return t.r.fillna(te.code.map(ra).reset_index(drop=True)).fillna(g).values

def citl(y, pr):
    """Calibration dans l'ensemble : intercept a tel que logit(p) + a reproduit le taux observe."""
    eps = 1e-6; lo = np.log(np.clip(pr, eps, 1-eps) / (1 - np.clip(pr, eps, 1-eps))); a = 0.0
    for _ in range(50):
        q = 1/(1+np.exp(-(lo+a))); g = (y-q).sum(); hss = (q*(1-q)).sum(); a += g/hss
    return a


MODELES = ['Regression logistique', 'XGBoost', 'CatBoost', 'LSTM']
BORNES = ['2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']; res=[]
for i in range(1, 4):
    t1, t2 = BORNES[i-1], BORNES[i]
    for hz in HOR:
        d = ouv[ouv.horizon == hz].sort_values(['nuit', 'code']); cp = pd.Timestamp(t1) - pd.Timedelta(days=hz)
        tr = d[d.nuit < cp]; te = d[(d.nuit >= t1) & (d.nuit < t2)]; y = te.invendu.values
        for m in MODELES:
            pr = ajuste(m, tr, te)
            res.append(dict(seuil=45, bloc=i, horizon=hz, modele=m, AUC=roc_auc_score(y, pr), pente=pente(y, pr), ecart_pct=100*(pr.sum()-y.sum())/y.sum()))
R = pd.DataFrame(res); R.to_csv('sensi_45_v6.csv', index=False); print(R.groupby('modele')[['AUC','pente']].mean().round(4))
