exec(open('protocole_v6.py').read().split("MODELES = ['Regression logistique'")[0])
cells=pd.read_pickle('predictions_v6.pkl'); B=['2025-03-01','2025-09-01','2026-03-01','2026-09-01']; rows=[]
for c in cells:
    i,h=c['bloc'],c['h']; d=ouv[ouv.horizon==h]; cp=pd.Timestamp(B[i-1])-pd.Timedelta(days=h); m=d[d.nuit<cp].occ_30j.mean()
    y=c['te'].invendu.values; heu=1-c['te'].occ_30j.fillna(m).values
    rows.append(dict(bloc=i,horizon=h,catboost=roc_auc_score(y,c['P']['CatBoost']),naive=roc_auc_score(y,c['P']['Reference naive']),heuristique_occ30=roc_auc_score(y,heu)))
A=pd.DataFrame(rows); A.to_csv('auc_references_v6.csv',index=False); print(A.groupby('horizon')[['catboost','naive','heuristique_occ30']].mean().round(3))
# IC CatBoost - heuristique
codes=sorted(ouv.code.unique()); rng=np.random.default_rng(42)
pos={(c['bloc'],c['h']):{a:np.flatnonzero(c['te'].code.values==a) for a in codes} for c in cells}
H={}
for c in cells:
    i,h=c['bloc'],c['h']; d=ouv[ouv.horizon==h]; cp=pd.Timestamp(B[i-1])-pd.Timedelta(days=h); H[(i,h)]=1-c['te'].occ_30j.fillna(d[d.nuit<cp].occ_30j.mean()).values
def diff(idx=None):
    v=[]
    for c in cells:
        y=c['te'].invendu.values; a=c['P']['CatBoost']; b=H[(c['bloc'],c['h'])]
        if idx is not None: s=idx[(c['bloc'],c['h'])]; y,a,b=y[s],a[s],b[s]
        v.append(roc_auc_score(y,a)-roc_auc_score(y,b))
    return np.mean(v)
o=diff(); bt=[diff({k:np.concatenate([v[a] for a in rng.choice(codes,len(codes))]) for k,v in pos.items()}) for _ in range(300)]
print('CatBoost - heuristique', round(o,4), np.percentile(bt,[2.5,97.5]).round(4))
