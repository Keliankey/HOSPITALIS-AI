import numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split, GroupShuffleSplit
import xgboost as xgb
from catboost import CatBoostClassifier
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']
BASE=['quantieme','jour_semaine','week_end','mois','occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne','penalite_visibilite','ferie','veille_ferie','pont']
F=BASE+VAC
p=pd.read_pickle('panel.pkl')
C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['date']=pd.to_datetime(C.date)
cal=C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC]; cal.columns=['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour']+VAC
p=p.merge(cal,on='nuit',how='left').merge(pd.read_pickle('p2w.pkl')[['code','zone']],on='code',how='left')
p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int); p['mois']=p.nuit.dt.month; p['zone_i']=pd.factorize(p.zone)[0]
d=p[p.deja_vendu_a_d0==0].reset_index(drop=True); d['nid']=d.code+'|'+d.nuit.dt.strftime('%Y%m%d')
def fit(nom,tr,te):
    y=tr.invendu.values
    if nom=='XGBoost':
        m=xgb.XGBClassifier(n_estimators=150,max_depth=3,learning_rate=.03,subsample=.7,colsample_bytree=.7,reg_lambda=10.,min_child_weight=50,tree_method='hist',random_state=0).fit(tr[F+['zone_i']],y); return m.predict_proba(te[F+['zone_i']])[:,1]
    if nom=='CatBoost':
        m=CatBoostClassifier(iterations=150,depth=3,learning_rate=.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False,random_seed=0).fit(pd.concat([tr[F],tr[['zone']]],axis=1),y,cat_features=['zone']); return m.predict_proba(pd.concat([te[F],te[['zone']]],axis=1))[:,1]
    a=tr[F+['zone_i']].fillna(tr[F+['zone_i']].median()); b=te[F+['zone_i']].fillna(tr[F+['zone_i']].median()); mu,sd=a.mean(),a.std()+1e-9
    return LogisticRegression(max_iter=2000).fit((a-mu)/sd,y).predict_proba((b-mu)/sd)[:,1]
res=[]
for s in range(10):
    tr1,te1=train_test_split(d,test_size=.2,random_state=s,stratify=d.invendu)
    i2,j2=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=s).split(d,groups=d.nid)); tr2,te2=d.iloc[i2],d.iloc[j2]
    for m in ['Regression logistique','XGBoost','CatBoost']:
        a1=roc_auc_score(te1.invendu,fit(m,tr1,te1)); a2=roc_auc_score(te2.invendu,fit(m,tr2,te2))
        res.append(dict(graine=s,modele=m,C1=a1,C2=a2,fuite=a1-a2))
R=pd.DataFrame(res); R.to_csv('fuite_10_graines_v6.csv',index=False)
print(R.groupby('modele').fuite.agg(['mean','std','min','max']).round(4))
