import pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
BLEU, ORANGE, ENCRE, GRILLE = '#2a78d6', '#eb6834', '#0b0b0b', '#d9d8d4'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'savefig.dpi':200,'savefig.bbox':'tight','axes.titlesize':9.5,'axes.titleweight':'bold'})
fig,ax=plt.subplots(figsize=(7.6,2.7)); deb=pd.Timestamp('2023-11-04'); B=[pd.Timestamp(b) for b in ['2025-03-01','2025-09-01','2026-03-01','2026-09-01']]
for i in range(3):
    yy=2-i; c90=(B[i]-pd.Timedelta(days=90)-deb).days
    ax.barh(yy,c90,left=0,color=BLEU,alpha=.85,height=.5)
    ax.barh(yy,90,left=c90,color=BLEU,alpha=.85,height=.5,hatch='////',edgecolor='white',linewidth=0)
    ax.barh(yy,(B[i+1]-B[i]).days,left=(B[i]-deb).days,color=ORANGE,height=.5)
    ax.text(-15,yy,f'Bloc {i+1}',ha='right',va='center',fontsize=8.5,color=ENCRE)
    ax.text(c90/2,yy,'apprentissage',ha='center',va='center',fontsize=7.5,color='white')
    ax.text((B[i]-deb).days+(B[i+1]-B[i]).days/2,yy,'test',ha='center',va='center',fontsize=7.5,color='white')
ax.text((B[2]-deb).days-45,-0.55,'zone hachurée : appris à J-3, pas à J-90',ha='center',va='center',fontsize=7,color=ENCRE)
ticks=[deb]+B; ax.set_xticks([(t-deb).days for t in ticks]); ax.set_xticklabels(['nov. 2023','mars 2025','sept. 2025','mars 2026','août 2026'],fontsize=7.5)
ax.set_yticks([]); [ax.spines[s].set_visible(False) for s in ('top','right','left')]; ax.set_ylim(-.8,2.5)
ax.set_title("Apprendre sur les nuits dont l'issue est connue au premier jour de décision, tester sur les 6 mois suivants")
fig.savefig('fig/fig_blocs_temporels.png'); plt.close(fig)
