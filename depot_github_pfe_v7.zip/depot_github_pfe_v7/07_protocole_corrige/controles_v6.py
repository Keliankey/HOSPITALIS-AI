"""Controles chiffres complementaires du memoire (protocole corrige).
Entrees : sejours_pseudonymises.csv, perim.pkl, panel.pkl, predictions_v6.pkl (produit par protocole_v6.py).
Sortie : affichage console, recopie dans controles_v6.log."""
import pandas as pd, numpy as np

s = pd.read_csv('sejours_pseudonymises.csv', parse_dates=['date_reservation', 'date_arrivee', 'date_depart'])
pe = pd.read_pickle('perim.pkl')
s['delai'] = (s.date_arrivee - s.date_reservation).dt.days

# 1. Section 3.2 : des 21 836 nuits vendues de l'extraction aux 21 143 nuits vendues du perimetre
n = [(c, d) for c, a, b in zip(s.code, s.date_arrivee, s.date_depart) for d in pd.date_range(a, b - pd.Timedelta(days=1))]
N = pd.DataFrame(n, columns=['code', 'nuit'])
apres = (N.nuit > '2026-08-31').sum(); avant = N[N.nuit <= '2026-08-31']
print(f'Nuits vendues {len(N)} ; posterieures au 31/08/2026 {apres} ; doublons (2 reservations, meme annonce, meme nuit) {len(avant) - len(avant.drop_duplicates())} ; distinctes {len(avant.drop_duplicates())} ; vendues du perimetre {int(pe.vendu.sum())}')

# 2. Tableau C.8 : meme decoupage que l'instantane du 1er septembre 2026 (arrivees du 26/08 au 30/12, reservations prises au plus tard le 1/09)
for y in [2024, 2025]:
    a, b, d = pd.Timestamp(f'{y}-08-26'), pd.Timestamp(f'{y}-12-30'), pd.Timestamp(f'{y}-09-01')
    inst = s[(s.date_reservation <= d) & (s.date_arrivee.between(a, b))]
    comp = s[s.date_arrivee.between(a, b)]
    print(f'{y} : instantane {len(inst)} reservations, delai median {inst.delai.median()} j ; historique complet {comp.delai.median()} j')
print(f'Population complete : delai median {s.delai.median()} j ; part des reservations prises dans les 7 derniers jours {100*(s.delai <= 7).mean():.1f} %')

# 3. Section 6.3 : plages d'invendu consecutif de 22 a 44 nuits
p = pe.sort_values(['code', 'nuit']).reset_index(drop=True)
p['run'] = ((p.vendu != p.groupby('code').vendu.shift()) | (p.nuit - p.groupby('code').nuit.shift() != pd.Timedelta(days=1))).cumsum()
r = p[p.vendu == 0].groupby('run').size(); pl = r[(r >= 22) & (r <= 44)]
p['plage'] = p.run.isin(pl.index)
p['periode'] = pd.cut(p.nuit, pd.to_datetime(['2023-11-01', '2025-03-01', '2025-09-01', '2026-03-01', '2026-09-01']), right=False, labels=['avant bloc 1', 'bloc 1', 'bloc 2', 'bloc 3'])
print(f'Plages : {len(pl)}, {pl.sum()} nuits, {100*pl.sum()/len(p):.1f} % du perimetre ; par periode (%) :', p.groupby('periode', observed=True).plage.mean().mul(100).round(1).to_dict(), f'; aout 2026 {100*p[p.nuit >= "2026-08-01"].plage.mean():.1f} %')

# 4. Section 4.6 et 5.4 : erreurs de CatBoost au dernier bloc et taux de base de la politique quotidienne
P = pd.read_pickle('predictions_v6.pkl')
T = pd.concat([c['te'].assign(p=c['P']['CatBoost'], h=c['h']) for c in P if c['bloc'] == 3])
T['err'] = 100 * (T.invendu - T.p)   # positif : invendu sous-estime
print('Ecart observe - predit par mois et horizon (points) :'); print(T.groupby(['mois', 'h']).err.mean().unstack().round(1))
print('Par zone :'); print(T.groupby(['zone', 'h']).err.mean().unstack().round(1))
print('Vendredi-samedi (True) / autres jours :'); print(T.groupby([T.jour_semaine.isin([4, 5]), 'h']).err.mean().unstack().round(1))
for h in [90, 3]:
    x = T[T.h == h]; q = x.p >= 0.5
    print(f'J-{h} au seuil 0,5 : faux negatifs {int(((~q) & (x.invendu == 1)).sum())}, faux positifs {int((q & (x.invendu == 0)).sum())}')
L = T[(T.d0 >= '2026-03-02') & (T.d0 <= '2026-08-30')].copy(); L['cle'] = L.code + L.nuit.astype(str)
for hs in [[90, 60, 30, 15, 7, 3], [90, 60, 30, 15]]:
    x = L[L.h.isin(hs)].drop_duplicates('cle'); print(f'Politique quotidienne, horizons {hs} : {len(x)} nuits candidates, invendu {100*x.invendu.mean():.1f} %')
