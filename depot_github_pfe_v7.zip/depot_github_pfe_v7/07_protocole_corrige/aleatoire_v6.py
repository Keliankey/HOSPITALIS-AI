exec(open('protocole_v6.py').read().split("MODELES = ['Regression logistique'")[0])
MODELES = ['Regression logistique', 'XGBoost', 'CatBoost', 'LSTM']; rows=[]
for h in HOR:
    d = ouv[ouv.horizon == h]
    tr, te = train_test_split(d, test_size=0.2, random_state=0, stratify=d.invendu)
    for m in MODELES:
        pr=ajuste(m,tr,te); rows.append(dict(protocole='B. aleatoire 80/20, par horizon',modele=m,horizon=h,AUC=roc_auc_score(te.invendu,pr),cal_pente=pente(te.invendu.values,pr)))
R=pd.DataFrame(rows); R.to_csv('aleatoire_v6.csv',index=False); print(R.groupby('modele')[['AUC','cal_pente']].mean().round(4))
