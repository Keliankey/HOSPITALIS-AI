exec(open('protocole_v6.py').read().split("MODELES = ['Regression logistique'")[0])
tb=pd.read_pickle('type_bien.pkl'); tb.columns=[c.lower() for c in tb.columns]; tb=tb.rename(columns={'type':'type_bien'})
ouv=ouv.merge(tb[['code','type_bien']],on='code',how='left'); ouv['type_bien']=ouv.type_bien.fillna('inconnu')
def cb(tr,te,cat):
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False)
    m.fit(pd.concat([tr[FEAT],tr[cat]],axis=1),tr.invendu,cat_features=cat); return m.predict_proba(pd.concat([te[FEAT],te[cat]],axis=1))[:,1]
B=['2025-03-01','2025-09-01','2026-03-01','2026-09-01']; rows=[]
for i in range(1,4):
    for h in HOR:
        d=ouv[ouv.horizon==h].sort_values(['nuit','code']); cp=pd.Timestamp(B[i-1])-pd.Timedelta(days=h)
        tr=d[d.nuit<cp]; te=d[(d.nuit>=B[i-1])&(d.nuit<B[i])]; y=te.invendu.values
        a=cb(tr,te,['zone']); b=cb(tr,te,['zone','type_bien'])
        rows.append(dict(bloc=i,h=h,auc_sans=roc_auc_score(y,a),auc_avec=roc_auc_score(y,b),pente_sans=pente(y,a),pente_avec=pente(y,b)))
R=pd.DataFrame(rows); R.to_csv('type_bien_v6.csv',index=False); print(R[['auc_sans','auc_avec','pente_sans','pente_avec']].mean().round(4))
