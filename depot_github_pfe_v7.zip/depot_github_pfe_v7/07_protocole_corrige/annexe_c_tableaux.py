"""Tableaux de l'annexe C, protocole corrige (apprentissage purge, 19 variables)."""
import pandas as pd, numpy as np, glob
V=lambda x,d=3: (f"{x:+.{d}f}" if False else f"{x:.{d}f}").replace('.',',').replace('-','−')
S=lambda x,d=4: f"{x:+.{d}f}".replace('.',',').replace('-','−')
HOR=[90,60,30,15,7,3]
NOMS={'CatBoost':'CatBoost','XGBoost':'XGBoost','Regression logistique':'Régression logistique','LSTM':'LSTM'}
def tab_c1():
    fs=sorted(glob.glob('v6/sensi_*_v6.csv'))
    if len(fs)<3: return None
    R=pd.concat([pd.read_csv(f) for f in fs]); L=R[R.bloc==3].groupby(['seuil','modele']).ecart_pct.apply(lambda s: s.values)
    M=R.groupby(['seuil','modele'])[['AUC','pente']].mean()
    out="| Seuil | Modèle | AUC | Pente | Écart en euros, dernier bloc, J-90 | J-30 | J-3 |\n|---|---|---:|---:|---:|---:|---:|\n"
    for s in [30,45,60]:
        for m in ['CatBoost','XGBoost','Regression logistique','LSTM']:
            e=R[(R.seuil==s)&(R.modele==m)&(R.bloc==3)].set_index('horizon').ecart_pct
            out+=f"| {s} jours | {NOMS[m]} | {V(M.loc[(s,m),'AUC'],4)} | {V(M.loc[(s,m),'pente'])} | {S(e[90],1)} % | {S(e[30],1)} % | {S(e[3],1)} % |\n"
    return out
NOTE_C1="Note. Aire sous la courbe et pente moyennes sur 3 blocs temporels et 6 horizons, apprentissage purgé (section 3.6). Pour chaque seuil, le périmètre est reconstruit et les 4 modèles réentraînés ; l'écart en euros compare, sur le dernier bloc, la somme des probabilités prédites au nombre d'invendus."
def tab_c3():
    T=pd.read_csv('v6/type_bien_v6.csv'); out="| Bloc | AUC sans le type | AUC avec le type | Pente sans | Pente avec |\n|---|---:|---:|---:|---:|\n"
    for b,g in T.groupby('bloc'):
        out+=f"| {b} | {V(g.auc_sans.mean(),4)} | {V(g.auc_avec.mean(),4)} | {V(g.pente_sans.mean())} | {V(g.pente_avec.mean())} |\n"
    out+=f"| Moyenne | {V(T.auc_sans.mean(),4)} | {V(T.auc_avec.mean(),4)} | {V(T.pente_sans.mean())} | {V(T.pente_avec.mean())} |\n"
    return out
def tab_c4():
    A=pd.read_csv('v6/auc_references_v6.csv').groupby('horizon')[['catboost','naive','heuristique_occ30']].mean().loc[HOR]
    return "| Horizon | CatBoost | Taux historique de l'annonce pour le mois | 1 − occupation à 30 jours |\n|---|---:|---:|---:|\n"+"\n".join(f"| J-{h} | {V(r.catboost)} | {V(r.naive)} | {V(r.heuristique_occ30)} |" for h,r in A.iterrows())
NOTE_C4=("Note. Aires sous la courbe moyennes sur les 3 blocs temporels, apprentissage purgé. La référence naïve est le taux d'invendu observé en apprentissage pour la même annonce, le même mois et le même horizon, "
 "ramené vers le taux de l'annonce puis vers le taux global lorsque l'effectif est faible.")
TAB_C5=("| Comparaison | Écart moyen | Intervalle à 95 % |\n|---|---:|---|\n"
 "| Aire sous la courbe, CatBoost moins référence naïve | +0,035 | [+0,003 ; +0,060] |\n"
 "| Aire sous la courbe, CatBoost moins 1 − occupation à 30 jours | +0,056 | [+0,046 ; +0,066] |\n"
 "| Aire sous la courbe, XGBoost moins CatBoost | +0,001 | [−0,003 ; +0,005] |\n"
 "| Aire sous la courbe, régression logistique moins CatBoost | −0,005 | [−0,013 ; +0,003] |\n"
 "| Aire sous la courbe, LSTM moins CatBoost | −0,006 | [−0,014 ; +0,004] |\n"
 "| Ordonnée à l'origine en valeur absolue, CatBoost moins XGBoost | −0,025 | [−0,036 ; −0,012] |\n"
 "| Ordonnée à l'origine en valeur absolue, CatBoost moins régression logistique | −0,121 | [−0,158 ; −0,062] |\n"
 "| Écart de la pente à 1, CatBoost moins XGBoost | −0,003 | [−0,088 ; +0,138] |\n"
 "| Score de Brier, CatBoost moins XGBoost | −0,0006 | [−0,0013 ; +0,0001] |\n"
 "| Score de Brier, CatBoost moins régression logistique | −0,0042 | [−0,0065 ; −0,0022] |")
NOTE_C5=("Note. Moyennes sur 3 blocs temporels et 6 horizons, apprentissage purgé. Intervalles obtenus par 300 rééchantillonnages en grappes sur les annonces pour les aires sous la courbe, 200 pour les mesures de calibration, les modèles restant fixés ; ils ne mesurent pas la variabilité du réentraînement.")
def tab_c7():
    R=pd.read_csv('v6/cellules_v6.csv'); p=R.pivot_table(index=['bloc','horizon'],columns='modele',values=['pente','intercept','Brier'])
    out="| Bloc | Horizon | CB, pente | CB, ord. | CB, Brier | XGB, pente | XGB, ord. | RL, pente | RL, ord. |\n|------|--------|------:|------:|------:|------:|------:|------:|------:|\n"
    for (b,h) in [(b,h) for b in [1,2,3] for h in HOR]:
        r=p.loc[(b,h)]
        out+=(f"| {b} | J-{h} | {V(r[('pente','CatBoost')])} | {V(r[('intercept','CatBoost')])} | {V(r[('Brier','CatBoost')])} | "
              f"{V(r[('pente','XGBoost')])} | {V(r[('intercept','XGBoost')])} | {V(r[('pente','Regression logistique')])} | {V(r[('intercept','Regression logistique')])} |\n")
    return out
NOTE_C7=("Note. CB : CatBoost ; XGB : XGBoost ; RL : régression logistique ; ord. : ordonnée à l'origine. Pente et ordonnée à l'origine de calibration, sur l'échelle des cotes : une pente de 1 et une ordonnée nulle correspondent à des probabilités justes en moyenne ; une ordonnée positive signale une sous-estimation du risque d'invendu. "
 "Une pente et une ordonnée proches de leurs valeurs idéales ne garantissent pas une bonne calibration locale, que la figure 7 examine pour le dernier bloc.")
