"""Apport des familles de variables exogènes, CatBoost, 3 blocs x 6 horizons, IC bootstrap par annonce.
Événements testés SOUS L'HYPOTHÈSE que leur date est connue au moins 90 jours à l'avance (non vérifiée dans le fichier)."""
import numpy as np, pandas as pd, warnings
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')
TEMPS=['quantieme','jour_semaine','week_end','mois']; HIST=['occ_30j','occ_60j','jours_depuis_resa','jours_depuis_remise_en_ligne','penalite_visibilite']
FER=['ferie','veille_ferie','pont']; FISC=['tva_taux','taxe_sejour']
VAC=['vac_fwb','vac_flandre','vac_les_deux','vac_une_seule','vac_fwb_jour','vac_flandre_jour']; EVT=['evt_public','conseil_ue']
CAT=['zone']; HOR=[90,60,30,15,7,3]
p=pd.read_pickle('panel.pkl')
C=pd.read_excel('Calendrier_exogene_v2.xlsx',sheet_name='Calendrier'); C['date']=pd.to_datetime(C.date)
cal=C[['date','ferie','veille_ferie','pont','tva_taux','taxe_sejour_eur']+VAC]; cal.columns=['nuit','ferie','veille_ferie','pont','tva_taux','taxe_sejour']+VAC
p=p.merge(cal,on='nuit',how='left').merge(pd.read_pickle('p2w.pkl').reset_index()[['code','zone']],on='code',how='left')
Ev=pd.read_excel('evenements.xlsx',sheet_name='Evenements'); Co=pd.read_excel('evenements.xlsx',sheet_name='Conseil_Bruxelles')
j1=set(pd.to_datetime(Ev[Ev.granularite_temporelle=='jour_unique'].date_debut)); j2=set(pd.to_datetime(Co.date))
p['evt_public']=p.nuit.isin(j1).astype(int); p['conseil_ue']=p.nuit.isin(j2).astype(int)
p['invendu']=1-p.vendu; p['week_end']=p.jour_semaine.isin([4,5]).astype(int); p['mois']=p.nuit.dt.month
ouv=p[p.deja_vendu_a_d0==0].copy()
print('nuits du périmètre avec événement public',int(p[p.horizon==3].evt_public.sum()),'avec Conseil',int(p[p.horizon==3].conseil_ue.sum()))
BASE0=TEMPS+HIST
VARS={'sans_exogenes':BASE0,'plus_feries':BASE0+FER,'plus_fiscal':BASE0+FISC,'plus_vacances':BASE0+VAC,
      'modele_final':BASE0+FER+VAC,'final_plus_fiscal':BASE0+FER+VAC+FISC,'final_plus_evenements':BASE0+FER+VAC+EVT}
BORNES=['2025-03-01','2025-09-01','2026-03-01','2026-09-01']
def cb(tr,te,f):
    m=CatBoostClassifier(iterations=150,depth=3,learning_rate=0.03,l2_leaf_reg=20,verbose=0,allow_writing_files=False)
    m.fit(pd.concat([tr[f],tr[CAT]],axis=1),tr.invendu,cat_features=CAT); return m.predict_proba(pd.concat([te[f],te[CAT]],axis=1))[:,1]
cells=[]
for i in range(3):
    for h in HOR:
        d=ouv[ouv.horizon==h].sort_values(['nuit','code']); cp=pd.Timestamp(BORNES[i])-pd.Timedelta(days=h)
        tr=d[d.nuit<cp]; te=d[(d.nuit>=BORNES[i])&(d.nuit<BORNES[i+1])].reset_index(drop=True)
        P={k:cb(tr,te,f) for k,f in VARS.items()}
        cells.append(dict(b=i,h=h,te=te[['code','invendu']],P=P)); print(i,h,flush=True)
codes=sorted(ouv.code.unique()); pos={(c['b'],c['h']):{a:np.flatnonzero(c['te'].code.values==a) for a in codes} for c in cells}
def auc_h(idx=None):
    r={}
    for k in VARS:
        for h in HOR:
            A=[]
            for c in cells:
                if c['h']!=h: continue
                y=c['te'].invendu.values; pr=c['P'][k]
                if idx is not None: s=idx[c['b'],c['h']]; y=y[s]; pr=pr[s]
                A.append(roc_auc_score(y,pr))
            r[(k,h)]=np.mean(A)
    return r
obs=auc_h(); rng=np.random.default_rng(7); B=200; bt=[]
for b in range(B):
    s=rng.choice(codes,len(codes)); bt.append(auc_h({k:np.concatenate([v[a] for a in s]) for k,v in pos.items()}))
rows=[]
for k,ref in [('plus_feries','sans_exogenes'),('plus_fiscal','sans_exogenes'),('plus_vacances','sans_exogenes'),('modele_final','sans_exogenes'),('final_plus_fiscal','modele_final'),('final_plus_evenements','modele_final')]:
    for h in HOR+['moy']:
        hs=HOR if h=='moy' else [h]
        o=np.mean([obs[(k,x)]-obs[(ref,x)] for x in hs]); d=[np.mean([r[(k,x)]-r[(ref,x)] for x in hs]) for r in bt]
        rows.append(dict(variante=k,reference=ref,horizon=h,ecart=round(o,4),ic_bas=round(np.percentile(d,2.5),4),ic_haut=round(np.percentile(d,97.5),4)))
R=pd.DataFrame(rows); R.to_csv('exogenes_ablation_v6.csv',index=False)
print(R[R.horizon.isin([90,30,3,'moy'])].to_string(index=False))
